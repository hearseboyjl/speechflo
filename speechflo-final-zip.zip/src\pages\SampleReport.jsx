import jsPDF from "jspdf";
import html2canvas from "html2canvas";  
import Menubar from "../components/Menubar";
import { useEffect, useMemo, useState, useRef } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { apiUrl } from "../api";
import { applyTheme, getSavedTheme } from "../theme";

export default function SampleReport() {
  const { applicationId: paramAppId } = useParams();
  const navigate = useNavigate();
  const reportRef = useRef(null);

  const [showRejectModal, setShowRejectModal] = useState(false);
  const [showEndorseModal, setShowEndorseModal] = useState(false);
  const [isExportingPdf, setIsExportingPdf] = useState(false);
  const [rejectionReason, setRejectionReason] = useState("");
  const [reportContent, setReportContent] = useState("");
  const [reportData, setReportData] = useState({ applicationId: paramAppId, status: "" });
  const [applicantEmail, setApplicantEmail] = useState("");
  const [showNoReportModal, setShowNoReportModal] = useState(false); // <-- new state for missing report

  // Apply saved theme
  useEffect(() => {
    applyTheme(getSavedTheme());
  }, []);

  // Force login if no session detected
  useEffect(() => {
    const token = localStorage.getItem("token");
    if (!token) {
      navigate("/recruiter/login");
      return;
    }

    const verifyUser = async () => {
      try {
        const res = await fetch(apiUrl("/auth/me"), {
          headers: { Authorization: `Bearer ${token}` },
        });

        if (!res.ok) throw new Error("Unauthorized");

        const data = await res.json();
        localStorage.setItem("user", data.firstName || "User");
      } catch (err) {
        localStorage.removeItem("token");
        localStorage.removeItem("user");
        navigate("/recruiter/login");
      }
    };

    verifyUser();
  }, [navigate]);

  // Fetch the report file from server
  useEffect(() => {
    if (!paramAppId) return;

    const fetchReport = async () => {
      try {
        const token = localStorage.getItem("token");
        const res = await fetch(apiUrl(`/reports/${paramAppId}`), {
          headers: {
            "Content-Type": "application/json",
            Authorization: token ? `Bearer ${token}` : undefined,
          },
        });

        if (!res.ok) throw new Error("Failed to fetch report");

        const data = await res.json();
        setReportContent(data.content);

        const parseSection = (title) => {
          const match = data.content.match(
            new RegExp(`${title}:\\n([\\s\\S]*?)(\\n\\n|$)`)
          );
          return match ? match[1].trim() : "";
        };

        setReportData({
          applicationId: paramAppId,
          status: String(data.applicationStatus || "").toLowerCase(),
          applicantId: parseSection("Applicant ID") || "",
          applicantName: parseSection("Applicant Name") || "N/A",
          jobTitle: parseSection("Position") || "N/A",
          recruiterName: parseSection("Recruiter Name") || "N/A",
          date: parseSection("Date") || "N/A",
          skills: parseSection("Skills Extracted")?.split(", ").filter(Boolean) || [],
          summary: parseSection("Summary") || "",
          sentiment: parseSection("Sentiment") || "",
          confidence: parseSection("Confidence") || "",
          compatibilityScore: parseSection("Role Compatibility Score") || "",
          compatibilityFlag: parseSection("Role Compatibility Flag") || "",
          recommendationClass: parseSection("Recommendation Class") || "",
          responseConsistencyScore: parseSection("Response Consistency Score") || "",
          areasForImprovement: parseSection("Areas for Improvement") || "",
          recommendation: parseSection("Recommended Next Step") || "",
        });
      } catch (err) {
        console.error("Error fetching report:", err);
        setShowNoReportModal(true); // <-- show modal when fetch fails
      }
    };

    fetchReport();
  }, [paramAppId]);

  // Fetch applicant email using applicantId
  useEffect(() => {
    if (!reportData.applicantId) return;

    const fetchEmail = async () => {
      try {
        const token = localStorage.getItem("token");
        const res = await fetch(
          apiUrl(`/email/${reportData.applicantId}`),
          {
            headers: { Authorization: `Bearer ${token}` },
          }
        );

        if (!res.ok) throw new Error("Failed to fetch email");

        const data = await res.json();
        setApplicantEmail(data.email || "N/A");
      } catch (err) {
        console.error("Error fetching email:", err);
        setApplicantEmail("N/A");
      }
    };

    fetchEmail();
  }, [reportData.applicantId]);

  // Memoize report for UI
  const report = useMemo(
    () => ({
      title: "Applicant Interview Report",
      date: reportData.date || "N/A",
      applicant: {
        name: reportData.applicantName || "N/A",
        email: applicantEmail || "N/A",
        position: reportData.jobTitle || "N/A",
        interviewedBy: reportData.recruiterName || "",
      },
      aiSummary: {
        sentimentScore: reportData.sentiment,
        confidenceLevel: reportData.confidence,
        compatibilityScore: reportData.compatibilityScore,
        compatibilityFlag: reportData.compatibilityFlag,
        recommendationClass: reportData.recommendationClass,
        responseConsistencyScore: reportData.responseConsistencyScore,
        keywords: reportData.skills || [],
      },
      insight: reportData.recommendation || "No insights available.",
      parsedSkills: reportData.parsedSkills || {},
    }),
    [reportData, applicantEmail]
  );

  const isAlreadyEndorsed = String(reportData.status || "").toLowerCase() === "endorsed";

  const handleExportPDF = async (sendToServer = false) => {
    if (!reportRef.current) return;
    const element = reportRef.current;
    setIsExportingPdf(true);
    try {
      if (!sendToServer) {
        const clone = element.cloneNode(true);
        clone.querySelectorAll(".pdf-exclude").forEach((node) => node.remove());

        const styleBundle = Array.from(
          document.querySelectorAll('link[rel="stylesheet"], style')
        )
          .map((node) => node.outerHTML)
          .join("\n");

        const printWindow = window.open(
          "",
          "_blank",
          "noopener,noreferrer,width=1200,height=900"
        );

        if (!printWindow) {
          alert("Unable to open print window. Please allow pop-ups and try again.");
          return;
        }

        printWindow.document.open();
        printWindow.document.write(`
          <!doctype html>
          <html>
            <head>
              <meta charset="utf-8" />
              <title>${report.applicant.name || "Report"} - Export</title>
              ${styleBundle}
              <style>
                html, body {
                  margin: 0;
                  padding: 0;
                  background: #ffffff;
                  -webkit-print-color-adjust: exact;
                  print-color-adjust: exact;
                }
                .print-wrapper {
                  padding: 18px;
                }
                .pdf-exclude {
                  display: none !important;
                }
                @page {
                  size: Letter;
                  margin: 10mm;
                }
              </style>
            </head>
            <body>
              <div class="print-wrapper">${clone.outerHTML}</div>
              <script>
                window.onload = () => {
                  setTimeout(() => {
                    window.focus();
                    window.print();
                  }, 120);
                };
                window.onafterprint = () => window.close();
              </script>
            </body>
          </html>
        `);
        printWindow.document.close();
        return;
      }

      const canvas = await html2canvas(element, {
        scale: 2,
        ignoreElements: (node) => node?.classList?.contains("pdf-exclude"),
      });
      const imgData = canvas.toDataURL("image/png");

      const pdf = new jsPDF("p", "mm", "letter");
      const imgProps = pdf.getImageProperties(imgData);
      const pdfWidth = pdf.internal.pageSize.getWidth();
      const pdfHeight = (imgProps.height * pdfWidth) / imgProps.width;
      pdf.addImage(imgData, "PNG", 0, 0, pdfWidth, pdfHeight);

      const fileName = `${report.applicant.name || "report"}.pdf`;
      pdf.save(fileName);

      if (sendToServer) {
        const pdfBlob = pdf.output("blob");
        const formData = new FormData();
        formData.append("pdf", pdfBlob, fileName);
        formData.append("applicantName", report.applicant.name);
        formData.append("applicationId", String(reportData.applicationId || ""));

        const token = localStorage.getItem("token");
        try {
          const res = await fetch(
            apiUrl("/application-decision/save-pdf"),
            {
              method: "POST",
              headers: { Authorization: `Bearer ${token}` },
              body: formData,
            }
          );

          if (!res.ok) throw new Error("Failed to send PDF to server");

          await res.json();
          return true;
        } catch (err) {
          console.error("Error sending PDF to server:", err);
          return false;
        }
      }
    } finally {
      setIsExportingPdf(false);
    }
  };

  const handleReject = async () => {
    if (isAlreadyEndorsed) {
      alert("This application is already endorsed.");
      return false;
    }

    const reason = rejectionReason.trim();
    if (!reason) {
      alert("Please enter a reason for rejection.");
      return false;
    }

    try {
      const token = localStorage.getItem("token");
      const res = await fetch(
        apiUrl(`/application-decision/reject/${reportData.applicationId}`),
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`,
          },
          body: JSON.stringify({
            applicationId: reportData.applicationId,
            rejectionReason: reason,
          }),
        }
      );

      if (!res.ok) throw new Error("Failed to reject application");
      await res.json();
      setRejectionReason("");
      return true;
    } catch (err) {
      console.error("Error rejecting application:", err);
      alert("Failed to reject application. Please try again.");
      return false;
    }
  };

  const cardCls = [
    "rounded-2xl",
    "bg-surface backdrop-blur-md",
    "shadow-[0_12px_30px_rgba(15,23,42,0.08)]",
    "dark:shadow-[0_12px_30px_rgba(0,0,0,0.35)]",
    "hover:shadow-[0_18px_45px_rgba(15,23,42,0.12)]",
    "dark:hover:shadow-[0_18px_45px_rgba(0,0,0,0.45)]",
    "transition-shadow",
    "border-2 border-token",
  ].join(" ");

  const panelCls = [
    "mt-4 rounded-xl",
    "bg-surface-strong backdrop-blur-sm",
    "border border-token",
  ].join(" ");

  const dividerCls = "border-t border-token";

  const exportBtn = [
    "h-10 px-6 rounded-xl",
    "border border-[#2779b3]",
    "bg-[#2f8dcd] text-white font-semibold",
    "shadow-[0_8px_20px_rgba(15,23,42,0.16)]",
    "hover:bg-[#287cb5] hover:shadow-[0_12px_28px_rgba(15,23,42,0.2)]",
    "active:translate-y-[1px]",
    "transition-all duration-200",
    "dark:border-sky-300 dark:bg-sky-400 dark:text-[#072236] dark:hover:bg-sky-300",
  ].join(" ");

  const primaryBtn = [
    "h-10 px-6 rounded-xl",
    "bg-btn-primary font-semibold",
    "shadow-[0_8px_20px_rgba(15,23,42,0.15)]",
    "hover:brightness-95",
    "active:translate-y-[1px]",
    "transition",
  ].join(" ");

  const rejectBtn = [
    "h-10 px-6 rounded-xl",
    "bg-btn-reject font-semibold",
    "shadow-card",
    "hover:brightness-95",
    "active:translate-y-[1px]",
    "transition-all duration-200",
  ].join(" ");

  const chipCls = [
    "inline-flex items-center justify-center rounded-full",
    "bg-chip text-chip border border-chip",
    "px-3 py-1.5 text-xs font-semibold",
  ].join(" ");

  const sectionTitleCls = "text-xs font-bold tracking-wide text-title";

  return (
    <div className="min-h-screen w-full bg-app">
      <Menubar />

      <main className="min-h-screen bg-app layout-main">
        <div className="max-w-[1200px] mx-auto px-8 py-8">
          <div className={`p-8 ${cardCls}`} ref={reportRef}>
            {/* Header */}
            <div className="flex flex-col lg:flex-row lg:items-start lg:justify-between gap-6">
              <div>
                <h1 className="text-4xl font-bold text-title">{report.title}</h1>

                <div className="mt-4 flex flex-col sm:flex-row sm:items-center gap-3">
                  <div className="text-sm text-muted">
                    <span className="font-semibold text-main">Date:</span>{" "}
                    {report.date}
                  </div>

                  <button className={`${exportBtn} pdf-exclude`} type="button" onClick={handleExportPDF} disabled={isExportingPdf}>
                    Export PDF
                  </button>
                </div>
              </div>

              <div className="pdf-exclude flex flex-col sm:flex-row lg:flex-col items-start sm:items-center lg:items-end gap-3">
                {!isAlreadyEndorsed ? (
                  <>
                    <button
                      className={primaryBtn}
                      type="button"
                      onClick={() => setShowEndorseModal(true)}
                    >
                      Endorse to CEO
                    </button>
                    <button
                      className={rejectBtn}
                      type="button"
                      onClick={() => setShowRejectModal(true)}
                    >
                      Reject
                    </button>
                  </>
                ) : null}
              </div>
            </div>

            <div className={`mt-6 ${dividerCls}`} />

            {/* Applicant info */}
            <section className="mt-6">
              <h2 className={sectionTitleCls}>APPLICANT INFORMATION</h2>

              <div className="mt-4 grid grid-cols-1 md:grid-cols-2 gap-4">
                <InfoPill label="Name" value={report.applicant.name} />
                <InfoPill label="Email" value={report.applicant.email} />
                <InfoPill label="Position" value={report.applicant.position} />
                <InfoPill label="Interviewed By" value={report.applicant.interviewedBy} />
              </div>
            </section>

            {/* AI Analysis Summary */}
            <section className="mt-6">
              <h2 className={sectionTitleCls}>AI ANALYSIS SUMMARY</h2>

              <div className={`${panelCls} p-5`}>
                <div className="text-sm text-main">
                  <span className="font-semibold">Sentiment Score:</span>{" "}
                  <span className="text-muted">{report.aiSummary.sentimentScore}</span>
                </div>

                <div className="mt-2 text-sm text-main">
                  <span className="font-semibold">Confidence Level:</span>{" "}
                  <span className="text-muted">{report.aiSummary.confidenceLevel}</span>
                </div>
                <div className="mt-2 text-sm text-main">
                  <span className="font-semibold">Role Compatibility:</span>{" "}
                  <span className="text-muted">
                    {report.aiSummary.compatibilityScore || "--"} ({report.aiSummary.compatibilityFlag || "N/A"})
                  </span>
                </div>
                <div className="mt-2 text-sm text-main">
                  <span className="font-semibold">Recommendation Class:</span>{" "}
                  <span className="text-muted">{report.aiSummary.recommendationClass || "N/A"}</span>
                </div>
                <div className="mt-2 text-sm text-main">
                  <span className="font-semibold">Response Consistency:</span>{" "}
                  <span className="text-muted">
                    {report.aiSummary.responseConsistencyScore
                      ? `${(Number(report.aiSummary.responseConsistencyScore) * 100).toFixed(2)}%`
                      : "N/A"}
                  </span>
                </div>
              </div>

              {/* Keywords */}
              <div className="mt-4 flex flex-col sm:flex-row sm:items-center gap-3">
                <div className="text-sm font-semibold text-main">Applicant Skills:</div>
                <div className="flex flex-wrap gap-2">
                  {report.aiSummary.keywords.map((k) => (
                    <span key={k} className={chipCls}>{k}</span>
                  ))}
                </div>
              </div>
            </section>

            {/* AI Insights */}
            <section className="mt-6">
              <h2 className={sectionTitleCls}>AI INSIGHTS</h2>
              <div
                className={[
                  "mt-4 rounded-xl p-5 border-l-4",
                  "bg-insight border-insight ring-insight text-insight",
                  "shadow-soft",
                ].join(" ")}
              >
                <p className="text-sm leading-relaxed text-insight">{report.insight}</p>
              </div>
            </section>
          </div>
        </div>
      </main>

      {/* Reject Modal */}
      {showRejectModal && !isAlreadyEndorsed && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <div className="bg-surface rounded-xl p-6 max-w-md w-full shadow-lg">
            <h3 className="text-lg font-bold mb-2">Reject Applicant</h3>
            <p className="mb-4 text-sm text-main">
              Enter a rejection reason. This will be saved and visible in Interviewer Hub.
            </p>
            <textarea
              value={rejectionReason}
              onChange={(e) => setRejectionReason(e.target.value)}
              placeholder="Reason for rejection..."
              className="w-full min-h-[110px] rounded-xl border border-token bg-surface-strong px-3 py-2 text-sm text-main outline-none focus:ring-2 focus:ring-[#2F8DCD]/30"
            />
            <div className="mt-4 flex justify-end gap-3">
              <button
                className="px-4 py-2 rounded-lg text-sm border border-gray-300 hover:bg-gray-100 transition"
                onClick={() => setShowRejectModal(false)}
              >
                Cancel
              </button>
              <button
                className="px-4 py-2 rounded-lg text-sm bg-red-600 text-white font-semibold hover:bg-red-700 transition"
                onClick={async () => {
                  const ok = await handleReject();
                  if (!ok) return;
                  setShowRejectModal(false);
                  navigate("/recruiter/interviewer-hub/");
                }}
              >
                Confirm Reject
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Endorse Modal */}
      {showEndorseModal && (
        <Modal
          title="Confirm Endorse"
          message={`This action will endorse this applicant to the next hiring step. Are you sure you want to proceed?`}
          onConfirm={async () => {
            if (isAlreadyEndorsed) {
              setShowEndorseModal(false);
              return;
            }
            setShowEndorseModal(false);

            // Generate PDF and send to server / CEO
            const filePath = await handleExportPDF(true);
            if (filePath) {
              setReportData((prev) => ({ ...prev, status: "endorsed" }));
              alert("Report has been sent to the CEO successfully. Status updated to Endorsed.");
            } else {
              alert("Failed to send report. Please try again.");
            }
          }}
          onCancel={() => setShowEndorseModal(false)}
        />
      )}

      {/* No Report Modal */}
      {showNoReportModal && (
        <Modal
          title="No Report Generated"
          message="No report has been generated yet."
          onConfirm={() => navigate(-1)}
        />
      )}
    </div>
  );
}

function InfoPill({ label, value }) {
  const pillCls = [
    "rounded-xl",
    "bg-surface-strong backdrop-blur-md",
    "border border-token",
    "shadow-sm px-5 py-3",
  ].join(" ");

  return (
    <div className={pillCls}>
      <div className="text-sm text-main">
        <span className="font-semibold">{label}:</span>{" "}
        <span className="text-muted">{value}</span>
      </div>
    </div>
  );
}

function Modal({ title, message, onConfirm, onCancel }) {
  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
      <div className="bg-surface rounded-xl p-6 max-w-md w-full shadow-lg">
        <h3 className="text-lg font-bold mb-4">{title}</h3>
        <p className="mb-6 text-sm text-main">{message}</p>
        <div className="flex justify-end gap-3">
          <button
            className="px-4 py-2 bg-red-500 text-white rounded-xl hover:bg-red-600"
            onClick={onConfirm}
          >
            Confirm
          </button>
        </div>
      </div>
    </div>
  );
}

