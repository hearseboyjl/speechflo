import Menubar from "../components/Menubar";
import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { apiUrl } from "../api";
import { applyTheme, getSavedTheme } from "../theme";
import { authHeaders, clearSession, getToken } from "../session";

export default function Reports() {
  const navigate = useNavigate();
  const [reports, setReports] = useState([]);

  // Apply saved theme
  useEffect(() => {
    applyTheme(getSavedTheme());
  }, []);

  // Force login if no session detected
  useEffect(() => {
    const token = getToken();
    if (!token) {
      navigate("/recruiter/login");
      return;
    }

    const verifyUser = async () => {
      try {
        const res = await fetch(apiUrl("/auth/me"), {
          headers: authHeaders(),
        });

        if (!res.ok) throw new Error("Unauthorized");

        const data = await res.json();
        localStorage.setItem("user", data.firstName || "User");
      } catch (err) {
        clearSession();
        navigate("/recruiter/login");
      }
    };

    verifyUser();
  }, [navigate]);

  // Fetch completed + endorsed applications
  useEffect(() => {
    const fetchCompletedApplications = async () => {
      try {
        const res = await fetch(apiUrl("/job-applications/completed"), {
          headers: authHeaders(),
        });
        if (!res.ok) throw new Error(`HTTP error ${res.status}`);
        const data = await res.json();
        

        // convert database status into front-end display
        const formatted = data.map(r => ({
          ...r,
          displayStatus:
            r.status === "completed"
              ? "Completed"
              : r.status === "endorsed"
              ? "Endorsed"
              : r.status,
        }));

        setReports(formatted);
      } catch (err) {
        console.error("Failed to fetch completed job applications:", err);
      }
    };

    fetchCompletedApplications();
  }, []);

  const cardCls = [
    "rounded-2xl",
    "bg-surface backdrop-blur-md",
    "shadow-[0_12px_30px_rgba(15,23,42,0.08)]",
    "shadow-card",
    "hover:shadow-[0_18px_45px_rgba(15,23,42,0.12)]",
    "transition-shadow",
    "border-2 border-token",
  ].join(" ");

  const primaryBtn = [
    "h-9 px-8 rounded-xl",
    "bg-btn-primary font-semibold",
    "shadow-[0_8px_20px_rgba(15,23,42,0.15)]",
    "hover:brightness-95 hover:shadow-[0_12px_28px_rgba(15,23,42,0.2)]",
    "active:translate-y-[1px]",
    "transition-all duration-200",
  ].join(" ");

  const dividerCls = "border-t border-slate-200 dark:border-slate-700/60";

  const statusPillCls = [
    "inline-flex items-center px-3 py-1 rounded-full text-xs font-semibold border",
    "hover:brightness-95 active:translate-y-[1px] transition",
  ].join(" ");

  return (
    <div className="min-h-screen w-full bg-app">
      <Menubar />

      <main className="min-h-screen bg-app layout-main">
        <div className="max-w-[1200px] mx-auto px-8 py-8">
          {/* Header */}
          <div className="flex flex-col md:flex-row md:items-start md:justify-between gap-6">
            <div>
              <h1 className="text-4xl font-bold text-title">Reports</h1>
              <p className="mt-2 text-sm text-muted">
                Review recent interview reports and export insights.
              </p>
            </div>
          </div>

          <section className={`mt-8 p-8 ${cardCls}`}>
            <div className="mt-2">
              {/* table head */}
              <div className="grid grid-cols-4 text-xs font-semibold text-muted px-6">
                <div className="text-center">Candidates</div>
                <div className="text-center">Date</div>
                <div className="text-center">Status</div>
                <div className="text-center">Actions</div>
              </div>

              <div className={`mt-4 ${dividerCls}`} />

              {/* rows */}
              <div className="mt-2 space-y-2">
                {reports.map(r => (
                  <div key={r.id}>
                    <div className="grid grid-cols-4 items-center px-6 py-4">
                      <div className="text-center text-sm font-medium text-main">
                        {r.candidate}
                      </div>

                      <div className="text-center text-sm text-muted">
                        {new Date(r.applied_at).toLocaleDateString()}
                      </div>

                      <div className="text-center">
                        <span className={`${statusPillCls} ${r.status === "endorsed" ? "status-endorsed" : "status-completed"}`}>
                          {r.displayStatus}
                        </span>
                      </div>

                      <div className="text-center">
                      <button
                          onClick={() =>
                            navigate(`/recruiter/reports/${r.id}`, { state: { applicationId: r.id } })
                          }
                          className={primaryBtn}
                    >
                      View
                    </button>
                      </div>
                    </div>

                    <div className={dividerCls} />
                  </div>
                ))}

                {reports.length === 0 && (
                  <div className="px-6 py-10 text-center text-sm text-muted">
                    No completed or endorsed reports yet.
                  </div>
                )}
              </div>
            </div>
          </section>
        </div>
      </main>
    </div>
  );
}
