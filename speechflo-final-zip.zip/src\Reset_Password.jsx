﻿import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { apiUrl } from "./api";

export default function Reset_Password() {
  const navigate = useNavigate();

  // STATE
  const [email, setEmail] = useState("");
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");
  const [loading, setLoading] = useState(false);

  // HELPERS
  const isValidEmail = (value) =>
    /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value);

  // HANDLER
  const handleSendCode = async (e) => {
    e.preventDefault();

    if (loading) return;

    setError("");
    setSuccess("");
    setLoading(true);

    if (!email) {
      setError("Email is required.");
      setLoading(false);
      return;
    }

    if (!isValidEmail(email)) {
      setError("Please enter a valid email address.");
      setLoading(false);
      return;
    }

    try {
      const res = await fetch(apiUrl("/auth/request-reset"), {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email }),
      });

      const data = await res.json();

      if (!res.ok) {
        setError(data.message || "Something went wrong");
        setLoading(false);
        return;
      }

      setSuccess(data.message || "Reset code sent.");
      setTimeout(() => navigate("/confirm-reset"), 1000);

    } catch (err) {
      console.error(err);
      setError("Server error. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div
      className="min-h-screen w-full flex items-center justify-center px-6 relative overflow-hidden"
      style={{
        background:
          "linear-gradient(to bottom right, #abd7f4 0%, #C4D6E3 48%, #4a8fc1 100%)",
      }}
    >
      <div className="absolute inset-0 backdrop-blur-md bg-white/10 z-0" />

      <div className="relative z-10 w-full max-w-5xl grid grid-cols-1 lg:grid-cols-2 rounded-[32px] bg-white/60 backdrop-blur-xl shadow-[0_30px_80px_rgba(15,23,42,0.25)] overflow-hidden">
        
        {/* LEFT */}
        <div className="hidden lg:flex flex-col justify-center p-12">
          <h1 className="text-2xl font-bold text-[#002853]">AvantePH</h1>
          <p className="mt-4 text-slate-600 max-w-sm">
            Enter your email to receive a password reset code.
          </p>
          <img
            src="/Forgot_Password.png"
            alt="Forgot Password"
            className="mt-10 mx-auto w-full max-w-[320px] object-contain drop-shadow-xl"
          />
        </div>

        {/* RIGHT */}
        <div className="p-10 sm:p-12 flex flex-col justify-center">
          <h2 className="text-2xl font-bold text-[#002853] mb-2">
            Reset Password
          </h2>

          <p className="text-sm text-slate-600 mb-8">
            We'll send a verification code to your email.
          </p>

          <div className="space-y-5">
            <div>
              <label className="block text-sm font-semibold text-slate-700 mb-1">
                Email Address
              </label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="Email"
                className="w-full h-11 px-4 rounded-xl bg-white border border-slate-200 outline-none focus:ring-2 focus:ring-[#2F8DCD]/40"
              />
            </div>

            {error && (
              <p className="text-sm text-red-500 text-center">{error}</p>
            )}

            {success && (
              <p className="text-sm text-green-600 text-center">{success}</p>
            )}

            <button
              onClick={handleSendCode}
              disabled={loading}
              className={`w-full h-11 rounded-xl text-white font-semibold transition
                ${loading ? "bg-slate-400 cursor-not-allowed" : "bg-[#2F8DCD] hover:brightness-95"}
              `}
            >
              {loading ? "Sending..." : "Send Code"}
            </button>

            <p
              onClick={() => navigate("/login-applicant")}
              className="text-sm text-center text-slate-600 hover:underline cursor-pointer"
            >
              Back to Login
            </p>
          </div>

          <div className="mt-8 text-center text-s text-slate-400">
            (c) 2026 AvantePH
          </div>
        </div>
      </div>
    </div>
  );
}

