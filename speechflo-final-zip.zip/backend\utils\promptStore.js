import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";
import { db } from "../db.js";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const promptFilePath = path.join(__dirname, "../data/masterprompt.json");

function readPromptFile() {
  const raw = fs.readFileSync(promptFilePath, "utf8");
  return normalizePromptConfig(JSON.parse(raw));
}

function normalizePromptTasks(tasks = {}) {
  return Object.fromEntries(
    Object.entries(tasks || {}).map(([key, value]) => [key, String(value || "")])
  );
}

export function normalizePromptConfig(payload = {}) {
  return {
    master_prompt: String(payload.master_prompt || "").trim(),
    tasks: normalizePromptTasks(payload.tasks || {}),
  };
}

function buildVersionLabel(prefix = "prompt") {
  const stamp = new Date().toISOString().replace(/[:.]/g, "-");
  return `${prefix}-${stamp}`;
}

async function promptTableExists() {
  try {
    const [rows] = await db.query("SHOW TABLES LIKE 'prompt_versions'");
    return rows.length > 0;
  } catch {
    return false;
  }
}

export async function ensureSeedPromptVersion() {
  if (!(await promptTableExists())) {
    return null;
  }

  const [rows] = await db.query("SELECT id FROM prompt_versions LIMIT 1");
  if (rows.length > 0) {
    return rows[0].id;
  }

  const seed = readPromptFile();
  const [result] = await db.query(
    `
    INSERT INTO prompt_versions (
      version_label,
      master_prompt,
      tasks_json,
      notes,
      status,
      published_at
    )
    VALUES (?, ?, ?, ?, 'published', NOW())
    `,
    [
      buildVersionLabel("seed"),
      seed.master_prompt,
      JSON.stringify(seed.tasks),
      "Seeded automatically from backend/data/masterprompt.json",
    ]
  );
  return result.insertId;
}

function parsePromptRow(row) {
  let tasks = {};
  try {
    tasks = row?.tasks_json ? JSON.parse(row.tasks_json) : {};
  } catch {
    tasks = {};
  }

  return {
    id: row.id,
    versionLabel: row.version_label,
    notes: row.notes || "",
    status: row.status,
    createdBy: row.created_by,
    publishedBy: row.published_by,
    createdAt: row.created_at,
    updatedAt: row.updated_at,
    publishedAt: row.published_at,
    master_prompt: String(row.master_prompt || ""),
    tasks: normalizePromptTasks(tasks),
  };
}

export async function getPromptVersions() {
  if (!(await promptTableExists())) {
    return [];
  }

  await ensureSeedPromptVersion();
  const [rows] = await db.query(
    `
    SELECT
      id,
      version_label,
      master_prompt,
      tasks_json,
      notes,
      status,
      created_by,
      published_by,
      created_at,
      updated_at,
      published_at
    FROM prompt_versions
    ORDER BY created_at DESC, id DESC
    `
  );
  return rows.map(parsePromptRow);
}

export async function getPromptVersionById(id) {
  if (!(await promptTableExists())) {
    return null;
  }

  await ensureSeedPromptVersion();
  const [rows] = await db.query(
    `
    SELECT
      id,
      version_label,
      master_prompt,
      tasks_json,
      notes,
      status,
      created_by,
      published_by,
      created_at,
      updated_at,
      published_at
    FROM prompt_versions
    WHERE id = ?
    LIMIT 1
    `,
    [id]
  );
  return rows.length ? parsePromptRow(rows[0]) : null;
}

export async function getActivePromptConfig() {
  if (!(await promptTableExists())) {
    return readPromptFile();
  }

  await ensureSeedPromptVersion();
  const [rows] = await db.query(
    `
    SELECT
      id,
      version_label,
      master_prompt,
      tasks_json,
      notes,
      status,
      created_by,
      published_by,
      created_at,
      updated_at,
      published_at
    FROM prompt_versions
    WHERE status = 'published'
    ORDER BY published_at DESC, id DESC
    LIMIT 1
    `
  );

  if (!rows.length) {
    return readPromptFile();
  }

  const parsed = parsePromptRow(rows[0]);
  return normalizePromptConfig(parsed);
}
