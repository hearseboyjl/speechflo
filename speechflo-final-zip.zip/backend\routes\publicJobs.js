import express from "express";
import { db } from "../db.js";

const router = express.Router();

function mapJobRow(row) {
  return {
    id: row.id,
    title: row.title,
    description: row.description || "",
    companyName: row.company_name || "",
    employmentType: row.employment_type || "",
    workSetup: row.work_setup || "",
    city: row.city || "",
    region: row.region || "",
    isActive: Boolean(row.is_active),
    lifecycleStatus: row.lifecycle_status || (Boolean(row.is_active) ? "published" : "closed"),
    publishedAt: row.published_at || null,
    closedAt: row.closed_at || null,
    archivedAt: row.archived_at || null,
    createdAt: row.created_at,
    updatedAt: row.updated_at,
  };
}

router.get("/", async (_req, res) => {
  try {
    let jobs = [];
    try {
      const [rows] = await db.query(
        `
        SELECT
          id,
          title,
          description,
          company_name,
          employment_type,
          work_setup,
          city,
          region,
          is_active,
          lifecycle_status,
          published_at,
          closed_at,
          archived_at,
          created_at,
          updated_at
        FROM jobs
        WHERE is_active = 1
          AND lifecycle_status = 'published'
        ORDER BY COALESCE(published_at, created_at) DESC, id DESC
        `
      );
      jobs = rows;
    } catch (err) {
      if (err?.code !== "ER_BAD_FIELD_ERROR") throw err;
      const [legacyRows] = await db.query(
        `
        SELECT
          id,
          title,
          description,
          company_name,
          employment_type,
          work_setup,
          city,
          region,
          is_active,
          created_at,
          updated_at
        FROM jobs
        WHERE is_active = 1
        ORDER BY created_at DESC, id DESC
        `
      );
      jobs = legacyRows.map((row) => ({
        ...row,
        lifecycle_status: "published",
        published_at: row.created_at,
        closed_at: null,
        archived_at: null,
      }));
    }

    const [skills] = await db.query(
      `
      SELECT
        job_id,
        skill_name,
        category,
        required,
        weight
      FROM job_skills
      WHERE job_id IS NOT NULL
      ORDER BY job_id ASC, required DESC, weight DESC, skill_name ASC
      `
    );

    const skillsByJobId = new Map();
    skills.forEach((row) => {
      if (!skillsByJobId.has(row.job_id)) {
        skillsByJobId.set(row.job_id, []);
      }
      skillsByJobId.get(row.job_id).push({
        name: row.skill_name,
        category: row.category || "",
        required: Boolean(row.required),
        weight: Number(row.weight ?? 0),
      });
    });

    res.json(
      jobs.map((job) => ({
        ...mapJobRow(job),
        skills: skillsByJobId.get(job.id) || [],
      }))
    );
  } catch (err) {
    console.error("[PublicJobs][list] error:", err);
    res.status(500).json({ message: "Failed to load jobs" });
  }
});

router.get("/:id", async (req, res) => {
  try {
    const jobId = Number(req.params.id);
    if (!Number.isFinite(jobId)) {
      return res.status(400).json({ message: "Invalid job id." });
    }

    let jobs = [];
    try {
      const [rows] = await db.query(
        `
        SELECT
          id,
          title,
          description,
          company_name,
          employment_type,
          work_setup,
          city,
          region,
          is_active,
          lifecycle_status,
          published_at,
          closed_at,
          archived_at,
          created_at,
          updated_at
        FROM jobs
        WHERE id = ?
          AND is_active = 1
          AND lifecycle_status = 'published'
        LIMIT 1
        `,
        [jobId]
      );
      jobs = rows;
    } catch (err) {
      if (err?.code !== "ER_BAD_FIELD_ERROR") throw err;
      const [legacyRows] = await db.query(
        `
        SELECT
          id,
          title,
          description,
          company_name,
          employment_type,
          work_setup,
          city,
          region,
          is_active,
          created_at,
          updated_at
        FROM jobs
        WHERE id = ? AND is_active = 1
        LIMIT 1
        `,
        [jobId]
      );
      jobs = legacyRows.map((row) => ({
        ...row,
        lifecycle_status: "published",
        published_at: row.created_at,
        closed_at: null,
        archived_at: null,
      }));
    }

    if (!jobs.length) {
      return res.status(404).json({ message: "Job not found." });
    }

    const [skills] = await db.query(
      `
      SELECT
        skill_name,
        category,
        required,
        weight
      FROM job_skills
      WHERE job_id = ?
      ORDER BY required DESC, weight DESC, skill_name ASC
      `,
      [jobId]
    );

    res.json({
      ...mapJobRow(jobs[0]),
      skills: skills.map((row) => ({
        name: row.skill_name,
        category: row.category || "",
        required: Boolean(row.required),
        weight: Number(row.weight ?? 0),
      })),
    });
  } catch (err) {
    console.error("[PublicJobs][detail] error:", err);
    res.status(500).json({ message: "Failed to load job detail" });
  }
});

export default router;
