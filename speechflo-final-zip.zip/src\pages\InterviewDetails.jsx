import Menubar from "../components/Menubar";
import { useLocation, useNavigate } from "react-router-dom";
import { apiUrl } from "../api";
import { useEffect, useState, useMemo, useRef } from "react";
import jsPDF from "jspdf";

// color palette
const colors = {
  keyword: "text-indigo-500",
  improvement: "text-rose-500",
  summary: "text-green-600",
  recommendation: "text-yellow-600",
  placeholder: "bg-gray-200/50",
  requiredSkill: "bg-red-500 text-white",
  optionalSkill: "bg-yellow-300 text-black",
};

// highlight keywords from transcript
function HighlightedText({ text, keywords }) {
  if (!text) return null;
  if (!keywords || keywords.length === 0) return <>{text}</>;

  const cleanKeywords = Array.from(
    new Set(
      keywords
        .map((k) => String(k || "").trim())
        .filter(Boolean)
    )
  ).sort((a, b) => b.length - a.length); // prefer longer exact phrases

  if (!cleanKeywords.length) return <>{text}</>;

  const escapeRegex = (value) => value.replace(/[-/\\^$*+?.()|[\]{}]/g, "\\$&");
  const stopwords = new Set([
    "and", "the", "for", "with", "from", "that", "this", "into", "your",
    "have", "has", "are", "was", "were", "will", "can", "able", "using",
    "use", "used", "skill", "skills"
  ]);

  const termSet = new Set();
  cleanKeywords.forEach((skill) => {
    const phrase = skill.trim();
    if (phrase) termSet.add(phrase);

    // Also match meaningful parts of multi-word skills.
    phrase
      .split(/[^a-zA-Z0-9]+/)
      .map((t) => t.trim())
      .filter((t) => t.length >= 4 && !stopwords.has(t.toLowerCase()))
      .forEach((t) => termSet.add(t));
  });

  const terms = Array.from(termSet).sort((a, b) => b.length - a.length);
  const matches = [];

  for (const term of terms) {
    const isSingleToken = !/\s/.test(term);
    const pattern = isSingleToken
      ? `\\b${escapeRegex(term)}(?:s|es|ed|ing)?\\b`
      : escapeRegex(term).replace(/\s+/g, "\\s+");
    const regex = new RegExp(pattern, "gi");
    let m;
    while ((m = regex.exec(text)) !== null) {
      matches.push({ start: m.index, end: m.index + m[0].length });
    }
  }

  // Keep non-overlapping matches based on earliest position and longest phrase.
  matches.sort((a, b) => a.start - b.start || b.end - b.start - (a.end - a.start));
  const picked = [];
  for (const cur of matches) {
    const overlaps = picked.some((p) => cur.start < p.end && cur.end > p.start);
    if (!overlaps) picked.push(cur);
  }
  picked.sort((a, b) => a.start - b.start);

  if (!picked.length) return <>{text}</>;

  const nodes = [];
  let cursor = 0;
  picked.forEach((p, i) => {
    if (cursor < p.start) {
      nodes.push(
        <span key={`t-${i}-${cursor}`}>{text.slice(cursor, p.start)}</span>
      );
    }
    nodes.push(
      <span key={`h-${i}-${p.start}`} className="text-indigo-500 font-semibold">
        {text.slice(p.start, p.end)}
      </span>
    );
    cursor = p.end;
  });
  if (cursor < text.length) {
    nodes.push(<span key={`t-end-${cursor}`}>{text.slice(cursor)}</span>);
  }

  return <>{nodes}</>;
}

// placeholder
const Placeholder = ({ height = "120px", className = "" }) => (
  <div
    className={`animate-pulse ${colors.placeholder} rounded-md ${className}`}
    style={{ height }}
  />
);

// section cards
function SectionCard({ title, children, cardCls, titleCls }) {
  return (
    <section className={`${cardCls} hover:shadow-lg transition-shadow duration-200`}>
      <h2 className={titleCls}>{title}</h2>
      <div className="mt-4">{children}</div>
    </section>
  );
}

function toPlainReason(reasonItem = {}) {
  if (reasonItem.match_level === "partial") {
    return "Partially matched: related evidence was found, but not enough for a full match.";
  }
  if (reasonItem.method === "semantic") {
    if (reasonItem.matched) {
      if (reasonItem.matched_by === "embedding_similarity") {
        return "Matched.";
      }
      if (reasonItem.matched_by === "lexical_support") {
        return "Matched because the candidate explicitly mentioned terms related to this skill.";
      }
      return "Matched based on semantic evidence in the interview transcript.";
    }
    return "Marked missing because no strong semantic or explicit evidence was found.";
  }
  if (reasonItem.method === "heuristic") {
    return reasonItem.matched
      ? "Matched based on direct text overlap with extracted skills."
      : "Marked missing because no clear text overlap was found.";
  }
  if (reasonItem.method === "stored_result") {
    return reasonItem.matched
      ? "Matched based on the latest stored validation result."
      : "Marked missing based on the latest stored validation result.";
  }
  return reasonItem.reason || "No detailed explanation available.";
}

export default function InterviewDetails() {
  const navigate = useNavigate();
  const sanitizeFileToken = (value = "") =>
    String(value || "")
      .trim()
      .replace(/[^a-z0-9]+/gi, "-")
      .replace(/^-+|-+$/g, "")
      .toLowerCase();

  //export button handler
const handleExport = async () => {
  try {
    const reportData = {
      applicationId,
      applicantId: interview.applicantId,
      applicantName: candidate,
      jobTitle: role,
      recruiterName: localStorage.getItem("user") || "",
      date: new Date().toLocaleDateString(),
      skills,
      summary,
      recommendation,
      parsedSkills,
      sentiment,
      confidence,
      areasForImprovement,
    };

    const res = await fetch(apiUrl("/reports/generate"), {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${localStorage.getItem("token")}`,
      },
      body: JSON.stringify(reportData),
    });

    const data = await res.json();
    if (!res.ok) throw new Error(data.error || "Failed to export report");

    alert(data.message); // show popup message

  } catch (err) {
    console.error("Error exporting report:", err);
    alert("Failed to export report");
  }
};

const handleRerunAnalysis = async () => {
  if (!applicationId) return;
  if (rerunFile && !interview?.applicantId) {
    alert("Cannot re-upload file because applicantId is missing for this interview record.");
    return;
  }

  setRerunning(true);
  setRerunProgress({
    percent: 10,
    stage: rerunFile ? "Uploading selected interview audio..." : "Re-running interview analysis...",
  });

  try {
    const token = localStorage.getItem("token");
    const headers = { Authorization: `Bearer ${token}` };

    if (rerunFile) {
      const formData = new FormData();
      formData.append("audio", rerunFile);
      formData.append("applicationId", String(applicationId));
      formData.append("applicantId", String(interview.applicantId));
      formData.append("transcriptionLanguage", rerunTranscriptionLanguage);

      const uploadRes = await fetch(apiUrl("/transcribe/upload-audio"), {
        method: "POST",
        headers,
        body: formData,
      });

      if (!uploadRes.ok) {
        const txt = await uploadRes.text();
        throw new Error(txt || "Failed to upload replacement audio");
      }
    } else {
      const rerunRes = await fetch(
        apiUrl(`/transcribe/rerun-analysis/${applicationId}`),
        { method: "POST", headers }
      );
      if (!rerunRes.ok) {
        const txt = await rerunRes.text();
        throw new Error(txt || "Failed to re-run analysis");
      }
    }

    setRerunProgress({ percent: 70, stage: "Validating role compatibility..." });

    const validateRes = await fetch(
      apiUrl(`/api/validate-skills/${applicationId}?roleNameFront=${encodeURIComponent(role || "")}`),
      { method: "GET", headers }
    );
    if (!validateRes.ok) {
      const txt = await validateRes.text();
      throw new Error(txt || "Failed to re-run skill validation");
    }

    setRerunProgress({ percent: 85, stage: "Refreshing analysis results..." });

    const analysisRes = await fetch(
      apiUrl(`/transcribe/get-skills/${applicationId}`),
      { headers }
    );
    if (analysisRes.ok) {
      const data = await analysisRes.json();
      setSkills(Array.isArray(data.skills) ? data.skills : []);
      setSummary(data.summary || "");
      setAreasForImprovement(data.areasForImprovement || "");
      setRecommendation(data.recommendation || "");
      setSentiment(data.sentiment || "");
      setConfidence(Number(data.confidence ?? 0));
    }

    const parsedRes = await fetch(
      apiUrl(`/api/parsed/${applicationId}`),
      { headers }
    );
    if (parsedRes.ok) {
      const data = await parsedRes.json();
      setParsedSkills(data);
    }

    setRerunProgress({ percent: 100, stage: "Finalizing analysis..." });
    setRerunFile(null);
  } catch (err) {
    console.error("[Re-run Analysis] error:", err);
    alert("Failed to re-run analysis. Check server logs.");
  } finally {
    setRerunning(false);
  }
};

const handleDownloadTranscript = () => {
  const text = String(transcript || "").trim();
  if (!text) {
    alert("No transcript available to download yet.");
    return;
  }

  const namePart = sanitizeFileToken(candidate || "candidate");
  const appPart = Number.isFinite(Number(applicationId)) ? `app-${applicationId}` : "application";
  const fileName = `transcript-${appPart}-${namePart || "candidate"}.pdf`;

  const doc = new jsPDF({ orientation: "portrait", unit: "pt", format: "a4" });
  const pageWidth = doc.internal.pageSize.getWidth();
  const pageHeight = doc.internal.pageSize.getHeight();
  const margin = 44;
  const contentWidth = pageWidth - margin * 2;
  const lineHeight = 15;
  let y = margin;

  const ensureSpace = (requiredHeight = lineHeight) => {
    if (y + requiredHeight <= pageHeight - margin) return;
    doc.addPage();
    y = margin;
  };

  const writeWrapped = (value, fontSize = 11) => {
    const safeText = String(value || "");
    if (!safeText) return;
    doc.setFontSize(fontSize);
    const lines = doc.splitTextToSize(safeText, contentWidth);
    lines.forEach((line) => {
      ensureSpace(lineHeight);
      doc.text(line, margin, y);
      y += lineHeight;
    });
  };

  doc.setFont("helvetica", "bold");
  writeWrapped("SpeechFlo Interview Transcript", 16);
  y += 6;

  doc.setFont("helvetica", "normal");
  writeWrapped(`Application: ${applicationId || "--"}`);
  writeWrapped(`Candidate: ${candidate || "--"}`);
  writeWrapped(`Role: ${role || "--"}`);
  writeWrapped(`Interview Date: ${interviewDate || "--"}`);
  writeWrapped(`Interviewer: ${interviewer || "--"}`);
  writeWrapped(`Generated: ${new Date().toLocaleString()}`);

  y += 10;
  doc.setFont("helvetica", "bold");
  writeWrapped("Transcript", 13);
  y += 4;

  doc.setFont("helvetica", "normal");
  const paragraphs = text.split(/\r?\n/);
  paragraphs.forEach((paragraph) => {
    if (!paragraph.trim()) {
      ensureSpace(lineHeight);
      y += lineHeight;
      return;
    }
    writeWrapped(paragraph, 11);
  });

  doc.save(fileName);
};

  // force user to login if no session is detected
  useEffect(() => {
    const token = localStorage.getItem("token");
    if (!token) {
      navigate("/recruiter/login");
      return;
    }
    const verifyUser = async () => {
      try {
        const res = await fetch(apiUrl("/auth/me"), {
          headers: { Authorization: `Bearer ${token}` },
        });
        if (!res.ok) throw new Error("Unauthorized");
      } catch (err) {
        console.error("Authentication failed:", err);
        localStorage.removeItem("token");
        localStorage.removeItem("user");
        navigate("/recruiter/login");
      }
    };
    verifyUser();
  }, [navigate]);

  const { state } = useLocation();
  const interview = state?.interview || {};
  const {
    id: applicationId,
    date: interviewDate = "2025-09-15",
    interviewer = "",
    candidate,
    role,
  } = interview;

  const [transcript, setTranscript] = useState("");
  const [loadingTranscript, setLoadingTranscript] = useState(false);
  const [skills, setSkills] = useState([]);
  const [summary, setSummary] = useState("");
  const [areasForImprovement, setAreasForImprovement] = useState("");
  const [recommendation, setRecommendation] = useState("");
  const [kbRoles, setKbRoles] = useState([]);
  const [expectedSkills, setExpectedSkills] = useState([]);

  // NEW: sentiment and confidence
  const [sentiment, setSentiment] = useState("");
  const [confidence, setConfidence] = useState(0);
  const [rerunning, setRerunning] = useState(false);
  const [showRerunModal, setShowRerunModal] = useState(false);
  const [rerunFile, setRerunFile] = useState(null);
  const [rerunTranscriptionLanguage, setRerunTranscriptionLanguage] = useState("taglish");
  const [rerunProgress, setRerunProgress] = useState({
    percent: 0,
    stage: "Preparing analysis...",
  });
  const rerunFileRef = useRef(null);

  // ---------- SET EXPECTED SKILLS BASED ON ROLE ----------
  useEffect(() => {
    if (!kbRoles.length || !role) return;
    const roleObj = kbRoles.find((r) => r.name === role);
    setExpectedSkills(roleObj?.skills || []);
  }, [kbRoles, role]);

  // Add logs inside fetchAnalysis and fetchTranscript to inspect data
  useEffect(() => {
    if (!applicationId) return;
    const fetchTranscript = async () => {
      setLoadingTranscript(true);
      try {
        const res = await fetch(apiUrl(`/transcribe/get-transcript/${applicationId}`), {
          headers: { Authorization: `Bearer ${localStorage.getItem("token")}` },
        });
        if (!res.ok) throw new Error("Transcript not found");
        const data = await res.json();
        setTranscript(data.transcript || "");
      } catch (err) {
        console.error("[Transcript] error:", err);
      } finally {
        setLoadingTranscript(false);
      }
    };
    fetchTranscript();
  }, [applicationId]);

  useEffect(() => {
    if (!applicationId) return;
    const fetchAnalysis = async () => {
      try {
        const res = await fetch(apiUrl(`/transcribe/get-skills/${applicationId}`), {
          headers: { Authorization: `Bearer ${localStorage.getItem("token")}` },
        });
        if (!res.ok) throw new Error("Analysis not found");
        const data = await res.json();
        setSkills(Array.isArray(data.skills) ? data.skills : []);
        setSummary(data.summary || "");
        setAreasForImprovement(data.areasForImprovement || "");
        setRecommendation(data.recommendation || "");

        // SET SENTIMENT AND CONFIDENCE
        setSentiment(data.sentiment || "");
        setConfidence(Number(data.confidence ?? 0));
      } catch (err) {
        console.error("[Analysis] error:", err);
      }
    };
    fetchAnalysis();
  }, [applicationId]);

  // ---------- PER-SKILL VALIDATION ----------
  const [parsedSkills, setParsedSkills] = useState({
    matched_skills: [],
    partial_skills: [],
    missing_skills: [],
    weighted_score: 0,
    compatibility_score: null,
    compatibility_flag: null,
    recommendation_class: null,
    confidence_flag: "OK",
    response_consistency_score: null,
    resume_consistency_score: null,
    resume_consistency_flag: "Insufficient Data",
    resume_consistency_details: {},
    components: null,
    reasoning: [],
    validation_method: null,
  });

  useEffect(() => {
    if (!applicationId) return;

    const fetchParsedSkills = async () => {
      try {
        let res = await fetch(apiUrl(`/api/parsed/${applicationId}`), {
          headers: { Authorization: `Bearer ${localStorage.getItem("token")}` },
        });

        if (!res.ok) {
          // Try generating validation once, then re-fetch parsed result.
          const genRes = await fetch(
            apiUrl(`/api/validate-skills/${applicationId}?roleNameFront=${encodeURIComponent(role || "")}`),
            {
              method: "GET",
              headers: { Authorization: `Bearer ${localStorage.getItem("token")}` },
            }
          );
          if (!genRes.ok) {
            const txt = await genRes.text();
            console.error("[SkillValidation Parsed] generation failed:", txt);
            return;
          }

          res = await fetch(apiUrl(`/api/parsed/${applicationId}`), {
            headers: { Authorization: `Bearer ${localStorage.getItem("token")}` },
          });
          if (!res.ok) {
            const txt = await res.text();
            console.error("[SkillValidation Parsed] fetch failed after generation:", txt);
            return;
          }
        }

        const data = await res.json();
        setParsedSkills(data);
      } catch (err) {
        console.error("[SkillValidation Parsed] error:", err);
      }
    };

    fetchParsedSkills();
  }, [applicationId, role]);

  // weighted score calculation
  function getWeightedScoreInfo(score) {
    if (score >= 0.7) return { label: "Excellent", color: "bg-indigo-500 text-white" };
    if (score >= 0.5) return { label: "Good", color: "bg-green-400 text-black" };
    if (score >= 0.35) return { label: "Moderate", color: "bg-yellow-400 text-white" };
    return { label: "Weak", color: "bg-red-500 text-white" };
  }

  function getCompatibilityInfo(flag) {
    if (flag === "High") return { color: "bg-green-600 text-white" };
    if (flag === "Moderate") return { color: "bg-yellow-500 text-black" };
    if (flag === "Low") return { color: "bg-red-600 text-white" };
    return { color: "bg-gray-400 text-white" };
  }

  // ---------- METRICS ----------
  const metrics = useMemo(() => {
    const totalExpectedSkills = expectedSkills.length;
    const mentionedSkills = skills.filter(s => !!s).length;

    const improvementList = areasForImprovement
      ? areasForImprovement
          .split(/\n|(?<=[.?!])\s+/)
          .map(item => item.trim())
          .filter(Boolean)
      : [];

    return {
      wordsSpoken: transcript ? transcript.trim().split(/\s+/).length : 0,
      fillerWords: transcript
        ? (transcript.match(/\b(um|uh|like|you know)\b/gi) || []).length
        : 0,
      skillsMentioned: mentionedSkills,
      areasOfImprovement: improvementList.length,
      sentiment: sentiment || "N/A",
      confidence: confidence || 0,
    };
  }, [skills, expectedSkills, transcript, areasForImprovement, parsedSkills.weighted_score, sentiment, confidence]);

  // ---------- UI CLASSES ----------
  const pageBg = "bg-app-bloom";
  const titleCls = "text-3xl font-bold text-title";
  const metaCls = "mt-1 text-xs text-muted";
  const metaStrong = "font-medium text-main";
  const cardBase = "rounded-2xl backdrop-blur-md border border-token shadow-soft p-6 pb-7";
  const leftCardCls = `${cardBase} bg-surface`;
  const rightCardCls = `${cardBase} bg-white ring-1 ring-white/15 text-black`;
  const sectionTitleLeft = "text-lg font-semibold text-title";
  const sectionTitleRight = "text-lg font-semibold text-title";
  const btnBase = "font-semibold shadow-card hover:brightness-95 active:translate-y-[1px] transition";
  const primaryBtn = `h-9 px-5 rounded-xl bg-btn-primary text-white border border-white/25 ${btnBase}`;
  const secondaryBtn = `h-9 px-4 rounded-md bg-btn-primary text-white border border-white/20 shadow-soft hover:brightness-95 active:translate-y-[1px] transition`;
  const ghostBtn = "h-9 px-4 rounded-md bg-white text-slate-800 border border-slate-300 shadow-sm hover:bg-slate-50 active:translate-y-[1px] transition";
  const infoBtn = "h-9 px-4 rounded-lg bg-gradient-to-r from-[#e8f3fc] to-white text-[#1b5d85] border border-[#9cc5e1] shadow-sm hover:from-[#dceefe] hover:to-[#f7fbff] active:translate-y-[1px] transition font-semibold";
  const subtleActionBtn = "h-9 px-4 rounded-lg bg-white text-[#255f87] border border-[#bad6ea] shadow-sm hover:bg-[#f4faff] hover:border-[#8fbad8] active:translate-y-[1px] transition font-semibold";
  const strongActionBtn = "h-9 px-4 rounded-lg bg-gradient-to-r from-[#2F8DCD] to-[#256fa1] text-white border border-[#2A7CB3] shadow-md hover:brightness-95 active:translate-y-[1px] transition font-semibold";
  const selectBtn =
    "h-9 px-3 rounded-lg bg-white text-[#255f87] border border-[#bad6ea] shadow-sm " +
    "focus:outline-none focus:ring-2 focus:ring-[#2F8DCD]/30";

  return (
    <div className={`min-h-screen w-full ${pageBg}`}>
      <Menubar />
      <main className={`min-h-screen ${pageBg} layout-main`}>
        <div className="max-w-[1200px] mx-auto px-10 py-10">
          {/* Header */}
          <div className="flex items-start justify-between gap-6">
            <div>
              <h1 className={titleCls}>
                Interview Details{candidate ? ` - ${candidate}` : ""}
              </h1>
              <p className={metaCls}>
                Date: <span className={metaStrong}>{interviewDate}</span> | Interviewer: <span className={metaStrong}>{interviewer}</span>
              </p>
            </div>
            <div className="flex items-center gap-3">
              <button
                type="button"
                onClick={() => navigate("/recruiter/help/metrics")}
                className={infoBtn}
              >
                Open Help Center
              </button>
              <button type="button" onClick={() => navigate(-1)} className={primaryBtn}>
                Back
              </button>
            </div>
          </div>
          {/* Main Grid */}
          <div className="mt-8 grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* LEFT */}
            <div className="lg:col-span-2 space-y-6">
              <SectionCard title="Transcript" cardCls={leftCardCls} titleCls={sectionTitleLeft}>
                <div className="mb-3 flex justify-end">
                  <button
                    type="button"
                    onClick={handleDownloadTranscript}
                    className={subtleActionBtn}
                    disabled={loadingTranscript || !transcript}
                  >
                    Download Transcript (PDF)
                  </button>
                </div>
                {transcript ? (
                  <pre className="whitespace-pre-wrap text-sm text-main max-h-[300px] overflow-y-auto">
                    <HighlightedText text={transcript} keywords={skills.map((s) => s?.toLowerCase())} />
                  </pre>
                ) : (
                  <Placeholder height="140px" />
                )}
              </SectionCard>

              <SectionCard title="Skills Extracted from Interview" cardCls={leftCardCls} titleCls={sectionTitleLeft}>
                {skills.length ? (
                  <div className="flex flex-wrap gap-2">
                    {skills.map((skill, idx) => (
                      <span key={idx} className="bg-indigo-100 text-indigo-700 px-3 py-1 rounded-full text-xs font-semibold">
                        {skill}
                      </span>
                    ))}
                  </div>
                ) : (
                  <Placeholder height="110px" />
                )}
              </SectionCard>

              <SectionCard title="Summary" cardCls={leftCardCls} titleCls="text-lg font-semibold text-yellow-500">
                {(summary || areasForImprovement) ? (
                  <div className="space-y-5 text-black">
                    {summary && (
                      <ul className="list-disc list-inside text-sm space-y-2">
                        {summary.split(/\n|(?<=[.?!])\s+/).map((sentence, idx) =>
                          sentence.trim() ? <li key={idx}>{sentence.trim()}</li> : null
                        )}
                      </ul>
                    )}
                    {areasForImprovement && (
                      <div>
                        <h3 className="font-semibold mb-2 text-red-500">Areas for Improvement:</h3>
                        <ul className="list-disc list-inside text-sm space-y-2">
                          {areasForImprovement.split(/\n|(?<=[.?!])\s+/).map((item, idx) =>
                            item.trim() ? <li key={idx}>{item.trim()}</li> : null
                          )}
                        </ul>
                      </div>
                    )}
                  </div>
                ) : (
                  <Placeholder height="190px" />
                )}
              </SectionCard>
            </div>

            {/* RIGHT */}
            <div className="space-y-6">
              <SectionCard title="Metrics" cardCls={rightCardCls} titleCls={sectionTitleRight}>
                <div className="space-y-2 text-sm">
                  <div>Words spoken: {metrics.wordsSpoken}</div>
                  <div>Filler words: {metrics.fillerWords}</div>
                  <div>Skills mentioned: {metrics.skillsMentioned}</div>
                  <div>Sentiment: {metrics.sentiment}</div>
                  <div>Speech confidence (0-1): {metrics.confidence.toFixed(2)}</div>
                  <div>Areas for improvement: {metrics.areasOfImprovement}</div>
                  <div className="flex items-center gap-2">
                    Weighted Score: {parsedSkills.weighted_score?.toFixed(2) || 0}
                    <span className={`px-2 py-0.5 text-xs font-semibold rounded-full ${getWeightedScoreInfo(parsedSkills.weighted_score).color}`}>
                      {getWeightedScoreInfo(parsedSkills.weighted_score).label}
                    </span>
                  </div>
                  <div className="flex items-center gap-2">
                    Compatibility: {parsedSkills.compatibility_score ?? "--"}
                    <span className={`px-2 py-0.5 text-xs font-semibold rounded-full ${getCompatibilityInfo(parsedSkills.compatibility_flag).color}`}>
                      {parsedSkills.compatibility_flag || "N/A"}
                    </span>
                  </div>
                  <div>Recommendation class: {parsedSkills.recommendation_class || "N/A"}</div>
                  <div>Analysis confidence flag: {parsedSkills.confidence_flag || "OK"}</div>
                  <div>
                    Response consistency: {parsedSkills.response_consistency_score != null
                      ? `${(Number(parsedSkills.response_consistency_score) * 100).toFixed(2)}%`
                      : parsedSkills.components?.responseConsistency != null
                      ? `${Number(parsedSkills.components.responseConsistency).toFixed(2)}%`
                      : "N/A"}
                  </div>
                  <div>
                    Resume consistency: {parsedSkills.resume_consistency_score != null
                      ? `${(Number(parsedSkills.resume_consistency_score) * 100).toFixed(2)}%`
                      : "N/A"}
                  </div>
                  <div>Resume consistency flag: {parsedSkills.resume_consistency_flag || "Insufficient Data"}</div>
                  <div>
                    Resume skill alignment: {parsedSkills.resume_consistency_details?.skill_alignment_score != null
                      ? `${(Number(parsedSkills.resume_consistency_details.skill_alignment_score) * 100).toFixed(2)}%`
                      : "N/A"}
                  </div>
                  <div>
                    Resume experience consistency: {parsedSkills.resume_consistency_details?.experience_consistency_score != null
                      ? `${(Number(parsedSkills.resume_consistency_details.experience_consistency_score) * 100).toFixed(2)}%`
                      : "N/A"}
                  </div>
                  <div>Hard contradictions: {parsedSkills.resume_consistency_details?.hard_contradiction_count ?? 0}</div>
                  <div>Soft gaps: {parsedSkills.resume_consistency_details?.soft_gap_count ?? 0}</div>
                  <div className="text-xs text-gray-600">
                    Tip: Higher percentage means the candidate was more consistent across answers.
                  </div>
                </div>

                <div className="mt-3 w-full bg-white/20 rounded-full h-3">
                  <div
                    className="bg-indigo-500 h-3 rounded-full transition-all duration-300"
                    style={{ width: `${(parsedSkills.weighted_score || 0) * 100}%` }}
                  ></div>
                </div>
              </SectionCard>

              <SectionCard title="SpeechFlo AI Skill Validation" cardCls={rightCardCls} titleCls={sectionTitleLeft}>
                <div className="mb-3 text-xs text-gray-600">
                  Validation method: <span className="font-semibold">{parsedSkills.validation_method || "N/A"}</span>
                </div>
                <div className="mt-2">
                  <h3 className="font-semibold text-indigo-700">Matched Skills:</h3>
                  <div className="flex flex-wrap gap-2 mt-1">
                    {parsedSkills.matched_skills.map((skill, idx) => (
                      <span key={idx} className="px-2 py-1 text-xs font-semibold rounded-full bg-green-100 text-green-800">{skill}</span>
                    ))}
                  </div>
                </div>

                <div className="mt-4">
                  <h3 className="font-semibold text-indigo-700">Partial Skills:</h3>
                  <div className="flex flex-wrap gap-2 mt-1">
                    {(parsedSkills.partial_skills || []).map((skill, idx) => (
                      <span key={idx} className="px-2 py-1 text-xs font-semibold rounded-full bg-yellow-100 text-yellow-800">{skill}</span>
                    ))}
                  </div>
                </div>

                <div className="mt-4">
                  <h3 className="font-semibold text-indigo-700">Missing Skills:</h3>
                  <div className="flex flex-wrap gap-2 mt-1">
                    {parsedSkills.missing_skills.map((skill, idx) => (
                      <span key={idx} className="px-2 py-1 text-xs font-semibold rounded-full bg-red-100 text-red-800">{skill}</span>
                    ))}
                  </div>
                </div>

                <div className="mt-5">
                  <h3 className="font-semibold text-indigo-700">Validation Reasoning:</h3>
                  <p className="mt-1 text-xs text-gray-600">
                    Plain-language explanation of why each role skill was marked matched or missing.
                  </p>
                  {Array.isArray(parsedSkills.reasoning) && parsedSkills.reasoning.length > 0 ? (
                    <div className="mt-2 max-h-[220px] overflow-y-auto space-y-2">
                      {parsedSkills.reasoning.map((r, idx) => (
                        <div key={idx} className="border border-gray-200 rounded-md p-2 text-xs bg-white">
                          <div className="font-semibold text-black">
                            {r.skill_name} - {r.match_level === "partial" ? "Partial" : r.matched ? "Matched" : "Missing"}
                          </div>
                          <div className="text-gray-700 mt-1">
                            <span className="font-semibold">KB Skill:</span> {r.kb_skill || r.skill_name}
                          </div>
                          <div className="text-gray-700">
                            <span className="font-semibold">Candidate said:</span>{" "}
                            {r.candidate_evidence_text ? `"${r.candidate_evidence_text}"` : "No clear statement found."}
                          </div>
                          <div className="text-gray-700">{toPlainReason(r)}</div>
                          <div className="text-gray-500 mt-1">
                            Required: {r.required ? "Yes" : "No"} | Critical: {r.is_critical ? "Yes" : "No"}
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-xs text-gray-500 mt-2">No reasoning logs available yet.</div>
                  )}
                </div>

                <div className="mt-5">
                  <h3 className="font-semibold text-indigo-700">Resume Cross-check Evidence (V2):</h3>
                  <p className="mt-1 text-xs text-gray-600">
                    Claim-level comparison between uploaded resume and applicant interview statements.
                  </p>
                  {Array.isArray(parsedSkills.resume_consistency_details?.claim_checks) &&
                  parsedSkills.resume_consistency_details.claim_checks.length > 0 ? (
                    <div className="mt-2 max-h-[220px] overflow-y-auto space-y-2">
                      {parsedSkills.resume_consistency_details.claim_checks.slice(0, 25).map((c, idx) => (
                        <div key={`${c.type}-${c.claim_key}-${idx}`} className="border border-gray-200 rounded-md p-2 text-xs bg-white">
                          <div className="font-semibold text-black">
                            [{String(c.type || "").toUpperCase()}] {c.claim_key || "claim"} - {c.status || "unknown"}
                          </div>
                          <div className="text-gray-700 mt-1">
                            <span className="font-semibold">Resume evidence:</span>{" "}
                            {c.resume_evidence_text ? `"${c.resume_evidence_text}"` : "None"}
                          </div>
                          <div className="text-gray-700">
                            <span className="font-semibold">Transcript evidence:</span>{" "}
                            {c.transcript_evidence_text ? `"${c.transcript_evidence_text}"` : "None"}
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-xs text-gray-500 mt-2">No claim-level checks available.</div>
                  )}
                </div>
              </SectionCard>

              <SectionCard title="Recommended Next Step" cardCls={rightCardCls} titleCls="text-lg font-semibold text-green-600">
                {recommendation ? (
                  <div className="text-sm text-black whitespace-pre-wrap">{recommendation}</div>
                ) : (
                  <Placeholder height="120px" className="bg-white/10" />
                )}

                <div className="mt-5 flex flex-wrap gap-3">
                  <select
                    value={rerunTranscriptionLanguage}
                    onChange={(e) => setRerunTranscriptionLanguage(e.target.value)}
                    className={selectBtn}
                    disabled={rerunning}
                    title="Transcription language"
                  >
                    <option value="taglish">Taglish (Recommended)</option>
                    <option value="auto">Auto-detect language</option>
                    <option value="en">English</option>
                    <option value="tl">Filipino / Tagalog</option>
                  </select>
                  <input
                    ref={rerunFileRef}
                    type="file"
                    accept="audio/*,video/*"
                    onChange={(e) => setRerunFile(e.target.files?.[0] || null)}
                    className="hidden"
                  />
                  <button
                    type="button"
                    onClick={() => rerunFileRef.current?.click()}
                    className={subtleActionBtn}
                    disabled={rerunning}
                  >
                    {rerunFile ? "Change Audio File" : "Select Audio for Re-run"}
                  </button>
                  <button
                    type="button"
                    onClick={() => setShowRerunModal(true)}
                    className={strongActionBtn}
                    disabled={rerunning}
                  >
                    {rerunning ? "Re-running..." : "Re-run Analysis"}
                  </button>
                  <button type="button" onClick={handleExport} className={secondaryBtn}>
                    Export Report
                  </button>
                </div>
                {rerunFile && (
                  <p className="mt-2 text-xs text-gray-700">
                    Selected file: <span className="font-semibold">{rerunFile.name}</span>
                  </p>
                )}
              </SectionCard>
            </div>
          </div>
        </div>
      </main>
      {showRerunModal && (
        <ConfirmModal
          title="Confirm Re-run Analysis"
          message="This action will consume additional AI resources (transcript analysis + skill validation). Do you want to continue?"
          onConfirm={async () => {
            setShowRerunModal(false);
            await handleRerunAnalysis();
          }}
          onCancel={() => setShowRerunModal(false)}
        />
      )}
      {rerunning && (
        <AnalysisProgressModal
          title="Analyzing interview"
          stage={rerunProgress.stage}
          percent={rerunProgress.percent}
        />
      )}
    </div>
  );
}

function AnalysisProgressModal({ title, stage, percent }) {
  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
      <div className="bg-white rounded-xl p-6 max-w-md w-full shadow-lg border border-gray-200">
        <h3 className="text-lg font-bold mb-2 text-black">{title}</h3>
        <p className="text-sm text-gray-700">{stage}</p>
        <div className="mt-4 w-full bg-gray-200 rounded-full h-3 overflow-hidden">
          <div
            className="h-3 bg-blue-600 transition-all duration-300"
            style={{ width: `${percent}%` }}
          />
        </div>
        <p className="text-xs text-gray-600 mt-2">{percent}%</p>
      </div>
    </div>
  );
}

function ConfirmModal({ title, message, onConfirm, onCancel }) {
  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
      <div className="bg-white rounded-xl p-6 max-w-md w-full shadow-lg border border-gray-200">
        <h3 className="text-lg font-bold mb-3 text-black">{title}</h3>
        <p className="text-sm text-gray-700">{message}</p>
        <div className="mt-5 flex justify-end gap-3">
          <button
            type="button"
            onClick={onCancel}
            className="px-4 py-2 rounded-md border border-gray-300 text-gray-700 hover:bg-gray-50"
          >
            Cancel
          </button>
          <button
            type="button"
            onClick={onConfirm}
            className="px-4 py-2 rounded-md bg-blue-600 text-white hover:bg-blue-700"
          >
            Continue
          </button>
        </div>
      </div>
    </div>
  );
}

