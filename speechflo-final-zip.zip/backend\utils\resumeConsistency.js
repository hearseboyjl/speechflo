import mammoth from "mammoth";
import { PDFParse } from "pdf-parse";

const SUPPORTED_MIME_TYPES = new Set([
  "application/pdf",
  "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
]);

function normalizeWhitespace(text = "") {
  return String(text || "")
    .replace(/\r/g, "\n")
    .replace(/\u00a0/g, " ")
    .replace(/[ \t]+/g, " ")
    .replace(/\n{3,}/g, "\n\n")
    .trim();
}

function tokenize(text = "") {
  return String(text || "")
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, " ")
    .trim()
    .split(" ")
    .filter(Boolean);
}

function escapeRegex(value = "") {
  return String(value || "").replace(/[-/\\^$*+?.()|[\]{}]/g, "\\$&");
}

function findEvidenceLine(sourceText = "", phrase = "") {
  const source = String(sourceText || "");
  const target = String(phrase || "").trim();
  if (!source || !target) return "";

  const lines = source
    .split(/\r?\n/)
    .map((line) => line.trim())
    .filter(Boolean);

  const lowerTarget = target.toLowerCase();
  for (const line of lines) {
    if (line.toLowerCase().includes(lowerTarget)) return line.slice(0, 280);
  }

  const targetTokens = tokenize(target).filter((t) => t.length >= 4);
  if (!targetTokens.length) return "";
  for (const line of lines) {
    const lineTokens = tokenize(line);
    const shared = targetTokens.filter((t) => lineTokens.includes(t)).length;
    if (
      (targetTokens.length === 1 && shared === 1) ||
      (targetTokens.length === 2 && shared === 2) ||
      (targetTokens.length >= 3 && shared / targetTokens.length >= 0.67)
    ) {
      return line.slice(0, 280);
    }
  }
  return "";
}

function hasSkillMention(text = "", skill = "") {
  const source = String(text || "").toLowerCase();
  const phrase = String(skill || "").trim().toLowerCase();
  if (!source || !phrase) return false;

  const phraseRegex = new RegExp(
    `\\b${escapeRegex(phrase).replace(/\s+/g, "\\s+")}\\b`,
    "i"
  );
  if (phraseRegex.test(source)) return true;

  const skillTokens = tokenize(phrase).filter((t) => t.length >= 4);
  if (!skillTokens.length) return false;
  const sourceTokens = tokenize(source);
  const shared = skillTokens.filter((t) => sourceTokens.includes(t)).length;
  if (skillTokens.length === 1) return shared === 1;
  if (skillTokens.length === 2) return shared === 2;
  return shared / skillTokens.length >= 0.67;
}

function extractYears(text = "") {
  return Array.from(
    new Set(
      (String(text || "").match(/\b(\d{1,2})\s+years?\b/gi) || [])
        .map((m) => Number((m.match(/\d{1,2}/) || [])[0]))
        .filter((n) => Number.isFinite(n))
    )
  );
}

function getApplicantOnlyText(transcript = "") {
  const source = String(transcript || "");
  if (!source) return "";
  const applicantLines = source
    .split(/\r?\n/)
    .map((line) => line.trim())
    .filter((line) => /^Applicant:/i.test(line))
    .map((line) => line.replace(/^Applicant:\s*/i, "").trim())
    .filter(Boolean);
  return applicantLines.length ? applicantLines.join(" ") : source;
}

export async function extractResumeText({ mimeType = "", fileBuffer }) {
  if (!fileBuffer || !Buffer.isBuffer(fileBuffer)) {
    return "";
  }
  const normalizedType = String(mimeType || "").trim().toLowerCase();
  if (!SUPPORTED_MIME_TYPES.has(normalizedType)) {
    throw new Error(`Unsupported resume MIME type: ${mimeType}`);
  }

  if (normalizedType === "application/pdf") {
    const parser = new PDFParse({ data: fileBuffer });
    try {
      const result = await parser.getText();
      return normalizeWhitespace(result?.text || "");
    } finally {
      await parser.destroy();
    }
  }

  const docx = await mammoth.extractRawText({ buffer: fileBuffer });
  return normalizeWhitespace(docx?.value || "");
}

export function computeResumeConsistency({
  resumeText = "",
  transcript = "",
  extractedSkills = [],
}) {
  const normalizedResumeText = normalizeWhitespace(resumeText);
  const applicantText = getApplicantOnlyText(transcript);
  const uniqueSkills = Array.from(
    new Set(
      (extractedSkills || [])
        .map((s) => String(s || "").trim())
        .filter(Boolean)
    )
  );

  const base = {
    resume_consistency_score: null,
    resume_consistency_flag: "Insufficient Data",
    support_ratio: null,
    contradiction_penalty: 0,
    supported_skills: [],
    unsupported_skills: [],
    evidence: [],
    notes: "Resume consistency check skipped due to insufficient data.",
  };

  if (!normalizedResumeText) {
    return {
      ...base,
      notes: "No resume text was available for consistency checking.",
    };
  }

  if (!uniqueSkills.length) {
    return {
      ...base,
      notes: "No interview-extracted skills available to compare against resume.",
    };
  }

  const supportedSkills = [];
  const unsupportedSkills = [];
  const evidence = [];

  uniqueSkills.forEach((skill) => {
    const mentioned = hasSkillMention(normalizedResumeText, skill);
    if (mentioned) {
      supportedSkills.push(skill);
      const evidenceLine = findEvidenceLine(normalizedResumeText, skill);
      evidence.push({
        skill,
        evidence_text: evidenceLine || "",
      });
      return;
    }
    unsupportedSkills.push(skill);
  });

  const supportRatio = supportedSkills.length / uniqueSkills.length;

  const resumeYears = extractYears(normalizedResumeText);
  const transcriptYears = extractYears(applicantText);
  let contradictionPenalty = 0;
  if (resumeYears.length && transcriptYears.length) {
    const maxGap = Math.max(
      ...resumeYears.map((r) =>
        Math.min(...transcriptYears.map((t) => Math.abs(r - t)))
      )
    );
    if (Number.isFinite(maxGap) && maxGap >= 3) {
      contradictionPenalty = 0.1;
    }
  }

  const score = Math.max(0, Math.min(1, supportRatio - contradictionPenalty));
  let flag = "Low";
  if (score >= 0.75) flag = "High";
  else if (score >= 0.45) flag = "Moderate";

  return {
    resume_consistency_score: Number(score.toFixed(4)),
    resume_consistency_flag: flag,
    support_ratio: Number(supportRatio.toFixed(4)),
    contradiction_penalty: Number(contradictionPenalty.toFixed(4)),
    supported_skills: supportedSkills,
    unsupported_skills: unsupportedSkills,
    evidence,
    notes:
      contradictionPenalty > 0
        ? "Skill support was reduced due to large years-of-experience mismatch signals."
        : "Resume consistency computed from resume-to-interview skill support.",
  };
}
