import { db } from "../db.js";

export async function writeAuditLog({
  actorUserId = null,
  action,
  entityType,
  entityId = null,
  summary,
  metadata = null,
}) {
  if (!action || !entityType || !summary) {
    return;
  }

  try {
    await db.query(
      `
      INSERT INTO audit_logs (
        actor_user_id,
        action,
        entity_type,
        entity_id,
        summary,
        metadata_json
      )
      VALUES (?, ?, ?, ?, ?, ?)
      `,
      [
        actorUserId || null,
        String(action),
        String(entityType),
        entityId === null || entityId === undefined ? null : String(entityId),
        String(summary),
        metadata ? JSON.stringify(metadata) : null,
      ]
    );
  } catch (err) {
    console.error("[AuditLog] failed to persist audit log:", err);
  }
}
