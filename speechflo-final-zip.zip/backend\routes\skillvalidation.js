import express from "express";
import dotenv from "dotenv";
import OpenAI from "openai";
import { db } from "../db.js";
import { authMiddleware, requireRole } from "./authMiddleware.js";
import {
  parseAnalysisSections,
  parseSkillValidation,
} from "../utils/interviewStore.js";
import {
  compatibilityConfig,
  computeCompatibilityResult,
} from "../utils/compatibilityPolicy.js";
import { getActivePromptConfig } from "../utils/promptStore.js";
import {
  extractResumeText,
} from "../utils/resumeConsistency.js";
import {
  buildResumeCrossCheckV2,
  enhanceResumeCrossCheckWithEmbeddings,
} from "../utils/resumeCrossCheckV2.js";

dotenv.config();
const router = express.Router();
const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

router.use(authMiddleware);
router.use(requireRole("recruiter", "admin"));

// --------------------------
// GPT helper for skill validation
// --------------------------
/**
 * Fallback GPT validator used when semantic validation cannot provide a stable result.
 * Prompt content comes from the currently active prompt configuration.
 */
async function callGPTSkillValidation(applicantSkillsStr, roleSkillsStr, maxTokens = 1500) {
  const prompts = await getActivePromptConfig();
  const taskPrompt = prompts.tasks["skill_validation"];
  if (!taskPrompt) throw new Error("Task 'skill_validation' not defined in master prompt");

  const fullPrompt = `${prompts.master_prompt}\n\n${taskPrompt}\n\nApplicant Skills:\n${applicantSkillsStr}\n\nRole Skills:\n${roleSkillsStr}`;


  const response = await openai.chat.completions.create({
    model: "gpt-4",
    messages: [{ role: "user", content: fullPrompt }],
    max_tokens: maxTokens,
  });

  const output = response.choices[0].message.content;
  return output;
}

/**
 * Lexical fallback validator using extracted skills + transcript evidence checks.
 */
function buildHeuristicValidation(applicantSkills = [], roleSkillsRows = [], transcript = "") {
  const normalizedApplicant = applicantSkills
    .map((s) => String(s || "").trim().toLowerCase())
    .filter(Boolean);

  const tokenize = (text) =>
    String(text || "")
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, " ")
      .trim()
      .split(" ")
      .filter(Boolean);

  const isMentioned = (candidateTerms = []) => {
    const normalizedTerms = candidateTerms
      .map((t) => String(t || "").trim().toLowerCase())
      .filter(Boolean);
    if (!normalizedTerms.length) return false;

    for (const appSkill of normalizedApplicant) {
      for (const term of normalizedTerms) {
        if (appSkill === term) return true;
        if (appSkill.includes(term) || term.includes(appSkill)) return true;

        const appTokens = tokenize(appSkill);
        const termTokens = tokenize(term);
        if (!appTokens.length || !termTokens.length) continue;
        const shared = termTokens.filter((t) => appTokens.includes(t)).length;
        const overlap = shared / Math.max(termTokens.length, 1);
        if (overlap >= 0.6) return true;
      }
    }
    return false;
  };

  const matched = [];
  const missing = [];
  const reasoning = [];
  let totalWeight = 0;
  let matchedWeight = 0;

  roleSkillsRows.forEach((r) => {
    const skill = String(r.skill_name || "").trim();
    if (!skill) return;
    const aliases = buildSkillEvidenceTerms(skill, r.aliases_json);

    const weight = Number(r.weight ?? 0);
    totalWeight += weight > 0 ? weight : 0;

    const candidateTerms = aliases;
    const evidenceLine = findApplicantEvidenceLine(transcript, candidateTerms);
    const matchedByHeuristic = isMentioned(candidateTerms) && Boolean(evidenceLine);
    if (matchedByHeuristic) {
      matched.push(skill);
      if (weight > 0) matchedWeight += weight;
      reasoning.push({
        skill_name: skill,
        kb_skill: skill,
        matched: true,
        method: "heuristic",
        reason: "Matched by lexical overlap against extracted applicant skills.",
        candidate_evidence_text: evidenceLine,
        required: Number(r.required || 0) === 1,
        is_critical: Number(r.is_critical || 0) === 1,
        weight,
      });
    } else {
      missing.push(skill);
      reasoning.push({
        skill_name: skill,
        kb_skill: skill,
        matched: false,
        method: "heuristic",
        reason: evidenceLine
          ? "No strong lexical overlap found in extracted applicant skills."
          : "No clear candidate statement found for this skill in the transcript.",
        candidate_evidence_text: evidenceLine,
        required: Number(r.required || 0) === 1,
        is_critical: Number(r.is_critical || 0) === 1,
        weight,
      });
    }
  });

  const weightedScore = totalWeight > 0 ? matchedWeight / totalWeight : 0;
  return {
    matched_skills: matched,
    partial_skills: [],
    missing_skills: missing,
    weighted_score: Number(weightedScore.toFixed(4)),
    reasoning,
    validation_method: "heuristic",
  };
}

/**
 * Computes cosine similarity for embedding vectors.
 */
function cosineSimilarity(a = [], b = []) {
  if (!a.length || !b.length || a.length !== b.length) return 0;
  let dot = 0;
  let magA = 0;
  let magB = 0;
  for (let i = 0; i < a.length; i += 1) {
    dot += a[i] * b[i];
    magA += a[i] * a[i];
    magB += b[i] * b[i];
  }
  if (magA === 0 || magB === 0) return 0;
  return dot / (Math.sqrt(magA) * Math.sqrt(magB));
}

const GENERIC_SKILL_TERMS = new Set([
  "accounting",
  "office",
  "work",
  "operations",
  "operation",
  "admin",
  "administration",
  "support",
  "basic",
  "general",
  "experience",
]);

const TAGLISH_SKILL_ALIASES = {
  "accounting operations": [
    "general accounting",
    "accounting process",
    "accounting records",
  ],
  "accounting software": [
    "quickbooks",
    "xero",
    "sap",
    "odoo",
    "accounting system",
  ],
  "accounts payable receivable": [
    "accounts payable",
    "accounts receivable",
    "receivables",
    "ap ar",
    "vendor payments",
    "customer invoices",
  ],
  "excel analytics": [
    "excel",
    "microsoft excel",
    "excel formulas",
    "pivot table",
    "data analysis",
    "financial trends",
  ],
  "financial statements": [
    "financial statement",
    "financial reporting",
    "financial report",
    "monthly financial report",
    "income statement",
    "balance sheet",
    "cash flow statement",
  ],
  "internal controls compliance": [
    "internal control",
    "controls",
    "audit prep",
    "audit ready",
    "compliance",
    "reviewed entries",
    "double check",
  ],
  "reconciliation": [
    "bank reconciliation",
    "reconcile",
    "reconciliations",
  ],
};

function normalizeSkillKey(value = "") {
  return String(value || "")
    .toLowerCase()
    .replace(/&/g, " ")
    .replace(/[^a-z0-9]+/g, " ")
    .trim();
}

function normalizeLooseToken(token = "") {
  let t = String(token || "").toLowerCase().replace(/[^a-z0-9]/g, "");
  if (!t) return "";

  // Light stemming for plural/verb variants to reduce strict mismatches.
  if (t.length > 4 && t.endsWith("ies")) t = `${t.slice(0, -3)}y`;
  else if (t.length > 4 && t.endsWith("es")) t = t.slice(0, -2);
  else if (t.length > 3 && t.endsWith("s") && !t.endsWith("ss")) t = t.slice(0, -1);

  if (t.length > 5 && t.endsWith("ing")) t = t.slice(0, -3);
  else if (t.length > 4 && t.endsWith("ed")) t = t.slice(0, -2);

  return t;
}

function tokenizeLoose(text = "") {
  return String(text || "")
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, " ")
    .trim()
    .split(" ")
    .map((t) => normalizeLooseToken(t))
    .filter(Boolean);
}

function parseAliasArray(rawAliases) {
  if (!rawAliases) return [];
  if (Array.isArray(rawAliases)) {
    return rawAliases.map((v) => String(v || "").trim()).filter(Boolean);
  }
  try {
    const parsed = JSON.parse(rawAliases);
    return Array.isArray(parsed)
      ? parsed.map((v) => String(v || "").trim()).filter(Boolean)
      : [];
  } catch {
    return [];
  }
}

function uniqueSkillTerms(terms = []) {
  const seen = new Set();
  const out = [];
  (Array.isArray(terms) ? terms : []).forEach((term) => {
    const raw = String(term || "").trim();
    const key = normalizeSkillKey(raw);
    if (!raw || !key || seen.has(key)) return;
    seen.add(key);
    out.push(raw);
  });
  return out;
}

function buildSkillEvidenceTerms(skillName = "", aliasesRaw = null) {
  const skill = String(skillName || "").trim();
  const dbAliases = parseAliasArray(aliasesRaw);
  const fallbackAliases = TAGLISH_SKILL_ALIASES[normalizeSkillKey(skill)] || [];
  return uniqueSkillTerms([skill, ...dbAliases, ...fallbackAliases]);
}

function isGenericApplicantSkill(skillText = "") {
  const tokens = tokenizeLoose(skillText).filter((t) => t.length >= 3);
  if (!tokens.length) return true;
  const genericCount = tokens.filter((t) => GENERIC_SKILL_TERMS.has(t)).length;
  const genericRatio = genericCount / tokens.length;
  return tokens.length <= 4 && genericRatio >= 0.5;
}

function isFoundationalCategory(category = "") {
  const norm = String(category || "").toLowerCase();
  return (
    norm.includes("core") ||
    norm.includes("foundational") ||
    norm.includes("general") ||
    norm.includes("baseline")
  );
}

/**
 * Primary semantic validator:
 * compares applicant skill evidence against role requirements using embeddings.
 */
async function buildSemanticValidation(applicantSkills = [], roleSkillsRows = [], transcript = "") {
  const cleanApplicantSkills = applicantSkills
    .map((s) => String(s || "").trim())
    .filter(Boolean);

  if (!cleanApplicantSkills.length || !roleSkillsRows.length) {
    return {
      matched_skills: [],
      partial_skills: [],
      missing_skills: roleSkillsRows.map((r) => r.skill_name).filter(Boolean),
      weighted_score: 0,
    };
  }

  const roleTerms = roleSkillsRows
    .map((row) => {
      const skillName = String(row.skill_name || "").trim();
      return {
        skill_name: skillName,
        weight: Number(row.weight ?? 0),
        category: String(row.category || "").trim(),
        terms: buildSkillEvidenceTerms(skillName, row.aliases_json),
      };
    })
    .filter((r) => r.skill_name);

  const textSet = new Set();
  cleanApplicantSkills.forEach((s) => textSet.add(`Applicant skill: ${s}`));
  roleTerms.forEach((r) => {
    r.terms.forEach((t) => textSet.add(`Required skill term: ${t}`));
  });
  const embeddingInputs = Array.from(textSet);

  const emb = await openai.embeddings.create({
    model: "text-embedding-3-small",
    input: embeddingInputs,
  });

  const vectorByText = new Map();
  emb.data.forEach((item, idx) => {
    vectorByText.set(embeddingInputs[idx], item.embedding);
  });

  const applicantVectors = cleanApplicantSkills.map((s) => ({
    skill: s,
    vector: vectorByText.get(`Applicant skill: ${s}`) || [],
  }));

  const matched = [];
  const partial = [];
  const missing = [];
  const reasoning = [];
  let totalWeight = 0;
  let matchedWeight = 0;
  const threshold = 0.5;
  const partialThreshold = 0.55;

  const hasLexicalEvidence = (candidateTerms = [], appSkillText = "") => {
    const appNorm = String(appSkillText || "").trim();
    const appTokens = tokenizeLoose(appNorm);
    if (!appNorm) return false;
    for (const term of candidateTerms) {
      const t = String(term || "").trim();
      if (!t) continue;
      const appNormKey = normalizeSkillKey(appNorm);
      const termKey = normalizeSkillKey(t);
      if (appNormKey.includes(termKey) || termKey.includes(appNormKey)) return true;
      const tTokens = tokenizeLoose(t);
      const shared = tTokens.filter((tok) => appTokens.includes(tok)).length;
      if (tTokens.length === 1 && shared === 1) return true;
      if (tTokens.length === 2 && shared >= 1) return true;
      if (tTokens.length >= 3 && shared >= 2 && shared / tTokens.length >= 0.67) return true;
    }
    return false;
  };

  for (const role of roleTerms) {
    const weight = role.weight > 0 ? role.weight : 0;
    totalWeight += weight;

    let best = 0;
    let bestTerm = "";
    let bestApplicantSkill = "";
    let bestApplicantIsGeneric = false;
    const transcriptEvidenceDirect = findApplicantEvidenceLine(transcript, role.terms);
    let lexicalSupport = Boolean(transcriptEvidenceDirect);
    for (const term of role.terms) {
      const termVector = vectorByText.get(`Required skill term: ${term}`) || [];
      for (const app of applicantVectors) {
        const sim = cosineSimilarity(app.vector, termVector);
        if (sim > best) {
          best = sim;
          bestTerm = term;
          bestApplicantSkill = app.skill;
          bestApplicantIsGeneric = isGenericApplicantSkill(app.skill);
        }
        if (!lexicalSupport && hasLexicalEvidence(role.terms, app.skill)) {
          lexicalSupport = true;
        }
      }
    }

    let evidenceLine =
      transcriptEvidenceDirect ||
      findApplicantEvidenceLine(transcript, [
      role.skill_name,
      ...role.terms,
      bestApplicantSkill,
      ]);
    if (!evidenceLine && lexicalSupport && bestApplicantSkill) {
      // Keep strictness while preserving evidence trail from extracted transcript skill.
      evidenceLine = `Extracted skill: ${bestApplicantSkill}`;
    }
    const hasEvidence = Boolean(evidenceLine);
    const categoryAllowsGeneric = isFoundationalCategory(role.category);
    const semanticThreshold =
      bestApplicantIsGeneric && !categoryAllowsGeneric ? 0.72 : threshold;

    const lexicalMatched = lexicalSupport && hasEvidence;
    const semanticMatched =
      !lexicalMatched &&
      best >= semanticThreshold &&
      hasEvidence &&
      (!bestApplicantIsGeneric || categoryAllowsGeneric);
    const partialMatched =
      !lexicalMatched &&
      !semanticMatched &&
      hasEvidence &&
      best >= partialThreshold;

    if (lexicalMatched || semanticMatched) {
      matched.push(role.skill_name);
      matchedWeight += weight;
      reasoning.push({
        skill_name: role.skill_name,
        kb_skill: role.skill_name,
        matched: true,
        method: "semantic",
        best_similarity: Number(best.toFixed(4)),
        similarity_threshold: semanticThreshold,
        best_required_term: bestTerm || role.skill_name,
        best_applicant_skill: bestApplicantSkill || null,
        matched_by: lexicalMatched ? "lexical_support" : "embedding_similarity",
        candidate_evidence_text: evidenceLine,
        required: false,
        is_critical: false,
        weight,
        role_category: role.category || null,
        match_level: "matched",
      });
    } else if (partialMatched) {
      partial.push(role.skill_name);
      matchedWeight += weight * 0.5;
      reasoning.push({
        skill_name: role.skill_name,
        kb_skill: role.skill_name,
        matched: false,
        method: "semantic",
        best_similarity: Number(best.toFixed(4)),
        similarity_threshold: semanticThreshold,
        best_required_term: bestTerm || role.skill_name,
        best_applicant_skill: bestApplicantSkill || null,
        matched_by: "partial_similarity",
        reason: "Partially matched: related evidence found, but not enough for a full match.",
        candidate_evidence_text: evidenceLine,
        required: false,
        is_critical: false,
        weight,
        role_category: role.category || null,
        match_level: "partial",
      });
    } else {
      missing.push(role.skill_name);
      reasoning.push({
        skill_name: role.skill_name,
        kb_skill: role.skill_name,
        matched: false,
        method: "semantic",
        best_similarity: Number(best.toFixed(4)),
        similarity_threshold: semanticThreshold,
        best_required_term: bestTerm || role.skill_name,
        best_applicant_skill: bestApplicantSkill || null,
        matched_by: null,
        reason: hasEvidence
          ? bestApplicantIsGeneric && !categoryAllowsGeneric
            ? "Only broad evidence was found; specific proof for this skill is missing."
            : "No lexical match found, and semantic fallback did not pass threshold."
          : "No clear candidate statement found for this skill in the transcript.",
        candidate_evidence_text: evidenceLine,
        required: false,
        is_critical: false,
        weight,
        role_category: role.category || null,
        match_level: "missing",
      });
    }
  }

  const bySkill = new Map(
    roleSkillsRows.map((r) => [
      String(r.skill_name || "").trim().toLowerCase(),
      {
        required: Number(r.required || 0) === 1,
        is_critical: Number(r.is_critical || 0) === 1,
      },
    ])
  );
  reasoning.forEach((item) => {
    const meta = bySkill.get(String(item.skill_name || "").trim().toLowerCase());
    if (meta) {
      item.required = meta.required;
      item.is_critical = meta.is_critical;
    }
  });

  const weighted = totalWeight > 0 ? matchedWeight / totalWeight : 0;
  return {
    matched_skills: matched,
    partial_skills: partial,
    missing_skills: missing,
    weighted_score: Number(weighted.toFixed(4)),
    reasoning,
    validation_method: "semantic",
  };
}

function normalizeTitle(value = "") {
  return String(value)
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, " ")
    .trim();
}

/**
 * Resolves role skills for one application.
 * Priority: knowledgebase skills first, then fallback to job_skills.
 */
async function getRoleSkillsForValidation(jobId, jobTitle) {
  // 1) Prefer dedicated KB tables.
  const [kbRoles] = await db.query(
    "SELECT id, name FROM knowledgebase_roles"
  );

  let chosenKbRole = null;
  const target = normalizeTitle(jobTitle);
  if (kbRoles.length) {
    chosenKbRole =
      kbRoles.find((r) => normalizeTitle(r.name) === target) ||
      kbRoles.find((r) => normalizeTitle(r.name).includes(target)) ||
      kbRoles.find((r) => target.includes(normalizeTitle(r.name))) ||
      null;
  }

  if (chosenKbRole) {
    const [kbSkills] = await db.query(
      `
      SELECT
        skill_name,
        aliases_json,
        category,
        required,
        weight,
        is_critical
      FROM knowledgebase_skills
      WHERE role_id = ?
      `,
      [chosenKbRole.id]
    );
    if (kbSkills.length) {
      return { roleName: chosenKbRole.name, skills: kbSkills, source: "knowledgebase" };
    }
  }

  // 2) Fallback to existing job_skills.
  let roleSkillsRows = [];
  [roleSkillsRows] = await db.execute(
    `SELECT skill_name, category, required, weight, NULL AS aliases_json, 0 AS is_critical FROM job_skills WHERE job_id = ?`,
    [jobId]
  );
  if (roleSkillsRows.length === 0 && jobTitle) {
    [roleSkillsRows] = await db.execute(
      `SELECT skill_name, category, required, weight, NULL AS aliases_json, 0 AS is_critical FROM job_skills WHERE job_name = ?`,
      [jobTitle]
    );
  }
  return { roleName: jobTitle, skills: roleSkillsRows, source: "job_skills" };
}

/**
 * Loads per-role compatibility thresholds.
 * Falls back to default policy values if role policy records are unavailable.
 */
async function getRolePolicyForValidation(roleName = "") {
  const normalized = normalizeTitle(roleName);
  if (!normalized) return compatibilityConfig;

  let rows = [];
  try {
    const [result] = await db.query(
      `
      SELECT
        kr.name,
        rp.high_threshold,
        rp.moderate_threshold,
        rp.low_confidence_threshold,
        rp.critical_skill_penalty
      FROM knowledgebase_roles kr
      JOIN knowledgebase_role_policy rp ON rp.role_id = kr.id
      `
    );
    rows = result;
  } catch (err) {
    // If policy table is not ready yet, keep default thesis policy.
    return compatibilityConfig;
  }

  const matched =
    rows.find((r) => normalizeTitle(r.name) === normalized) ||
    rows.find((r) => normalizeTitle(r.name).includes(normalized)) ||
    rows.find((r) => normalized.includes(normalizeTitle(r.name))) ||
    null;

  if (!matched) return compatibilityConfig;

  return {
    ...compatibilityConfig,
    thresholds: {
      ...compatibilityConfig.thresholds,
      high: Number(matched.high_threshold ?? compatibilityConfig.thresholds.high),
      moderate: Number(matched.moderate_threshold ?? compatibilityConfig.thresholds.moderate),
      lowConfidence: Number(
        matched.low_confidence_threshold ?? compatibilityConfig.thresholds.lowConfidence
      ),
    },
    penalties: {
      ...compatibilityConfig.penalties,
      missingCriticalSkill: Number(
        matched.critical_skill_penalty ?? compatibilityConfig.penalties.missingCriticalSkill
      ),
    },
  };
}

function computeClarityScore(transcript = "") {
  const words = String(transcript || "").trim().split(/\s+/).filter(Boolean);
  if (!words.length) return 0;
  const filler = (String(transcript || "").match(/\b(um|uh|like|you know)\b/gi) || []).length;
  const ratio = filler / words.length;
  return Math.max(0, Math.min(1, 1 - ratio * 8));
}

function deriveRequiredCoverage(roleSkillsRows = [], missingSkills = [], partialSkills = []) {
  const requiredSkills = roleSkillsRows
    .filter((r) => Number(r.required || 0) === 1)
    .map((r) => String(r.skill_name || "").trim())
    .filter(Boolean);
  if (!requiredSkills.length) return 0;
  const missingSet = new Set(
    (missingSkills || []).map((s) => String(s || "").trim().toLowerCase()).filter(Boolean)
  );
  const partialSet = new Set(
    (partialSkills || []).map((s) => String(s || "").trim().toLowerCase()).filter(Boolean)
  );
  let covered = 0;
  requiredSkills.forEach((skill) => {
    const key = skill.toLowerCase();
    if (missingSet.has(key)) return;
    if (partialSet.has(key)) {
      covered += 0.5;
      return;
    }
    covered += 1;
  });
  return Math.max(0, covered / requiredSkills.length);
}

function deriveMissingCriticalCount(roleSkillsRows = [], missingSkills = [], partialSkills = []) {
  const criticalSet = new Set(
    roleSkillsRows
      .filter((r) => Number(r.is_critical || 0) === 1)
      .map((r) => String(r.skill_name || "").trim().toLowerCase())
      .filter(Boolean)
  );
  if (!criticalSet.size) return 0;
  const missingCount = (missingSkills || [])
    .filter((s) => criticalSet.has(String(s || "").trim().toLowerCase()))
    .length;
  const partialCount = (partialSkills || [])
    .filter((s) => criticalSet.has(String(s || "").trim().toLowerCase()))
    .length;
  return Number((missingCount + partialCount * 0.5).toFixed(2));
}

function countSkillMentions(text = "", skill = "") {
  const source = String(text || "").toLowerCase();
  const phrase = String(skill || "").trim().toLowerCase();
  if (!source || !phrase) return 0;
  const escaped = phrase.replace(/[-/\\^$*+?.()|[\]{}]/g, "\\$&").replace(/\s+/g, "\\s+");
  const regex = new RegExp(`\\b${escaped}\\b`, "gi");
  return (source.match(regex) || []).length;
}

function extractApplicantText(transcript = "") {
  const text = String(transcript || "");
  if (!text) return "";
  const applicantLines = text
    .split("\n")
    .map((l) => l.trim())
    .filter((l) => /^Applicant:/i.test(l))
    .map((l) => l.replace(/^Applicant:\s*/i, "").trim())
    .filter(Boolean);
  return applicantLines.length ? applicantLines.join(" ") : text;
}

/**
 * Computes consistency score from applicant-only transcript text.
 * Combines skill mention coverage, topic repetition, and contradiction penalties.
 */
function computeResponseConsistency({
  transcript = "",
  extractedSkills = [],
}) {
  const applicantText = extractApplicantText(transcript);
  const normalizedSkills = (extractedSkills || [])
    .map((s) => String(s || "").trim())
    .filter(Boolean);

  let smc = 0; // Skill Mention Consistency
  if (normalizedSkills.length > 0) {
    const supported = normalizedSkills.filter((skill) => countSkillMentions(applicantText, skill) > 0).length;
    smc = supported / normalizedSkills.length;
  }

  // Answer stability proxy: if a skill appears multiple times, treat it as more stable evidence.
  const repeatedTopics = normalizedSkills.filter((skill) => countSkillMentions(applicantText, skill) >= 2).length;
  const answerStability =
    normalizedSkills.length === 0 ? 0 : repeatedTopics / normalizedSkills.length;

  // Contradiction proxy: conflicting "X years" statements from applicant text.
  const yearNums = Array.from(
    new Set(
      (applicantText.match(/\b(\d{1,2})\s+years?\b/gi) || [])
        .map((m) => Number((m.match(/\d{1,2}/) || [0])[0]))
        .filter((n) => Number.isFinite(n))
    )
  );
  const contradictionCount = yearNums.length >= 2 ? 1 : 0;
  const contradictionPenalty = Math.min(1, contradictionCount / 3);

  const score = Math.max(0, Math.min(1, 0.5 * smc + 0.5 * answerStability - 0.2 * contradictionPenalty));
  return Number(score.toFixed(4));
}

function findApplicantEvidenceLine(transcript = "", terms = []) {
  const allLines = String(transcript || "")
    .split("\n")
    .map((l) => l.trim())
    .filter(Boolean);

  const applicantLines = allLines
    .filter((l) => /^Applicant:/i.test(l))
    .map((l) => l.replace(/^Applicant:\s*/i, "").trim())
    .filter(Boolean);
  const fallbackLines = allLines
    .filter((l) => !/^Interviewer:/i.test(l))
    .map((l) => l.replace(/^(Applicant:|Interviewer:)\s*/i, "").trim())
    .filter(Boolean);

  const searchableLines = applicantLines.length ? applicantLines : fallbackLines;
  if (!searchableLines.length) return "";

  const normalizedTerms = (terms || [])
    .map((t) => String(t || "").trim().toLowerCase())
    .filter(Boolean);

  if (!normalizedTerms.length) return searchableLines[0].slice(0, 280);

  const tokenize = (text) => tokenizeLoose(text);

  for (const line of searchableLines) {
    const lineNorm = normalizeSkillKey(line);
    const lineTokens = tokenize(lineNorm);
    for (const term of normalizedTerms) {
      const termNorm = normalizeSkillKey(term);
      if (lineNorm.includes(termNorm)) return line.slice(0, 280);
      const termTokens = tokenize(term).filter((t) => t.length >= 4);
      if (!termTokens.length) continue;
      const shared = termTokens.filter((t) => lineTokens.includes(t)).length;
      if (termTokens.length === 1 && shared === 1) return line.slice(0, 280);
      if (termTokens.length === 2 && shared === 2) return line.slice(0, 280);
      if (termTokens.length >= 3 && shared >= 2 && shared / termTokens.length >= 0.67) {
        return line.slice(0, 280);
      }
    }
  }
  return "";
}

/**
 * Builds final compatibility payload used for UI display and persistence.
 * This combines validation output, policy thresholds, transcript clarity, and consistency.
 */
function buildCompatibilityPayload({
  parsedValidation,
  roleSkillsRows,
  transcript,
  confidence,
  extractedSkills,
  rolePolicy,
}) {
  const requiredCoverage = deriveRequiredCoverage(
    roleSkillsRows,
    parsedValidation.missing_skills || [],
    parsedValidation.partial_skills || []
  );
  const missingCriticalCount = deriveMissingCriticalCount(
    roleSkillsRows,
    parsedValidation.missing_skills || [],
    parsedValidation.partial_skills || []
  );
  const clarity = computeClarityScore(transcript || "");
  const responseConsistency = computeResponseConsistency({
    transcript,
    extractedSkills,
  });
  const result = computeCompatibilityResult({
    weightedScore: Number(parsedValidation.weighted_score ?? 0),
    requiredCoverage,
    communicationClarity: clarity,
    confidence: Number(confidence ?? 0),
    responseConsistency,
    missingCriticalCount,
    cfg: rolePolicy || compatibilityConfig,
  });
  return {
    ...result,
    response_consistency_score: Number(responseConsistency.toFixed(4)),
  };
}

/**
 * Fetches applicant resume binary payload for a given application id.
 */
async function getResumeFileForApplication(applicationId) {
  const [rows] = await db.query(
    `
    SELECT
      ja.user_id,
      arf.file_name,
      arf.mime_type,
      arf.file_data
    FROM job_applications ja
    LEFT JOIN applicant_resume_files arf ON arf.user_id = ja.user_id
    WHERE ja.id = ?
    LIMIT 1
    `,
    [applicationId]
  );
  if (!rows.length) return null;
  const row = rows[0];
  if (!row.file_data) return null;
  return row;
}

/**
 * Computes resume consistency summary for one application.
 * Uses lexical claim checks with optional embedding-based enhancement.
 */
async function computeResumeConsistencyForApplication({
  applicationId,
  transcript = "",
  extractedSkills = [],
  roleSkillsRows = [],
  openaiClient = null,
}) {
  const defaultResult = {
    version: "resume_consistency_v2",
    resume_consistency_score: null,
    resume_consistency_flag: "Insufficient Data",
    skill_alignment_score: null,
    experience_consistency_score: null,
    tooling_consistency_score: null,
    credential_consistency_score: null,
    overall_resume_consistency_score: null,
    hard_contradiction_count: 0,
    soft_gap_count: 0,
    insufficient_evidence_count: 0,
    resume_claims: {},
    transcript_claims: {},
    claim_checks: [],
    notes: "Resume consistency check skipped due to insufficient data.",
  };

  const resumeFile = await getResumeFileForApplication(applicationId);
  if (!resumeFile) {
    return {
      ...defaultResult,
      notes: "No uploaded resume file was found for this applicant.",
    };
  }

  try {
    const resumeText = await extractResumeText({
      mimeType: resumeFile.mime_type,
      fileBuffer: resumeFile.file_data,
    });
    const lexicalComputed = buildResumeCrossCheckV2({
      resumeText,
      transcript,
      extractedSkills,
      roleSkillsRows,
    });
    let computed = lexicalComputed;
    if (openaiClient) {
      try {
        computed = await enhanceResumeCrossCheckWithEmbeddings({
          crossCheck: lexicalComputed,
          resumeText,
          transcriptText: transcript,
          openaiClient,
        });
      } catch (semanticErr) {
        computed = {
          ...lexicalComputed,
          notes: `${lexicalComputed.notes || ""} Semantic enrichment failed; lexical result kept.`.trim(),
        };
      }
    }
    return {
      ...computed,
      resume_consistency_score:
        computed.overall_resume_consistency_score === null ||
        computed.overall_resume_consistency_score === undefined
          ? null
          : Number(computed.overall_resume_consistency_score),
      resume_file_name: resumeFile.file_name || null,
      resume_mime_type: resumeFile.mime_type || null,
    };
  } catch (err) {
    return {
      ...defaultResult,
      notes: `Resume parsing failed: ${err.message}`,
      resume_file_name: resumeFile.file_name || null,
      resume_mime_type: resumeFile.mime_type || null,
    };
  }
}

/**
 * Upserts claim-level cross-check output into application_claim_checks table.
 */
async function upsertApplicationClaimChecks(applicationId, details = {}) {
  const scoreOrNull = (v) =>
    v === null || v === undefined || Number.isNaN(Number(v)) ? null : Number(v);
  await db.query(
    `
    INSERT INTO application_claim_checks (
      application_id,
      model_version,
      resume_claims_json,
      transcript_claims_json,
      checks_json,
      skill_alignment_score,
      experience_consistency_score,
      tooling_consistency_score,
      credential_consistency_score,
      overall_resume_consistency_score,
      hard_contradiction_count,
      soft_gap_count,
      insufficient_evidence_count
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ON DUPLICATE KEY UPDATE
      model_version = VALUES(model_version),
      resume_claims_json = VALUES(resume_claims_json),
      transcript_claims_json = VALUES(transcript_claims_json),
      checks_json = VALUES(checks_json),
      skill_alignment_score = VALUES(skill_alignment_score),
      experience_consistency_score = VALUES(experience_consistency_score),
      tooling_consistency_score = VALUES(tooling_consistency_score),
      credential_consistency_score = VALUES(credential_consistency_score),
      overall_resume_consistency_score = VALUES(overall_resume_consistency_score),
      hard_contradiction_count = VALUES(hard_contradiction_count),
      soft_gap_count = VALUES(soft_gap_count),
      insufficient_evidence_count = VALUES(insufficient_evidence_count)
    `,
    [
      applicationId,
      details.version || "resume_consistency_v2",
      JSON.stringify(details.resume_claims || {}),
      JSON.stringify(details.transcript_claims || {}),
      JSON.stringify(details.claim_checks || []),
      scoreOrNull(details.skill_alignment_score),
      scoreOrNull(details.experience_consistency_score),
      scoreOrNull(details.tooling_consistency_score),
      scoreOrNull(details.credential_consistency_score),
      scoreOrNull(details.overall_resume_consistency_score),
      Number(details.hard_contradiction_count || 0),
      Number(details.soft_gap_count || 0),
      Number(details.insufficient_evidence_count || 0),
    ]
  );
}

/**
 * Applies recommendation guardrails based on resume consistency risk signals.
 */
function applyResumeConsistencyGuard(compatibility = {}, resumeConsistency = {}) {
  const out = {
    ...compatibility,
    resume_consistency_score:
      resumeConsistency.resume_consistency_score === null ||
      resumeConsistency.resume_consistency_score === undefined
        ? null
        : Number(resumeConsistency.resume_consistency_score),
    resume_consistency_flag:
      resumeConsistency.resume_consistency_flag || "Insufficient Data",
    resume_consistency_details: resumeConsistency || {},
  };

  if (out.resume_consistency_flag === "Low") {
    if (out.recommendation_class === "Advance") {
      out.recommendation_class = "Manual Review";
    } else if (out.recommendation_class === "Advance with Caution") {
      out.recommendation_class = "Manual Review";
    }
  } else if (
    out.resume_consistency_flag === "Moderate" &&
    out.recommendation_class === "Advance"
  ) {
    out.recommendation_class = "Advance with Caution";
  }

  if (Number(resumeConsistency.hard_contradiction_count || 0) >= 1) {
    if (out.recommendation_class === "Advance") {
      out.recommendation_class = "Manual Review";
    } else if (out.recommendation_class === "Advance with Caution") {
      out.recommendation_class = "Manual Review";
    }
  }

  return out;
}

/**
 * Rebuilds reasoning rows from stored matched/partial/missing buckets.
 * Used when older payloads are missing structured reasoning data.
 */
function buildReasoningFromParsed(parsedValidation, roleSkillsRows = [], transcript = "") {
  const matchedSet = new Set(
    (parsedValidation.matched_skills || []).map((s) => String(s || "").trim().toLowerCase())
  );
  const partialSet = new Set(
    (parsedValidation.partial_skills || []).map((s) => String(s || "").trim().toLowerCase())
  );
  return roleSkillsRows
    .map((r) => {
      const skill = String(r.skill_name || "").trim();
      if (!skill) return null;
      const evidence = findApplicantEvidenceLine(
        transcript,
        buildSkillEvidenceTerms(skill, r.aliases_json)
      );
      const key = skill.toLowerCase();
      const isMatched = matchedSet.has(key) && Boolean(evidence);
      const isPartial = !isMatched && partialSet.has(key) && Boolean(evidence);
      return {
        skill_name: skill,
        kb_skill: skill,
        matched: isMatched,
        match_level: isMatched ? "matched" : isPartial ? "partial" : "missing",
        method: "stored_result",
        reason: isMatched
          ? "Marked as matched in previous validation result."
          : isPartial
            ? "Marked as partial in previous validation result."
          : evidence
            ? "Marked as missing in previous validation result."
            : "No clear candidate statement found for this skill in the transcript.",
        candidate_evidence_text: evidence,
        required: Number(r.required || 0) === 1,
        is_critical: Number(r.is_critical || 0) === 1,
        weight: Number(r.weight ?? 0),
      };
    })
    .filter(Boolean);
}

/**
 * Ensures stored reasoning rows contain transcript evidence text before UI consumption.
 */
function hydrateReasoningEvidence(reasoning = [], transcript = "") {
  return (Array.isArray(reasoning) ? reasoning : []).map((item) => {
    const enrichedTerms = buildSkillEvidenceTerms(item.skill_name || item.kb_skill || "");
    const evidence =
      String(item.candidate_evidence_text || "").trim() ||
      findApplicantEvidenceLine(transcript, [
        ...enrichedTerms,
        item.best_required_term,
        item.best_applicant_skill,
      ]);
    return {
      ...item,
      kb_skill: item.kb_skill || item.skill_name,
      candidate_evidence_text: evidence || "",
    };
  });
}

/**
 * Strict evidence gate:
 * demotes matched/partial rows without transcript evidence and recomputes weighted score.
 */
function enforceStrictEvidenceMatch(parsedValidation, roleSkillsRows = [], transcript = "") {
  const reasoning = Array.isArray(parsedValidation.reasoning) ? parsedValidation.reasoning : [];
  if (!reasoning.length) {
    return {
      ...parsedValidation,
      partial_skills: Array.isArray(parsedValidation.partial_skills)
        ? parsedValidation.partial_skills
        : [],
    };
  }

  const hydrated = hydrateReasoningEvidence(reasoning, transcript);
  const normalized = hydrated.map((item) => {
    const hasEvidence = Boolean(String(item.candidate_evidence_text || "").trim());
    const level = item.match_level || (item.matched ? "matched" : "missing");
    if ((level === "matched" || level === "partial" || item.matched) && !hasEvidence) {
      return {
        ...item,
        matched: false,
        match_level: "missing",
        reason: "No clear candidate statement found for this skill in the transcript.",
      };
    }
    if (!item.match_level) {
      return {
        ...item,
        match_level: item.matched ? "matched" : "missing",
      };
    }
    return item;
  });

  const matchedSkills = normalized
    .filter((r) => r.match_level === "matched")
    .map((r) => String(r.skill_name || "").trim())
    .filter(Boolean);
  const partialSkills = normalized
    .filter((r) => r.match_level === "partial")
    .map((r) => String(r.skill_name || "").trim())
    .filter(Boolean);
  const missingSkills = normalized
    .filter((r) => r.match_level !== "matched" && r.match_level !== "partial")
    .map((r) => String(r.skill_name || "").trim())
    .filter(Boolean);

  // Recompute weighted score from strict matched/missing outcome.
  const roleBySkill = new Map(
    (roleSkillsRows || []).map((r) => [
      String(r.skill_name || "").trim().toLowerCase(),
      Number(r.weight ?? 0),
    ])
  );
  let totalWeight = 0;
  let matchedWeight = 0;
  (roleSkillsRows || []).forEach((r) => {
    const w = Number(r.weight ?? 0);
    if (w > 0) totalWeight += w;
  });
  matchedSkills.forEach((skill) => {
    const w = roleBySkill.get(skill.toLowerCase()) || 0;
    if (w > 0) matchedWeight += w;
  });
  partialSkills.forEach((skill) => {
    const w = roleBySkill.get(skill.toLowerCase()) || 0;
    if (w > 0) matchedWeight += w * 0.5;
  });
  const weightedScore = totalWeight > 0 ? matchedWeight / totalWeight : 0;

  return {
    ...parsedValidation,
    reasoning: normalized,
    matched_skills: matchedSkills,
    partial_skills: partialSkills,
    missing_skills: missingSkills,
    weighted_score: Number(weightedScore.toFixed(4)),
  };
}

/**
 * Decides whether parsed validation should be recomputed from source transcript/skills.
 */
function shouldRecomputeParsedValidation({
  row = {},
  parsed = {},
  reasoning = [],
  extractedSkills = [],
}) {
  if (!String(row.transcript || "").trim()) return false;
  if (!Array.isArray(extractedSkills) || extractedSkills.length === 0) return false;

  if (!String(row.skill_validation_raw || "").trim()) return true;

  const reasons = Array.isArray(reasoning) ? reasoning : [];
  const hasReasoning = reasons.length > 0;
  const methods = reasons
    .map((r) => String(r?.method || "").trim().toLowerCase())
    .filter(Boolean);
  const onlyStoredResult = methods.length > 0 && methods.every((m) => m === "stored_result");

  const matchedCount = Array.isArray(parsed.matched_skills) ? parsed.matched_skills.length : 0;
  const partialCount = Array.isArray(parsed.partial_skills) ? parsed.partial_skills.length : 0;
  const missingCount = Array.isArray(parsed.missing_skills) ? parsed.missing_skills.length : 0;
  const total = matchedCount + partialCount + missingCount;
  const heavilyMissing = total >= 5 && missingCount / Math.max(total, 1) >= 0.8;

  return !hasReasoning || onlyStoredResult || heavilyMissing;
}

// --------------------------
// GET /validate-skills/:applicationId
// Computes and persists validation, compatibility, and resume consistency outputs.
// --------------------------
router.get("/validate-skills/:applicationId", async (req, res) => {
  try {
    const { applicationId } = req.params;
    const [artifactRows] = await db.execute(
      "SELECT skills_json, analysis_raw, transcript, confidence FROM interview_artifacts WHERE application_id = ?",
      [applicationId]
    );
    if (!artifactRows.length) {
      return res.status(404).json({ error: "Analysis not found" });
    }

    let skills = [];
    try {
      skills = artifactRows[0].skills_json ? JSON.parse(artifactRows[0].skills_json) : [];
    } catch {
      skills = [];
    }
    if (!skills.length && artifactRows[0].analysis_raw) {
      const parsed = parseAnalysisSections(artifactRows[0].analysis_raw);
      skills = parsed.skills || [];
    }

    const applicantSkillsStr = skills.join(", ");
    if (!applicantSkillsStr) {
      return res.status(400).json({ error: "No skills found in analysis" });
    }

    // Resolve job context from application_id (preferred) with optional title fallback.
    const [appRows] = await db.execute(
      `
      SELECT ja.job_id, j.title
      FROM job_applications ja
      JOIN jobs j ON j.id = ja.job_id
      WHERE ja.id = ?
      `,
      [applicationId]
    );
    if (!appRows.length) {
      return res.status(404).json({ error: "Application not found" });
    }

    const jobId = appRows[0].job_id;
    const roleNameFront = req.query.roleNameFront || appRows[0].title;

    const roleData = await getRoleSkillsForValidation(jobId, roleNameFront);
    const rolePolicy = await getRolePolicyForValidation(roleData.roleName || roleNameFront || "");
    const roleSkillsRows = roleData.skills;
    if (roleSkillsRows.length === 0) {
      return res.status(404).json({ error: "No skills found for this role in DB" });
    }

    const roleSkillsStr = roleSkillsRows
      .map((r) => {
        let aliases = [];
        try {
          aliases = r.aliases_json ? JSON.parse(r.aliases_json) : [];
        } catch {
          aliases = [];
        }
        const aliasText = aliases.length ? ` aliases=${aliases.join("|")}` : "";
        return `${r.skill_name}${aliasText}; category=${r.category || ""}; required=${r.required ? "yes" : "no"}; weight=${r.weight ?? 0}`;
      })
      .join("\n");

    const gptOutput = await callGPTSkillValidation(applicantSkillsStr, roleSkillsStr);
    let parsedValidation;
    try {
      // Primary scoring path: semantic AI matching via embeddings.
      parsedValidation = await buildSemanticValidation(
        skills,
        roleSkillsRows,
        artifactRows[0]?.transcript || ""
      );
    } catch (semanticErr) {
      console.error("[SkillValidation] semantic scoring failed, falling back:", semanticErr.message);
      parsedValidation = parseSkillValidation(gptOutput);
      if (!Array.isArray(parsedValidation.partial_skills)) parsedValidation.partial_skills = [];
      parsedValidation.validation_method = "gpt_parse";
      parsedValidation.reasoning = buildReasoningFromParsed(
        parsedValidation,
        roleSkillsRows,
        artifactRows[0]?.transcript || ""
      );
      if (
        (!parsedValidation.matched_skills?.length &&
          !parsedValidation.missing_skills?.length) ||
        Number.isNaN(parsedValidation.weighted_score)
      ) {
        parsedValidation = buildHeuristicValidation(
          skills,
          roleSkillsRows,
          artifactRows[0]?.transcript || ""
        );
      }
    }
    if (!Array.isArray(parsedValidation.reasoning)) {
      parsedValidation.reasoning = buildReasoningFromParsed(
        parsedValidation,
        roleSkillsRows,
        artifactRows[0]?.transcript || ""
      );
    }
    parsedValidation.reasoning = (parsedValidation.reasoning || []).map((item) => ({
      ...item,
      kb_skill: item.kb_skill || item.skill_name,
      candidate_evidence_text:
        item.candidate_evidence_text ||
        findApplicantEvidenceLine(artifactRows[0]?.transcript || "", [
          ...buildSkillEvidenceTerms(item.skill_name || item.kb_skill || ""),
          item.best_required_term,
          item.best_applicant_skill,
        ]),
    }));
    parsedValidation = enforceStrictEvidenceMatch(
      parsedValidation,
      roleSkillsRows,
      artifactRows[0]?.transcript || ""
    );
    if (!parsedValidation.validation_method) {
      parsedValidation.validation_method = "semantic";
    }
    const resumeConsistency = await computeResumeConsistencyForApplication({
      applicationId,
      transcript: artifactRows[0]?.transcript || "",
      extractedSkills: skills,
      roleSkillsRows,
      openaiClient: openai,
    });
    let compatibility = buildCompatibilityPayload({
      parsedValidation,
      roleSkillsRows,
      transcript: artifactRows[0]?.transcript || "",
      confidence: artifactRows[0]?.confidence,
      extractedSkills: skills,
      rolePolicy,
    });
    compatibility = applyResumeConsistencyGuard(compatibility, resumeConsistency);
    await upsertApplicationClaimChecks(applicationId, resumeConsistency);

    await db.query(
      `
      UPDATE interview_artifacts
      SET
        skill_validation_raw = ?,
        matched_skills_json = ?,
        missing_skills_json = ?,
        weighted_score = ?,
        compatibility_score = ?,
        compatibility_flag = ?,
        recommendation_class = ?,
        compatibility_model_version = ?,
        response_consistency_score = ?,
        resume_consistency_score = ?,
        resume_consistency_flag = ?,
        resume_consistency_details_json = ?,
        skill_validation_reasoning_json = ?,
        skill_validation_method = ?
      WHERE application_id = ?
      `,
      [
        gptOutput,
        JSON.stringify(parsedValidation.matched_skills || []),
        JSON.stringify(parsedValidation.missing_skills || []),
        parsedValidation.weighted_score ?? 0,
        compatibility.compatibility_score,
        compatibility.compatibility_flag,
        compatibility.recommendation_class,
        compatibility.compatibility_model_version,
        compatibility.response_consistency_score,
        compatibility.resume_consistency_score,
        compatibility.resume_consistency_flag,
        JSON.stringify(compatibility.resume_consistency_details || {}),
        JSON.stringify(parsedValidation.reasoning || []),
        parsedValidation.validation_method || "semantic",
        applicationId,
      ]
    );

    res.json({
      message: "Skill validation completed",
      source: roleData.source,
      parsed: parsedValidation,
      compatibility,
      resumeConsistency,
      gptOutput
    });

  } catch (err) {
    console.error("[SkillValidation] error:", err);
    res.status(500).json({ error: "Failed to validate skills", details: err.message });
  }
});

// --------------------------
// GET /skillvalidation/parsed/:applicationId
// Returns parsed validation payload for UI/report consumers.
// --------------------------
router.get("/parsed/:applicationId", async (req, res) => {
  try {
    const { applicationId } = req.params;

    const [rows] = await db.query(
      `
      SELECT
        matched_skills_json,
        missing_skills_json,
        weighted_score,
        skill_validation_raw,
        compatibility_score,
        compatibility_flag,
        recommendation_class,
        compatibility_model_version,
        response_consistency_score,
        resume_consistency_score,
        resume_consistency_flag,
        resume_consistency_details_json,
        skill_validation_reasoning_json,
        skill_validation_method,
        transcript,
        confidence,
        skills_json
      FROM interview_artifacts
      WHERE application_id = ?
      `,
      [applicationId]
    );
    if (!rows.length) {
      return res.status(404).json({ error: "Skill validation not found" });
    }

    const row = rows[0];
    const [claimRows] = await db.query(
      `
      SELECT
        model_version,
        resume_claims_json,
        transcript_claims_json,
        checks_json,
        skill_alignment_score,
        experience_consistency_score,
        tooling_consistency_score,
        credential_consistency_score,
        overall_resume_consistency_score,
        hard_contradiction_count,
        soft_gap_count,
        insufficient_evidence_count
      FROM application_claim_checks
      WHERE application_id = ?
      LIMIT 1
      `,
      [applicationId]
    );
    const claimRow = claimRows[0] || null;
    let parsed = {
      matched_skills: [],
      partial_skills: [],
      missing_skills: [],
      weighted_score: row.weighted_score === null ? 0 : Number(row.weighted_score),
    };
    let extractedSkillsBase = [];
    try {
      extractedSkillsBase = row.skills_json ? JSON.parse(row.skills_json) : [];
    } catch {
      extractedSkillsBase = [];
    }
    let compatibility = {
      compatibility_score:
        row.compatibility_score === null ? null : Number(row.compatibility_score),
      compatibility_flag: row.compatibility_flag || null,
      recommendation_class: row.recommendation_class || null,
      compatibility_model_version: row.compatibility_model_version || null,
      response_consistency_score:
        row.response_consistency_score === null ? null : Number(row.response_consistency_score),
      resume_consistency_score:
        row.resume_consistency_score === null ? null : Number(row.resume_consistency_score),
      resume_consistency_flag: row.resume_consistency_flag || "Insufficient Data",
      resume_consistency_details: (() => {
        if (claimRow) {
          try {
            return {
              version: claimRow.model_version || "resume_consistency_v2",
              resume_claims: claimRow.resume_claims_json
                ? JSON.parse(claimRow.resume_claims_json)
                : {},
              transcript_claims: claimRow.transcript_claims_json
                ? JSON.parse(claimRow.transcript_claims_json)
                : {},
              claim_checks: claimRow.checks_json ? JSON.parse(claimRow.checks_json) : [],
              skill_alignment_score:
                claimRow.skill_alignment_score === null
                  ? null
                  : Number(claimRow.skill_alignment_score),
              experience_consistency_score:
                claimRow.experience_consistency_score === null
                  ? null
                  : Number(claimRow.experience_consistency_score),
              tooling_consistency_score:
                claimRow.tooling_consistency_score === null
                  ? null
                  : Number(claimRow.tooling_consistency_score),
              credential_consistency_score:
                claimRow.credential_consistency_score === null
                  ? null
                  : Number(claimRow.credential_consistency_score),
              overall_resume_consistency_score:
                claimRow.overall_resume_consistency_score === null
                  ? null
                  : Number(claimRow.overall_resume_consistency_score),
              hard_contradiction_count: Number(claimRow.hard_contradiction_count || 0),
              soft_gap_count: Number(claimRow.soft_gap_count || 0),
              insufficient_evidence_count: Number(claimRow.insufficient_evidence_count || 0),
            };
          } catch {
            // fallback to interview_artifacts JSON
          }
        }
        try {
          return row.resume_consistency_details_json
            ? JSON.parse(row.resume_consistency_details_json)
            : {};
        } catch {
          return {};
        }
      })(),
      confidence_flag: Number(row.confidence ?? 0) < compatibilityConfig.thresholds.lowConfidence
        ? "Low Analysis Confidence"
        : "OK",
    };
    let reasoning = [];
    try {
      reasoning = row.skill_validation_reasoning_json
        ? JSON.parse(row.skill_validation_reasoning_json)
        : [];
    } catch {
      reasoning = [];
    }

    if (row.matched_skills_json || row.missing_skills_json) {
      try {
        parsed.matched_skills = row.matched_skills_json
          ? JSON.parse(row.matched_skills_json)
          : [];
      } catch {
        parsed.matched_skills = [];
      }
      try {
        parsed.missing_skills = row.missing_skills_json
          ? JSON.parse(row.missing_skills_json)
          : [];
      } catch {
        parsed.missing_skills = [];
      }
    } else if (row.skill_validation_raw) {
      parsed = parseSkillValidation(row.skill_validation_raw);
      if (!Array.isArray(parsed.partial_skills)) parsed.partial_skills = [];
    }

    if (!Array.isArray(parsed.partial_skills)) parsed.partial_skills = [];
    if (!parsed.partial_skills.length && Array.isArray(reasoning) && reasoning.length) {
      parsed.partial_skills = reasoning
        .filter((item) => String(item?.match_level || "").toLowerCase() === "partial")
        .map((item) => String(item?.skill_name || "").trim())
        .filter(Boolean);
    }

    // Recompute from current KB when persisted payload is missing or clearly stale.
    const needsRecompute = shouldRecomputeParsedValidation({
      row,
      parsed,
      reasoning,
      extractedSkills: extractedSkillsBase,
    });
    if (needsRecompute) {
      // Fallback: compute a deterministic validation from extracted skills + role skills.
      const [artifactRows] = await db.query(
        `
        SELECT ia.skills_json, ja.job_id, j.title
        FROM interview_artifacts ia
        JOIN job_applications ja ON ja.id = ia.application_id
        JOIN jobs j ON j.id = ja.job_id
        WHERE ia.application_id = ?
        `,
        [applicationId]
      );

      if (artifactRows.length > 0) {
        const artifact = artifactRows[0];
        let applicantSkills = [];
        try {
          applicantSkills = artifact.skills_json ? JSON.parse(artifact.skills_json) : [];
        } catch {
          applicantSkills = [];
        }

        const roleData = await getRoleSkillsForValidation(
          artifact.job_id,
          artifact.title
        );
        const roleSkillsRows = roleData.skills;

        try {
          parsed = await buildSemanticValidation(
            applicantSkills,
            roleSkillsRows,
            row.transcript || ""
          );
        } catch {
          parsed = buildHeuristicValidation(
            applicantSkills,
            roleSkillsRows,
            row.transcript || ""
          );
        }

        const rolePolicy = await getRolePolicyForValidation(roleData.roleName || artifact.title || "");
        if (!Array.isArray(parsed.reasoning)) {
          parsed.reasoning = buildReasoningFromParsed(parsed, roleSkillsRows, row.transcript || "");
        }
        parsed.reasoning = (parsed.reasoning || []).map((item) => ({
          ...item,
          kb_skill: item.kb_skill || item.skill_name,
          candidate_evidence_text:
            item.candidate_evidence_text ||
            findApplicantEvidenceLine(row.transcript || "", [
              ...buildSkillEvidenceTerms(item.skill_name || item.kb_skill || ""),
              item.best_required_term,
              item.best_applicant_skill,
            ]),
        }));
        parsed = enforceStrictEvidenceMatch(parsed, roleSkillsRows, row.transcript || "");
        reasoning = Array.isArray(parsed.reasoning) ? parsed.reasoning : [];
        if (!parsed.validation_method) {
          parsed.validation_method = "semantic";
        }
        const resumeConsistency = await computeResumeConsistencyForApplication({
          applicationId,
          transcript: row.transcript || "",
          extractedSkills: applicantSkills.length ? applicantSkills : extractedSkillsBase,
          roleSkillsRows,
          openaiClient: openai,
        });
        compatibility = buildCompatibilityPayload({
          parsedValidation: parsed,
          roleSkillsRows,
          transcript: row.transcript || "",
          confidence: row.confidence,
          extractedSkills: applicantSkills.length ? applicantSkills : extractedSkillsBase,
          rolePolicy,
        });
        compatibility = applyResumeConsistencyGuard(compatibility, resumeConsistency);
        await upsertApplicationClaimChecks(applicationId, resumeConsistency);

        await db.query(
          `
          UPDATE interview_artifacts
          SET
            matched_skills_json = ?,
            missing_skills_json = ?,
            weighted_score = ?,
            compatibility_score = ?,
            compatibility_flag = ?,
            recommendation_class = ?,
            compatibility_model_version = ?,
            response_consistency_score = ?,
            resume_consistency_score = ?,
            resume_consistency_flag = ?,
            resume_consistency_details_json = ?,
            skill_validation_reasoning_json = ?,
            skill_validation_method = ?
          WHERE application_id = ?
          `,
          [
            JSON.stringify(parsed.matched_skills || []),
            JSON.stringify(parsed.missing_skills || []),
            parsed.weighted_score ?? 0,
            compatibility.compatibility_score,
            compatibility.compatibility_flag,
            compatibility.recommendation_class,
            compatibility.compatibility_model_version,
            compatibility.response_consistency_score,
            compatibility.resume_consistency_score,
            compatibility.resume_consistency_flag,
            JSON.stringify(compatibility.resume_consistency_details || {}),
            JSON.stringify(parsed.reasoning || []),
            parsed.validation_method || "semantic",
            applicationId,
          ]
        );
      }
    }

    // Always recompute compatibility payload on read so response stays consistent with
    // current formula and includes component breakdown fields.
    const [contextRows] = await db.query(
      `
      SELECT ja.job_id, j.title
      FROM job_applications ja
      JOIN jobs j ON j.id = ja.job_id
      WHERE ja.id = ?
      `,
      [applicationId]
    );
    const title = contextRows[0]?.title || "";
    const roleData = await getRoleSkillsForValidation(contextRows[0]?.job_id, title);
    const rolePolicy = await getRolePolicyForValidation(roleData.roleName || title);
    compatibility = buildCompatibilityPayload({
      parsedValidation: parsed,
      roleSkillsRows: roleData.skills || [],
      transcript: row.transcript || "",
      confidence: row.confidence,
      extractedSkills: extractedSkillsBase.length ? extractedSkillsBase : (parsed.matched_skills || []),
      rolePolicy,
    });
    let resumeConsistencyDetails = {};
    if (claimRow) {
      try {
        resumeConsistencyDetails = {
          version: claimRow.model_version || "resume_consistency_v2",
          resume_claims: claimRow.resume_claims_json
            ? JSON.parse(claimRow.resume_claims_json)
            : {},
          transcript_claims: claimRow.transcript_claims_json
            ? JSON.parse(claimRow.transcript_claims_json)
            : {},
          claim_checks: claimRow.checks_json ? JSON.parse(claimRow.checks_json) : [],
          skill_alignment_score:
            claimRow.skill_alignment_score === null
              ? null
              : Number(claimRow.skill_alignment_score),
          experience_consistency_score:
            claimRow.experience_consistency_score === null
              ? null
              : Number(claimRow.experience_consistency_score),
          tooling_consistency_score:
            claimRow.tooling_consistency_score === null
              ? null
              : Number(claimRow.tooling_consistency_score),
          credential_consistency_score:
            claimRow.credential_consistency_score === null
              ? null
              : Number(claimRow.credential_consistency_score),
          overall_resume_consistency_score:
            claimRow.overall_resume_consistency_score === null
              ? null
              : Number(claimRow.overall_resume_consistency_score),
          hard_contradiction_count: Number(claimRow.hard_contradiction_count || 0),
          soft_gap_count: Number(claimRow.soft_gap_count || 0),
          insufficient_evidence_count: Number(claimRow.insufficient_evidence_count || 0),
        };
      } catch {
        resumeConsistencyDetails = {};
      }
    } else {
      try {
        resumeConsistencyDetails = row.resume_consistency_details_json
          ? JSON.parse(row.resume_consistency_details_json)
          : {};
      } catch {
        resumeConsistencyDetails = {};
      }
    }
    compatibility = applyResumeConsistencyGuard(compatibility, {
      resume_consistency_score: row.resume_consistency_score,
      resume_consistency_flag: row.resume_consistency_flag,
      ...resumeConsistencyDetails,
    });
    if (!reasoning.length) {
      reasoning = buildReasoningFromParsed(parsed, roleData.skills || [], row.transcript || "");
    }
    reasoning = (reasoning || []).map((item) => ({
      ...item,
      kb_skill: item.kb_skill || item.skill_name,
      candidate_evidence_text:
        item.candidate_evidence_text ||
        findApplicantEvidenceLine(row.transcript || "", [
          ...buildSkillEvidenceTerms(item.skill_name || item.kb_skill || ""),
          item.best_required_term,
          item.best_applicant_skill,
        ]),
    }));
    parsed = enforceStrictEvidenceMatch(
      {
        ...parsed,
        reasoning,
      },
      roleData.skills || [],
      row.transcript || ""
    );
    reasoning = parsed.reasoning || reasoning;

    res.json({
      ...parsed,
      reasoning,
      validation_method: row.skill_validation_method || parsed.validation_method || "semantic",
      ...compatibility,
    });
  } catch (err) {
    console.error("[SkillValidation Parsed] error:", err);
    res.status(500).json({ error: "Failed to parse skill validation data", details: err.message });
  }
});

export default router;
