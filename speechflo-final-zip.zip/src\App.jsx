import { Routes, Route, Navigate } from "react-router-dom";
import { getToken } from "./session";

/* Recruiter system */
import RecruiterLogin from "./pages/RecruiterLogin";
import Dashboard from "./pages/Dashboard";
import InterviewHub from "./pages/InterviewHub";
import UploadInterview from "./pages/UploadInterview";
import Analytics from "./pages/Analytics";
import Settings from "./pages/Settings";
import ChangeRequests from "./pages/ChangeRequests";
import Reports from "./pages/Reports";
import SampleReport from "./pages/SampleReport";
import InterviewDetails from "./pages/InterviewDetails";
import PublicJobDetails from "./pages/PublicJobDetails";
import HelpCenter from "./pages/HelpCenter";

/* Applicant system */
import Applicant_SignUp from "./Applicant_SignUp";
import Login_Applicant from "./Login_Applicant";
import Reset_Password from "./Reset_Password";
import Confirm_Reset from "./Confirm_Reset";
import Set_New_Password from "./Set_New_Password";
import My_Applications from "./My_Applications";
import My_Profile from "./My_Profile";

/* Admin + public */
import Adminlog from "./Adminlog";
import Admindash from "./Admindash";
import Homepage from "./Homepage";
import Jobs from "./Jobs";

export default function App() {
  const hasAdminToken = Boolean(getToken());

  return (
    <Routes>

      {/* Default */}
      <Route path="/" element={<Navigate to="/home" replace />} />

      {/* Public */}
      <Route path="/home" element={<Homepage />} />
      <Route path="/jobs" element={<Jobs />} />
      <Route path="/jobs/:jobId" element={<PublicJobDetails />} />
      <Route path="/jobdetails1" element={<Navigate to="/jobs" replace />} />
      <Route path="/jobdetails2" element={<Navigate to="/jobs" replace />} />
      <Route path="/jobdetails3" element={<Navigate to="/jobs" replace />} />
      <Route path="/jobdetails4" element={<Navigate to="/jobs" replace />} />
      <Route path="/jobdetails5" element={<Navigate to="/jobs" replace />} />
      <Route path="/jobdetails6" element={<Navigate to="/jobs" replace />} />

      {/* Applicant */}
      <Route path="/signup" element={<Applicant_SignUp />} />
      <Route path="/login-applicant" element={<Login_Applicant />} />
      <Route path="/reset_password" element={<Reset_Password />} />
      <Route path="/confirm-reset" element={<Confirm_Reset />} />
      <Route path="/set-new-password" element={<Set_New_Password />} />
      <Route path="/my_applications" element={<My_Applications />} />
      <Route path="/my_profile" element={<My_Profile />} />

      {/* Admin */}
      <Route path="/admin-login" element={<Adminlog />} />
      <Route path="/admin" element={<Navigate to={hasAdminToken ? "/admin/dashboard" : "/admin-login"} replace />} />
      <Route path="/admin/dashboard" element={hasAdminToken ? <Admindash /> : <Navigate to="/admin-login" replace />} />

      {/* Recruiter */}
      <Route path="/recruiter/login" element={<RecruiterLogin />} />
      <Route path="/recruiter/dashboard" element={<Dashboard />} />
      <Route path="/recruiter/interviewer-hub" element={<InterviewHub />} />
      <Route path="/recruiter/upload-interview" element={<UploadInterview />} />
      <Route path="/recruiter/analytics" element={<Analytics />} />
      <Route path="/recruiter/settings" element={<Settings />} />
      <Route path="/recruiter/change-requests" element={<ChangeRequests />} />
      <Route path="/recruiter/reports" element={<Reports />} />
      <Route path="/recruiter/reports/:applicationId" element={<SampleReport />} />
      <Route path="/recruiter/interview-details" element={<InterviewDetails />} />
      <Route path="/recruiter/help" element={<HelpCenter />} />
      <Route path="/recruiter/help/:section" element={<HelpCenter />} />

    </Routes>
  );
}
