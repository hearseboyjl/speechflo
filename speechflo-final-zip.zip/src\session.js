export function storeSession(auth) {
  const token = auth?.token || "";
  const user = auth?.user || {};

  if (!token) return;

  localStorage.setItem("token", token);
  localStorage.setItem("user", user.firstName || "User");
  localStorage.setItem("userRole", user.role || "");
}

export function clearSession() {
  localStorage.removeItem("token");
  localStorage.removeItem("user");
  localStorage.removeItem("userRole");
}

export function getToken() {
  return localStorage.getItem("token") || "";
}

export function authHeaders(extra = {}) {
  const token = getToken();
  return token
    ? {
        ...extra,
        Authorization: `Bearer ${token}`,
      }
    : { ...extra };
}
