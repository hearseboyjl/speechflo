# SpeechFlo

SpeechFlo is a Vite + React frontend with an Express/MySQL backend for:

- applicant signup, login, and job applications
- recruiter interview upload, analysis, reports, and dashboards
- admin login, oversight, account management, prompt management, and audit logs

## Core Commands

```bash
npm install
npm run build
npm start
```

## Useful Scripts

```bash
npm run import:knowledgebase
npm run create:user -- --role recruiter --first-name Test --last-name User --email test@example.com --password "Password123!"
```

## Deployment

For the current VPS deploy flow, use [docs/VPS_UPDATE_GUIDE.md](/c:/Users/kiimz/Desktop/compiled/docs/VPS_UPDATE_GUIDE.md).

For environment variables and initial setup, use [docs/HOSTINGER_DEPLOYMENT_GUIDE.md](/c:/Users/kiimz/Desktop/compiled/docs/HOSTINGER_DEPLOYMENT_GUIDE.md).
