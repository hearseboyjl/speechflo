import express from "express";
import bcrypt from "bcryptjs";
import crypto from "crypto";
import { db } from "../db.js";
import { authMiddleware, requireRole } from "./authMiddleware.js";
import { writeAuditLog } from "../utils/auditLog.js";
import {
  ensureSeedPromptVersion,
  getActivePromptConfig,
  getPromptVersionById,
  getPromptVersions,
  normalizePromptConfig,
} from "../utils/promptStore.js";

const router = express.Router();

router.use(authMiddleware);
router.use(requireRole("admin"));

function parseJsonArray(value, fallback = []) {
  if (!value) return fallback;
  try {
    const parsed = JSON.parse(value);
    return Array.isArray(parsed) ? parsed : fallback;
  } catch {
    return fallback;
  }
}

function parseJsonValue(value, fallback = null) {
  if (!value) return fallback;
  try {
    return JSON.parse(value);
  } catch {
    return fallback;
  }
}

function cleanString(value, { lower = false } = {}) {
  const normalized = String(value || "").trim();
  return lower ? normalized.toLowerCase() : normalized;
}

function coerceBoolean(value, defaultValue = false) {
  if (typeof value === "boolean") return value;
  if (value === 1 || value === "1" || value === "true") return true;
  if (value === 0 || value === "0" || value === "false") return false;
  return defaultValue;
}

const JOB_LIFECYCLE_STATUSES = new Set(["draft", "published", "closed"]);

function normalizeLegacyLifecycle(value = "") {
  const status = cleanString(value, { lower: true });
  if (status === "archived") return "closed";
  return status;
}

function normalizeJobLifecycleStatus(value, fallback = "published") {
  const next = normalizeLegacyLifecycle(value);
  if (!next) return fallback;
  return JOB_LIFECYCLE_STATUSES.has(next) ? next : fallback;
}

function deriveLifecycleSnapshot({ lifecycleStatus, isActive, existing = null }) {
  const now = new Date();
  const currentStatus = normalizeLegacyLifecycle(existing?.lifecycle_status) || null;

  const nextStatus = normalizeJobLifecycleStatus(
    lifecycleStatus,
    isActive ? "published" : "draft"
  );

  const publishedAt = nextStatus === "published" ? existing?.published_at || now : existing?.published_at || null;

  const resolvedClosedAt =
    nextStatus === "closed" ? (currentStatus === "closed" ? existing?.closed_at || now : now) : null;

  const resolvedIsActive = nextStatus === "published" ? 1 : 0;

  return {
    lifecycleStatus: nextStatus,
    isActive: resolvedIsActive,
    publishedAt: publishedAt || null,
    closedAt: resolvedClosedAt || null,
    archivedAt: null,
  };
}

function sanitizeSkillRows(skills = []) {
  return (Array.isArray(skills) ? skills : [])
    .map((skill) => ({
      name: cleanString(skill?.name),
      category: cleanString(skill?.category),
      required: coerceBoolean(skill?.required, true),
      weight: Number(skill?.weight ?? 0),
      aliases: Array.isArray(skill?.aliases)
        ? skill.aliases.map((alias) => cleanString(alias)).filter(Boolean)
        : [],
      isCritical: coerceBoolean(skill?.isCritical, false),
    }))
    .filter((skill) => skill.name);
}

function slugifyRoleKey(value) {
  return cleanString(value, { lower: true })
    .replace(/[^a-z0-9]+/g, "_")
    .replace(/^_+|_+$/g, "")
    .slice(0, 120);
}

function buildTempPassword(length = 14) {
  const alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789!@#$%";
  const buffer = crypto.randomBytes(length);
  let output = "";
  for (let i = 0; i < length; i += 1) {
    output += alphabet[buffer[i] % alphabet.length];
  }
  return output;
}

function hasMailerConfig() {
  return Boolean(process.env.MAIL_HOST && process.env.MAIL_USER && process.env.MAIL_PASS);
}

async function fetchAccounts(search = "") {
  const q = cleanString(search, { lower: true });
  const params = [];
  let whereClause = "";

  if (q) {
    whereClause = `
      WHERE LOWER(CONCAT(first_name, ' ', last_name)) LIKE ?
         OR LOWER(email) LIKE ?
         OR LOWER(role) LIKE ?
         OR LOWER(COALESCE(department, '')) LIKE ?
    `;
    const token = `%${q}%`;
    params.push(token, token, token, token);
  }

  const [rows] = await db.query(
    `
    SELECT
      id,
      first_name,
      last_name,
      email,
      role,
      department,
      is_active,
      password_reset_required,
      last_login_at,
      created_at,
      updated_at
    FROM users
    ${whereClause}
    ORDER BY
      FIELD(role, 'admin', 'recruiter', 'applicant'),
      created_at DESC
    `,
    params
  );

  return rows.map((row) => ({
    id: row.id,
    firstName: row.first_name,
    lastName: row.last_name,
    email: row.email,
    role: row.role,
    department: row.department || "",
    isActive: Boolean(row.is_active),
    passwordResetRequired: Boolean(row.password_reset_required),
    lastLoginAt: row.last_login_at,
    createdAt: row.created_at,
    updatedAt: row.updated_at,
  }));
}

async function fetchJobs() {
  let jobs = [];
  try {
    const [rows] = await db.query(
      `
      SELECT
        id,
        title,
        description,
        company_name,
        employment_type,
        work_setup,
        city,
        region,
        is_active,
        lifecycle_status,
        published_at,
        closed_at,
        archived_at,
        created_at,
        updated_at
      FROM jobs
      ORDER BY created_at DESC, id DESC
      `
    );
    jobs = rows;
  } catch (err) {
    if (err?.code !== "ER_BAD_FIELD_ERROR") throw err;
    const [legacyRows] = await db.query(
      `
      SELECT
        id,
        title,
        description,
        company_name,
        employment_type,
        work_setup,
        city,
        region,
        is_active,
        created_at,
        updated_at
      FROM jobs
      ORDER BY created_at DESC, id DESC
      `
    );
    jobs = legacyRows.map((row) => ({
      ...row,
      lifecycle_status: Boolean(row.is_active) ? "published" : "closed",
      published_at: Boolean(row.is_active) ? row.created_at : null,
      closed_at: Boolean(row.is_active) ? null : row.updated_at,
      archived_at: null,
    }));
  }

  const [skills] = await db.query(
    `
    SELECT
      id,
      job_id,
      skill_name,
      category,
      required,
      weight
    FROM job_skills
    WHERE job_id IS NOT NULL
    ORDER BY job_id ASC, required DESC, weight DESC, skill_name ASC
    `
  );

  const skillsByJobId = new Map();
  skills.forEach((row) => {
    if (!skillsByJobId.has(row.job_id)) {
      skillsByJobId.set(row.job_id, []);
    }
    skillsByJobId.get(row.job_id).push({
      id: row.id,
      name: row.skill_name,
      category: row.category || "",
      required: Boolean(row.required),
      weight: Number(row.weight ?? 0),
    });
  });

  return jobs.map((job) => ({
    id: job.id,
    title: job.title,
    description: job.description || "",
    companyName: job.company_name || "",
    employmentType: job.employment_type || "",
    workSetup: job.work_setup || "",
    city: job.city || "",
    region: job.region || "",
    isActive: Boolean(job.is_active),
    lifecycleStatus: normalizeJobLifecycleStatus(
      job.lifecycle_status,
      Boolean(job.is_active) ? "published" : "closed"
    ),
    publishedAt: job.published_at || null,
    closedAt: job.closed_at || null,
    archivedAt: job.archived_at || null,
    createdAt: job.created_at,
    updatedAt: job.updated_at,
    skills: skillsByJobId.get(job.id) || [],
  }));
}

async function fetchKnowledgeBaseRoles() {
  const [roles] = await db.query(
    `
    SELECT
      kr.id,
      kr.kb_role_key,
      kr.name,
      kr.industry,
      kr.level,
      rp.high_threshold,
      rp.moderate_threshold,
      rp.low_confidence_threshold,
      rp.critical_skill_penalty,
      kr.created_at,
      kr.updated_at
    FROM knowledgebase_roles kr
    LEFT JOIN knowledgebase_role_policy rp ON rp.role_id = kr.id
    ORDER BY kr.name ASC
    `
  );

  const [skills] = await db.query(
    `
    SELECT
      id,
      role_id,
      skill_name,
      aliases_json,
      category,
      required,
      weight,
      is_critical
    FROM knowledgebase_skills
    ORDER BY role_id ASC, required DESC, weight DESC, skill_name ASC
    `
  );

  const skillsByRoleId = new Map();
  skills.forEach((row) => {
    if (!skillsByRoleId.has(row.role_id)) {
      skillsByRoleId.set(row.role_id, []);
    }
    skillsByRoleId.get(row.role_id).push({
      id: row.id,
      name: row.skill_name,
      aliases: parseJsonArray(row.aliases_json),
      category: row.category || "",
      required: Boolean(row.required),
      weight: Number(row.weight ?? 0),
      isCritical: Boolean(row.is_critical),
    });
  });

  return roles.map((role) => ({
    id: role.id,
    kbRoleKey: role.kb_role_key,
    name: role.name,
    industry: role.industry || "",
    level: role.level || "",
    policy: {
      highThreshold: role.high_threshold === null ? 80 : Number(role.high_threshold),
      moderateThreshold: role.moderate_threshold === null ? 60 : Number(role.moderate_threshold),
      lowConfidenceThreshold:
        role.low_confidence_threshold === null ? 0.7 : Number(role.low_confidence_threshold),
      criticalSkillPenalty:
        role.critical_skill_penalty === null ? 15 : Number(role.critical_skill_penalty),
    },
    skills: skillsByRoleId.get(role.id) || [],
    createdAt: role.created_at,
    updatedAt: role.updated_at,
  }));
}

function extractReportSection(content = "", title = "") {
  const source = String(content || "");
  if (!source || !title) return "";
  const match = source.match(new RegExp(`${title}:\\n([\\s\\S]*?)(\\n\\n|$)`, "i"));
  return match?.[1] ? String(match[1]).trim() : "";
}

async function fetchAdminReports(limit = 120) {
  const boundedLimit = Math.min(Math.max(Number(limit || 120), 10), 500);
  const [summaryRows] = await db.query(
    `
    SELECT
      COUNT(*) AS generated_reports,
      SUM(CASE WHEN ja.status = 'completed' THEN 1 ELSE 0 END) AS completed_reports,
      SUM(CASE WHEN ja.status = 'endorsed' THEN 1 ELSE 0 END) AS endorsed_reports
    FROM interview_artifacts ia
    JOIN job_applications ja ON ja.id = ia.application_id
    WHERE ia.report_raw IS NOT NULL AND ia.report_raw <> ''
    `
  );

  const [pipelineRows] = await db.query(
    `
    SELECT
      ja.status,
      COUNT(*) AS total
    FROM job_applications ja
    GROUP BY ja.status
    `
  );

  const [roleRows] = await db.query(
    `
    SELECT
      j.title AS role_title,
      COUNT(*) AS total_apps,
      SUM(CASE WHEN ja.status IN ('completed','endorsed') THEN 1 ELSE 0 END) AS finalized_apps
    FROM job_applications ja
    JOIN jobs j ON j.id = ja.job_id
    GROUP BY j.title
    ORDER BY total_apps DESC, j.title ASC
    LIMIT 25
    `
  );

  const [recruiterRows] = await db.query(
    `
    SELECT
      al.actor_user_id AS recruiter_id,
      CONCAT(COALESCE(u.first_name, ''), ' ', COALESCE(u.last_name, '')) AS recruiter_name,
      u.email AS recruiter_email,
      COUNT(*) AS reports_generated,
      MAX(al.created_at) AS last_generated_at
    FROM audit_logs al
    LEFT JOIN users u ON u.id = al.actor_user_id
    WHERE al.action = 'report.generate'
    GROUP BY al.actor_user_id, recruiter_name, recruiter_email
    ORDER BY reports_generated DESC, last_generated_at DESC
    LIMIT 25
    `
  );

  const [recentRows] = await db.query(
    `
    SELECT
      ia.application_id,
      ia.report_raw,
      ia.updated_at AS report_updated_at,
      ja.status AS application_status,
      ja.applied_at,
      CONCAT(COALESCE(applicant.first_name, ''), ' ', COALESCE(applicant.last_name, '')) AS applicant_name,
      applicant.email AS applicant_email,
      j.title AS role_title
    FROM interview_artifacts ia
    JOIN job_applications ja ON ja.id = ia.application_id
    JOIN users applicant ON applicant.id = ja.user_id
    JOIN jobs j ON j.id = ja.job_id
    WHERE ia.report_raw IS NOT NULL AND ia.report_raw <> ''
    ORDER BY ia.updated_at DESC
    LIMIT ?
    `,
    [boundedLimit]
  );

  const statusTotals = {
    submitted: 0,
    processing: 0,
    completed: 0,
    endorsed: 0,
    rejected: 0,
  };
  pipelineRows.forEach((row) => {
    const key = String(row.status || "").trim().toLowerCase();
    if (Object.prototype.hasOwnProperty.call(statusTotals, key)) {
      statusTotals[key] = Number(row.total || 0);
    }
  });

  const summary = summaryRows[0] || {};
  return {
    summary: {
      generatedReports: Number(summary.generated_reports || 0),
      completedReports: Number(summary.completed_reports || 0),
      endorsedReports: Number(summary.endorsed_reports || 0),
      pipeline: statusTotals,
    },
    byRole: roleRows.map((row) => ({
      roleTitle: row.role_title,
      totalApplications: Number(row.total_apps || 0),
      finalizedApplications: Number(row.finalized_apps || 0),
    })),
    byRecruiter: recruiterRows.map((row) => ({
      recruiterId: row.recruiter_id,
      recruiterName: String(row.recruiter_name || "").trim() || "Unknown",
      recruiterEmail: row.recruiter_email || "",
      reportsGenerated: Number(row.reports_generated || 0),
      lastGeneratedAt: row.last_generated_at || null,
    })),
    recent: recentRows.map((row) => ({
      applicationId: row.application_id,
      applicantName: String(row.applicant_name || "").trim() || "Unknown Applicant",
      applicantEmail: row.applicant_email || "",
      roleTitle: row.role_title || "",
      status: row.application_status || "",
      appliedAt: row.applied_at,
      reportUpdatedAt: row.report_updated_at,
      recommendation: extractReportSection(row.report_raw, "Recommended Next Step"),
      summary: extractReportSection(row.report_raw, "Summary"),
    })),
  };
}

router.get("/overview", async (req, res) => {
  try {
    await ensureSeedPromptVersion();
    const [userCounts] = await db.query(
      `
      SELECT role, COUNT(*) AS total
      FROM users
      GROUP BY role
      `
    );
    let activeJobsRows = [{ total: 0 }];
    try {
      const [rows] = await db.query(
        `
        SELECT COUNT(*) AS total
        FROM jobs
        WHERE lifecycle_status = 'published'
        `
      );
      activeJobsRows = rows;
    } catch (err) {
      if (err?.code !== "ER_BAD_FIELD_ERROR") throw err;
      const [legacyRows] = await db.query(
        `
        SELECT COUNT(*) AS total
        FROM jobs
        WHERE is_active = 1
        `
      );
      activeJobsRows = legacyRows;
    }
    const [applicationCounts] = await db.query(
      `
      SELECT status, COUNT(*) AS total
      FROM job_applications
      GROUP BY status
      `
    );
    const [reportRows] = await db.query(
      `
      SELECT
        COUNT(*) AS totalReports,
        SUM(CASE WHEN report_raw IS NOT NULL AND report_raw <> '' THEN 1 ELSE 0 END) AS generatedReports
      FROM interview_artifacts
      `
    );
    const [recentUsageRows] = await db.query(
      `
      SELECT
        DATE(applied_at) AS day,
        COUNT(*) AS applications,
        SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) AS completed,
        SUM(CASE WHEN status = 'endorsed' THEN 1 ELSE 0 END) AS endorsed
      FROM job_applications
      WHERE applied_at >= DATE_SUB(CURDATE(), INTERVAL 14 DAY)
      GROUP BY DATE(applied_at)
      ORDER BY day ASC
      `
    );
    const [auditRows] = await db.query(
      `
      SELECT
        al.id,
        al.action,
        al.entity_type,
        al.entity_id,
        al.summary,
        al.created_at,
        u.first_name,
        u.last_name,
        u.email
      FROM audit_logs al
      LEFT JOIN users u ON u.id = al.actor_user_id
      ORDER BY al.created_at DESC
      LIMIT 12
      `
    );
    const promptVersions = await getPromptVersions();
    const activePrompt = promptVersions.find((version) => version.status === "published") || null;
    const [dbHealth] = await db.query("SELECT 1 AS ok");

    const usersByRole = {
      admin: 0,
      recruiter: 0,
      applicant: 0,
    };
    userCounts.forEach((row) => {
      usersByRole[row.role] = Number(row.total || 0);
    });

    const applicationsByStatus = {
      submitted: 0,
      processing: 0,
      completed: 0,
      endorsed: 0,
      rejected: 0,
    };
    applicationCounts.forEach((row) => {
      applicationsByStatus[row.status] = Number(row.total || 0);
    });

    res.json({
      health: {
        api: true,
        database: Boolean(dbHealth.length),
        openAiConfigured: Boolean(process.env.OPENAI_API_KEY),
        mailConfigured: hasMailerConfig(),
        jwtConfigured: Boolean(process.env.JWT_SECRET),
        uptimeSeconds: Math.floor(process.uptime()),
        nodeVersion: process.version,
        environment: process.env.NODE_ENV || "development",
      },
      usage: {
        usersByRole,
        activeJobs: Number(activeJobsRows[0]?.total || 0),
        applicationsByStatus,
        generatedReports: Number(reportRows[0]?.generatedReports || 0),
        promptVersions: promptVersions.length,
        activePromptVersion: activePrompt?.versionLabel || "Seed file",
      },
      recentUsage: recentUsageRows.map((row) => ({
        day: row.day,
        applications: Number(row.applications || 0),
        completed: Number(row.completed || 0),
        endorsed: Number(row.endorsed || 0),
      })),
      recentAuditLogs: auditRows.map((row) => ({
        id: row.id,
        actor:
          row.first_name || row.last_name
            ? `${row.first_name || ""} ${row.last_name || ""}`.trim()
            : row.email || "System",
        action: row.action,
        entityType: row.entity_type,
        entityId: row.entity_id,
        summary: row.summary,
        createdAt: row.created_at,
      })),
    });
  } catch (err) {
    console.error("[Admin][overview] error:", err);
    res.status(500).json({ message: "Failed to load admin overview" });
  }
});

router.get("/audit-logs", async (req, res) => {
  try {
    const limit = Math.min(Math.max(Number(req.query.limit || 50), 1), 200);
    const [rows] = await db.query(
      `
      SELECT
        al.id,
        al.action,
        al.entity_type,
        al.entity_id,
        al.summary,
        al.metadata_json,
        al.created_at,
        u.first_name,
        u.last_name,
        u.email
      FROM audit_logs al
      LEFT JOIN users u ON u.id = al.actor_user_id
      ORDER BY al.created_at DESC
      LIMIT ${limit}
      `
    );

    res.json(
      rows.map((row) => ({
        id: row.id,
        actor:
          row.first_name || row.last_name
            ? `${row.first_name || ""} ${row.last_name || ""}`.trim()
            : row.email || "System",
        action: row.action,
        entityType: row.entity_type,
        entityId: row.entity_id,
        summary: row.summary,
        metadata: parseJsonValue(row.metadata_json, null),
        createdAt: row.created_at,
      }))
    );
  } catch (err) {
    console.error("[Admin][audit-logs] error:", err);
    res.status(500).json({ message: "Failed to load audit logs" });
  }
});

router.get("/reports", async (req, res) => {
  try {
    const data = await fetchAdminReports(req.query.limit || 120);
    res.json(data);
  } catch (err) {
    console.error("[Admin][reports] error:", err);
    res.status(500).json({ message: "Failed to load admin reports" });
  }
});

router.get("/accounts", async (req, res) => {
  try {
    const accounts = await fetchAccounts(req.query.q || "");
    res.json(accounts);
  } catch (err) {
    console.error("[Admin][accounts:list] error:", err);
    res.status(500).json({ message: "Failed to load accounts" });
  }
});

router.post("/accounts", async (req, res) => {
  try {
    const firstName = cleanString(req.body.firstName);
    const lastName = cleanString(req.body.lastName);
    const email = cleanString(req.body.email, { lower: true });
    const role = cleanString(req.body.role, { lower: true });
    const department = cleanString(req.body.department);
    const requestedPassword = cleanString(req.body.password);
    const isActive = coerceBoolean(req.body.isActive, true);
    const passwordResetRequired = coerceBoolean(req.body.passwordResetRequired, true);

    if (!firstName || !lastName || !email) {
      return res.status(400).json({ message: "First name, last name, and email are required." });
    }
    if (!["recruiter", "admin", "applicant"].includes(role)) {
      return res.status(400).json({ message: "Role must be applicant, recruiter, or admin." });
    }

    const [existing] = await db.query("SELECT id FROM users WHERE email = ? LIMIT 1", [email]);
    if (existing.length) {
      return res.status(400).json({ message: "An account with that email already exists." });
    }

    const tempPassword = requestedPassword || buildTempPassword();
    if (tempPassword.length < 8) {
      return res.status(400).json({ message: "Password must be at least 8 characters." });
    }

    const passwordHash = await bcrypt.hash(tempPassword, 10);
    const [result] = await db.query(
      `
      INSERT INTO users (
        first_name,
        last_name,
        email,
        password_hash,
        role,
        department,
        is_active,
        password_reset_required
      )
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)
      `,
      [firstName, lastName, email, passwordHash, role, department || null, isActive ? 1 : 0, passwordResetRequired ? 1 : 0]
    );

    await writeAuditLog({
      actorUserId: req.user.id,
      action: "account.create",
      entityType: "user",
      entityId: result.insertId,
      summary: `Created ${role} account for ${email}`,
      metadata: { email, role, department, passwordResetRequired },
    });

    res.status(201).json({
      message: "Account created successfully.",
      userId: result.insertId,
      temporaryPassword: tempPassword,
    });
  } catch (err) {
    console.error("[Admin][accounts:create] error:", err);
    res.status(500).json({ message: "Failed to create account" });
  }
});

router.patch("/accounts/:id", async (req, res) => {
  try {
    const userId = Number(req.params.id);
    if (!Number.isFinite(userId)) {
      return res.status(400).json({ message: "Invalid user id." });
    }

    const [rows] = await db.query(
      "SELECT id, email, role, is_active FROM users WHERE id = ? LIMIT 1",
      [userId]
    );
    if (!rows.length) {
      return res.status(404).json({ message: "User not found." });
    }

    const current = rows[0];
    const firstName = cleanString(req.body.firstName);
    const lastName = cleanString(req.body.lastName);
    const email = cleanString(req.body.email, { lower: true });
    const role = cleanString(req.body.role, { lower: true });
    const department = cleanString(req.body.department);
    const isActive = coerceBoolean(req.body.isActive, Boolean(current.is_active));
    const passwordResetRequired = coerceBoolean(
      req.body.passwordResetRequired,
      false
    );

    if (!firstName || !lastName || !email) {
      return res.status(400).json({ message: "First name, last name, and email are required." });
    }
    if (!["recruiter", "admin", "applicant"].includes(role)) {
      return res.status(400).json({ message: "Invalid role." });
    }
    if (req.user.id === userId && !isActive) {
      return res.status(400).json({ message: "You cannot deactivate your own account." });
    }

    const [dupe] = await db.query(
      "SELECT id FROM users WHERE email = ? AND id <> ? LIMIT 1",
      [email, userId]
    );
    if (dupe.length) {
      return res.status(400).json({ message: "Email is already used by another account." });
    }

    await db.query(
      `
      UPDATE users
      SET
        first_name = ?,
        last_name = ?,
        email = ?,
        role = ?,
        department = ?,
        is_active = ?,
        password_reset_required = ?
      WHERE id = ?
      `,
      [firstName, lastName, email, role, department || null, isActive ? 1 : 0, passwordResetRequired ? 1 : 0, userId]
    );

    await writeAuditLog({
      actorUserId: req.user.id,
      action: "account.update",
      entityType: "user",
      entityId: userId,
      summary: `Updated account ${email}`,
      metadata: { email, role, department, isActive, passwordResetRequired },
    });

    res.json({ message: "Account updated successfully." });
  } catch (err) {
    console.error("[Admin][accounts:update] error:", err);
    res.status(500).json({ message: "Failed to update account" });
  }
});

router.post("/accounts/:id/reset-password", async (req, res) => {
  try {
    const userId = Number(req.params.id);
    if (!Number.isFinite(userId)) {
      return res.status(400).json({ message: "Invalid user id." });
    }

    const [rows] = await db.query(
      "SELECT id, email FROM users WHERE id = ? LIMIT 1",
      [userId]
    );
    if (!rows.length) {
      return res.status(404).json({ message: "User not found." });
    }

    const nextPassword = cleanString(req.body.password) || buildTempPassword();
    if (nextPassword.length < 8) {
      return res.status(400).json({ message: "Password must be at least 8 characters." });
    }

    const passwordHash = await bcrypt.hash(nextPassword, 10);
    await db.query(
      `
      UPDATE users
      SET password_hash = ?, password_reset_required = 1
      WHERE id = ?
      `,
      [passwordHash, userId]
    );

    await writeAuditLog({
      actorUserId: req.user.id,
      action: "account.reset_password",
      entityType: "user",
      entityId: userId,
      summary: `Reset password for ${rows[0].email}`,
      metadata: { email: rows[0].email },
    });

    res.json({
      message: "Password reset successfully.",
      temporaryPassword: nextPassword,
    });
  } catch (err) {
    console.error("[Admin][accounts:reset-password] error:", err);
    res.status(500).json({ message: "Failed to reset password" });
  }
});

router.get("/jobs", async (_req, res) => {
  try {
    const jobs = await fetchJobs();
    res.json(jobs);
  } catch (err) {
    console.error("[Admin][jobs:list] error:", err);
    res.status(500).json({ message: "Failed to load jobs" });
  }
});

router.post("/jobs", async (req, res) => {
  const connection = await db.getConnection();
  try {
    const title = cleanString(req.body.title);
    const description = cleanString(req.body.description);
    const companyName = cleanString(req.body.companyName);
    const employmentType = cleanString(req.body.employmentType);
    const workSetup = cleanString(req.body.workSetup);
    const city = cleanString(req.body.city);
    const region = cleanString(req.body.region);
    const isActive = coerceBoolean(req.body.isActive, true);
    const lifecycleStatus = normalizeJobLifecycleStatus(req.body.lifecycleStatus, isActive ? "published" : "draft");
    const lifecycle = deriveLifecycleSnapshot({ lifecycleStatus, isActive });
    const skills = sanitizeSkillRows(req.body.skills);

    if (!title) {
      connection.release();
      return res.status(400).json({ message: "Job title is required." });
    }

    await connection.beginTransaction();
    const [jobResult] = await connection.query(
      `
      INSERT INTO jobs (
        title,
        description,
        company_name,
        employment_type,
        work_setup,
        city,
        region,
        is_active,
        lifecycle_status,
        published_at,
        closed_at,
        archived_at
      )
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `,
      [
        title,
        description || null,
        companyName || null,
        employmentType || null,
        workSetup || null,
        city || null,
        region || null,
        lifecycle.isActive,
        lifecycle.lifecycleStatus,
        lifecycle.publishedAt,
        lifecycle.closedAt,
        lifecycle.archivedAt,
      ]
    );

    for (const skill of skills) {
      await connection.query(
        `
        INSERT INTO job_skills (
          job_id,
          job_name,
          skill_name,
          category,
          required,
          weight
        )
        VALUES (?, ?, ?, ?, ?, ?)
        `,
        [jobResult.insertId, title, skill.name, skill.category || null, skill.required ? 1 : 0, skill.weight]
      );
    }

    await connection.commit();
    connection.release();

    await writeAuditLog({
      actorUserId: req.user.id,
      action: "job.create",
      entityType: "job",
      entityId: jobResult.insertId,
      summary: `Created job posting ${title}`,
      metadata: { title, skills: skills.length, lifecycleStatus: lifecycle.lifecycleStatus },
    });

    res.status(201).json({ message: "Job created successfully." });
  } catch (err) {
    await connection.rollback();
    connection.release();
    console.error("[Admin][jobs:create] error:", err);
    res.status(500).json({ message: "Failed to create job" });
  }
});

router.patch("/jobs/:id", async (req, res) => {
  const connection = await db.getConnection();
  try {
    const jobId = Number(req.params.id);
    if (!Number.isFinite(jobId)) {
      connection.release();
      return res.status(400).json({ message: "Invalid job id." });
    }

    const title = cleanString(req.body.title);
    const description = cleanString(req.body.description);
    const companyName = cleanString(req.body.companyName);
    const employmentType = cleanString(req.body.employmentType);
    const workSetup = cleanString(req.body.workSetup);
    const city = cleanString(req.body.city);
    const region = cleanString(req.body.region);
    const isActive = coerceBoolean(req.body.isActive, true);
    const requestedLifecycleStatus = normalizeJobLifecycleStatus(
      req.body.lifecycleStatus,
      isActive ? "published" : "draft"
    );
    const skills = sanitizeSkillRows(req.body.skills);

    if (!title) {
      connection.release();
      return res.status(400).json({ message: "Job title is required." });
    }

    await connection.beginTransaction();
    const [rows] = await connection.query(
      `
      SELECT
        id,
        lifecycle_status,
        published_at,
        closed_at,
        archived_at
      FROM jobs
      WHERE id = ?
      LIMIT 1
      `,
      [jobId]
    );
    if (!rows.length) {
      await connection.rollback();
      connection.release();
      return res.status(404).json({ message: "Job not found." });
    }
    const lifecycle = deriveLifecycleSnapshot({
      lifecycleStatus: requestedLifecycleStatus,
      isActive,
      existing: rows[0],
    });

    await connection.query(
      `
      UPDATE jobs
      SET
        title = ?,
        description = ?,
        company_name = ?,
        employment_type = ?,
        work_setup = ?,
        city = ?,
        region = ?,
        is_active = ?,
        lifecycle_status = ?,
        published_at = ?,
        closed_at = ?,
        archived_at = ?
      WHERE id = ?
      `,
      [
        title,
        description || null,
        companyName || null,
        employmentType || null,
        workSetup || null,
        city || null,
        region || null,
        lifecycle.isActive,
        lifecycle.lifecycleStatus,
        lifecycle.publishedAt,
        lifecycle.closedAt,
        lifecycle.archivedAt,
        jobId,
      ]
    );

    await connection.query("DELETE FROM job_skills WHERE job_id = ?", [jobId]);
    for (const skill of skills) {
      await connection.query(
        `
        INSERT INTO job_skills (
          job_id,
          job_name,
          skill_name,
          category,
          required,
          weight
        )
        VALUES (?, ?, ?, ?, ?, ?)
        `,
        [jobId, title, skill.name, skill.category || null, skill.required ? 1 : 0, skill.weight]
      );
    }

    await connection.commit();
    connection.release();

    await writeAuditLog({
      actorUserId: req.user.id,
      action: "job.update",
      entityType: "job",
      entityId: jobId,
      summary: `Updated job posting ${title}`,
      metadata: {
        title,
        isActive: Boolean(lifecycle.isActive),
        lifecycleStatus: lifecycle.lifecycleStatus,
        skills: skills.length,
      },
    });

    res.json({ message: "Job updated successfully." });
  } catch (err) {
    await connection.rollback();
    connection.release();
    console.error("[Admin][jobs:update] error:", err);
    res.status(500).json({ message: "Failed to update job" });
  }
});

router.patch("/jobs/:id/lifecycle", async (req, res) => {
  const connection = await db.getConnection();
  try {
    const jobId = Number(req.params.id);
    if (!Number.isFinite(jobId)) {
      connection.release();
      return res.status(400).json({ message: "Invalid job id." });
    }

    const requestedStatus = normalizeJobLifecycleStatus(req.body?.lifecycleStatus, "");
    if (!JOB_LIFECYCLE_STATUSES.has(requestedStatus)) {
      connection.release();
      return res.status(400).json({ message: "Invalid lifecycle status." });
    }

    await connection.beginTransaction();
    const [rows] = await connection.query(
      `
      SELECT
        id,
        title,
        is_active,
        lifecycle_status,
        published_at,
        closed_at,
        archived_at
      FROM jobs
      WHERE id = ?
      LIMIT 1
      `,
      [jobId]
    );

    if (!rows.length) {
      await connection.rollback();
      connection.release();
      return res.status(404).json({ message: "Job not found." });
    }

    const existing = rows[0];
    const lifecycle = deriveLifecycleSnapshot({
      lifecycleStatus: requestedStatus,
      isActive: requestedStatus === "published",
      existing,
    });

    await connection.query(
      `
      UPDATE jobs
      SET
        is_active = ?,
        lifecycle_status = ?,
        published_at = ?,
        closed_at = ?,
        archived_at = ?
      WHERE id = ?
      `,
      [
        lifecycle.isActive,
        lifecycle.lifecycleStatus,
        lifecycle.publishedAt,
        lifecycle.closedAt,
        lifecycle.archivedAt,
        jobId,
      ]
    );

    await connection.commit();
    connection.release();

    await writeAuditLog({
      actorUserId: req.user.id,
      action: "job.lifecycle_update",
      entityType: "job",
      entityId: jobId,
      summary: `Set job ${existing.title || jobId} lifecycle to ${lifecycle.lifecycleStatus}`,
      metadata: { lifecycleStatus: lifecycle.lifecycleStatus },
    });

    res.json({
      message: "Job lifecycle updated successfully.",
      lifecycleStatus: lifecycle.lifecycleStatus,
      isActive: Boolean(lifecycle.isActive),
    });
  } catch (err) {
    await connection.rollback();
    connection.release();
    console.error("[Admin][jobs:lifecycle] error:", err);
    res.status(500).json({ message: "Failed to update lifecycle status" });
  }
});

router.get("/knowledgebase/roles", async (_req, res) => {
  try {
    const roles = await fetchKnowledgeBaseRoles();
    res.json(roles);
  } catch (err) {
    console.error("[Admin][kb:list] error:", err);
    res.status(500).json({ message: "Failed to load knowledge base" });
  }
});

router.post("/knowledgebase/roles", async (req, res) => {
  const connection = await db.getConnection();
  try {
    const name = cleanString(req.body.name);
    const industry = cleanString(req.body.industry);
    const level = cleanString(req.body.level);
    const kbRoleKey = slugifyRoleKey(req.body.kbRoleKey || name);
    const skills = sanitizeSkillRows(req.body.skills);
    const policy = req.body.policy || {};

    if (!name || !kbRoleKey) {
      connection.release();
      return res.status(400).json({ message: "Role name is required." });
    }

    await connection.beginTransaction();
    const [existingKey] = await connection.query(
      "SELECT id FROM knowledgebase_roles WHERE kb_role_key = ? LIMIT 1",
      [kbRoleKey]
    );
    if (existingKey.length) {
      await connection.rollback();
      connection.release();
      return res.status(400).json({ message: "Knowledge base role key already exists." });
    }

    const [roleResult] = await connection.query(
      `
      INSERT INTO knowledgebase_roles (kb_role_key, name, industry, level)
      VALUES (?, ?, ?, ?)
      `,
      [kbRoleKey, name, industry || null, level || null]
    );

    for (const skill of skills) {
      await connection.query(
        `
        INSERT INTO knowledgebase_skills (
          role_id,
          skill_name,
          aliases_json,
          category,
          required,
          weight,
          is_critical
        )
        VALUES (?, ?, ?, ?, ?, ?, ?)
        `,
        [
          roleResult.insertId,
          skill.name,
          JSON.stringify(skill.aliases),
          skill.category || null,
          skill.required ? 1 : 0,
          skill.weight,
          skill.isCritical ? 1 : 0,
        ]
      );
    }

    await connection.query(
      `
      INSERT INTO knowledgebase_role_policy (
        role_id,
        high_threshold,
        moderate_threshold,
        low_confidence_threshold,
        critical_skill_penalty
      )
      VALUES (?, ?, ?, ?, ?)
      `,
      [
        roleResult.insertId,
        Number(policy.highThreshold ?? 80),
        Number(policy.moderateThreshold ?? 60),
        Number(policy.lowConfidenceThreshold ?? 0.7),
        Number(policy.criticalSkillPenalty ?? 15),
      ]
    );

    await connection.commit();
    connection.release();

    await writeAuditLog({
      actorUserId: req.user.id,
      action: "knowledgebase.create_role",
      entityType: "knowledgebase_role",
      entityId: roleResult.insertId,
      summary: `Created knowledge base role ${name}`,
      metadata: { kbRoleKey, skills: skills.length },
    });

    res.status(201).json({ message: "Knowledge base role created successfully." });
  } catch (err) {
    await connection.rollback();
    connection.release();
    console.error("[Admin][kb:create] error:", err);
    res.status(500).json({ message: "Failed to create knowledge base role" });
  }
});

router.patch("/knowledgebase/roles/:id", async (req, res) => {
  const connection = await db.getConnection();
  try {
    const roleId = Number(req.params.id);
    if (!Number.isFinite(roleId)) {
      connection.release();
      return res.status(400).json({ message: "Invalid role id." });
    }

    const name = cleanString(req.body.name);
    const industry = cleanString(req.body.industry);
    const level = cleanString(req.body.level);
    const kbRoleKey = slugifyRoleKey(req.body.kbRoleKey || name);
    const skills = sanitizeSkillRows(req.body.skills);
    const policy = req.body.policy || {};

    if (!name || !kbRoleKey) {
      connection.release();
      return res.status(400).json({ message: "Role name is required." });
    }

    await connection.beginTransaction();
    const [rows] = await connection.query(
      "SELECT id FROM knowledgebase_roles WHERE id = ? LIMIT 1",
      [roleId]
    );
    if (!rows.length) {
      await connection.rollback();
      connection.release();
      return res.status(404).json({ message: "Role not found." });
    }

    const [dupeKey] = await connection.query(
      "SELECT id FROM knowledgebase_roles WHERE kb_role_key = ? AND id <> ? LIMIT 1",
      [kbRoleKey, roleId]
    );
    if (dupeKey.length) {
      await connection.rollback();
      connection.release();
      return res.status(400).json({ message: "Knowledge base role key already exists." });
    }

    await connection.query(
      `
      UPDATE knowledgebase_roles
      SET kb_role_key = ?, name = ?, industry = ?, level = ?
      WHERE id = ?
      `,
      [kbRoleKey, name, industry || null, level || null, roleId]
    );

    await connection.query("DELETE FROM knowledgebase_skills WHERE role_id = ?", [roleId]);
    for (const skill of skills) {
      await connection.query(
        `
        INSERT INTO knowledgebase_skills (
          role_id,
          skill_name,
          aliases_json,
          category,
          required,
          weight,
          is_critical
        )
        VALUES (?, ?, ?, ?, ?, ?, ?)
        `,
        [
          roleId,
          skill.name,
          JSON.stringify(skill.aliases),
          skill.category || null,
          skill.required ? 1 : 0,
          skill.weight,
          skill.isCritical ? 1 : 0,
        ]
      );
    }

    await connection.query(
      `
      INSERT INTO knowledgebase_role_policy (
        role_id,
        high_threshold,
        moderate_threshold,
        low_confidence_threshold,
        critical_skill_penalty
      )
      VALUES (?, ?, ?, ?, ?)
      ON DUPLICATE KEY UPDATE
        high_threshold = VALUES(high_threshold),
        moderate_threshold = VALUES(moderate_threshold),
        low_confidence_threshold = VALUES(low_confidence_threshold),
        critical_skill_penalty = VALUES(critical_skill_penalty)
      `,
      [
        roleId,
        Number(policy.highThreshold ?? 80),
        Number(policy.moderateThreshold ?? 60),
        Number(policy.lowConfidenceThreshold ?? 0.7),
        Number(policy.criticalSkillPenalty ?? 15),
      ]
    );

    await connection.commit();
    connection.release();

    await writeAuditLog({
      actorUserId: req.user.id,
      action: "knowledgebase.update_role",
      entityType: "knowledgebase_role",
      entityId: roleId,
      summary: `Updated knowledge base role ${name}`,
      metadata: { kbRoleKey, skills: skills.length },
    });

    res.json({ message: "Knowledge base role updated successfully." });
  } catch (err) {
    await connection.rollback();
    connection.release();
    console.error("[Admin][kb:update] error:", err);
    res.status(500).json({ message: "Failed to update knowledge base role" });
  }
});

router.get("/prompts", async (_req, res) => {
  try {
    const versions = await getPromptVersions();
    res.json(versions);
  } catch (err) {
    console.error("[Admin][prompts:list] error:", err);
    res.status(500).json({ message: "Failed to load prompt versions" });
  }
});

router.get("/prompts/active", async (_req, res) => {
  try {
    const prompt = await getActivePromptConfig();
    res.json(prompt);
  } catch (err) {
    console.error("[Admin][prompts:active] error:", err);
    res.status(500).json({ message: "Failed to load active prompt" });
  }
});

router.post("/prompts", async (req, res) => {
  try {
    await ensureSeedPromptVersion();
    const payload = normalizePromptConfig(req.body);
    const versionLabel = cleanString(req.body.versionLabel) || `draft-${Date.now()}`;
    const notes = cleanString(req.body.notes);

    if (!payload.master_prompt) {
      return res.status(400).json({ message: "Master prompt is required." });
    }
    if (!Object.keys(payload.tasks).length) {
      return res.status(400).json({ message: "At least one task prompt is required." });
    }

    const [dupe] = await db.query(
      "SELECT id FROM prompt_versions WHERE version_label = ? LIMIT 1",
      [versionLabel]
    );
    if (dupe.length) {
      return res.status(400).json({ message: "Version label already exists." });
    }

    const [result] = await db.query(
      `
      INSERT INTO prompt_versions (
        version_label,
        master_prompt,
        tasks_json,
        notes,
        status,
        created_by
      )
      VALUES (?, ?, ?, ?, 'draft', ?)
      `,
      [versionLabel, payload.master_prompt, JSON.stringify(payload.tasks), notes || null, req.user.id]
    );

    await writeAuditLog({
      actorUserId: req.user.id,
      action: "prompt.create_version",
      entityType: "prompt_version",
      entityId: result.insertId,
      summary: `Created prompt version ${versionLabel}`,
      metadata: { versionLabel },
    });

    res.status(201).json({ message: "Prompt version created successfully." });
  } catch (err) {
    console.error("[Admin][prompts:create] error:", err);
    res.status(500).json({ message: "Failed to create prompt version" });
  }
});

router.patch("/prompts/:id", async (req, res) => {
  try {
    const promptId = Number(req.params.id);
    if (!Number.isFinite(promptId)) {
      return res.status(400).json({ message: "Invalid prompt version id." });
    }

    const existing = await getPromptVersionById(promptId);
    if (!existing) {
      return res.status(404).json({ message: "Prompt version not found." });
    }
    if (existing.status !== "draft") {
      return res.status(400).json({ message: "Only draft prompt versions can be edited." });
    }

    const payload = normalizePromptConfig(req.body);
    const versionLabel = cleanString(req.body.versionLabel) || existing.versionLabel;
    const notes = cleanString(req.body.notes);

    if (!payload.master_prompt) {
      return res.status(400).json({ message: "Master prompt is required." });
    }
    if (!Object.keys(payload.tasks).length) {
      return res.status(400).json({ message: "At least one task prompt is required." });
    }

    const [dupe] = await db.query(
      "SELECT id FROM prompt_versions WHERE version_label = ? AND id <> ? LIMIT 1",
      [versionLabel, promptId]
    );
    if (dupe.length) {
      return res.status(400).json({ message: "Version label already exists." });
    }

    await db.query(
      `
      UPDATE prompt_versions
      SET version_label = ?, master_prompt = ?, tasks_json = ?, notes = ?
      WHERE id = ?
      `,
      [versionLabel, payload.master_prompt, JSON.stringify(payload.tasks), notes || null, promptId]
    );

    await writeAuditLog({
      actorUserId: req.user.id,
      action: "prompt.update_version",
      entityType: "prompt_version",
      entityId: promptId,
      summary: `Updated draft prompt version ${versionLabel}`,
      metadata: { versionLabel },
    });

    res.json({ message: "Prompt version updated successfully." });
  } catch (err) {
    console.error("[Admin][prompts:update] error:", err);
    res.status(500).json({ message: "Failed to update prompt version" });
  }
});

router.post("/prompts/:id/publish", async (req, res) => {
  const connection = await db.getConnection();
  try {
    const promptId = Number(req.params.id);
    if (!Number.isFinite(promptId)) {
      connection.release();
      return res.status(400).json({ message: "Invalid prompt version id." });
    }

    const version = await getPromptVersionById(promptId);
    if (!version) {
      connection.release();
      return res.status(404).json({ message: "Prompt version not found." });
    }

    await connection.beginTransaction();
    await connection.query(
      "UPDATE prompt_versions SET status = 'archived' WHERE status = 'published'"
    );
    await connection.query(
      `
      UPDATE prompt_versions
      SET status = 'published', published_at = NOW(), published_by = ?
      WHERE id = ?
      `,
      [req.user.id, promptId]
    );
    await connection.commit();
    connection.release();

    await writeAuditLog({
      actorUserId: req.user.id,
      action: "prompt.publish_version",
      entityType: "prompt_version",
      entityId: promptId,
      summary: `Published prompt version ${version.versionLabel}`,
      metadata: { versionLabel: version.versionLabel },
    });

    res.json({ message: "Prompt version published successfully." });
  } catch (err) {
    await connection.rollback();
    connection.release();
    console.error("[Admin][prompts:publish] error:", err);
    res.status(500).json({ message: "Failed to publish prompt version" });
  }
});

export default router;
