import express from 'express';
import bcrypt from 'bcryptjs';
import { db } from '../db.js';
import jwt from 'jsonwebtoken';
import { transporter } from '../utils/mailer.js';
import { checkAuth } from '../checkAuth.js';
import { writeAuditLog } from "../utils/auditLog.js";



const router = express.Router();

function createAuthToken(user) {
    return jwt.sign(
        {
            id: user.id,
            email: user.email,
            role: user.role,
            firstName: user.first_name,
            lastName: user.last_name
        },
        process.env.JWT_SECRET,
        {expiresIn: "4h"}
    );
}

function rejectInactiveUser(user, res) {
    if (!Boolean(user?.is_active)) {
        res.status(403).json({ message: "Account is inactive. Contact an administrator." });
        return true;
    }

    return false;
}

async function finalizeLogin(user, res) {
    await db.query(
        "UPDATE users SET last_login_at = NOW() WHERE id = ?",
        [user.id]
    );

    const token = createAuthToken(user);
    return res.status(200).json({
        message: 'Login successful',
        token,
        user: {
            id: user.id,
            firstName: user.first_name,
            lastName: user.last_name,
            email: user.email,
            role: user.role,
            department: user.department || "",
            isActive: Boolean(user.is_active),
            passwordResetRequired: Boolean(user.password_reset_required),
        }
    });
}

//sign up endpoint
router.post('/applicant/signup', async (req, res) => {
    try{
        const { firstName, lastName, email, password } = req.body;


        //check if email is already used by another user
        const [existing] = await db.query(
            `SELECT * FROM users WHERE email = ?`,
            [email]
        );

        if(existing.length > 0) {
            return res.status(400).json({ message: 'Email already registered'});
        }

        //password encryption (hashing)
        const salt = 10;
        const password_hash = await bcrypt.hash(password, salt);

        //insert user data to db
        await db.query(
            'INSERT INTO users (first_name, last_name, email, password_hash) VALUES (?, ?, ?, ?)',
            [firstName, lastName, email, password_hash]
        );


        return res.status(201).json({ message: 'Signup successful'});

    }catch (err) {
        console.error('[SIGNUP ERROR]', err);
        return res.status(500).json({ message: 'Server error'});
    }
});


//login endpoint for user
router.post('/applicant/login', async (req, res) => {
    try{
        const {email, password} = req.body;

        const [rows] = await db.query(
            'SELECT * FROM users WHERE email = ? and role = ? ',
            [email, 'applicant']
        );
        
        if(rows.length === 0) {
            return res.status(400).json({ message: 'Invalid email or password'});
        }

        const user = rows[0];
        if (rejectInactiveUser(user, res)) {
            return;
        }

        //compare entered password to password hsah stored in db
        const isMatch = await bcrypt.compare(password, user.password_hash);

        if(!isMatch) {
            return res.status(400).json({ message: 'Invalid email or password.'});
        }


        return finalizeLogin(user, res);
    } catch (err) {
        console.error(err);
        return res.status(500).json({ message: 'Server error'});
    }
});

// login endpoint for recruiter
router.post('/recruiter/login', async (req, res) => {
    try {
        const { email, password } = req.body;

        const [rows] = await db.query(
            'SELECT * FROM users WHERE email = ? AND role = "recruiter"',
            [email]
        );

        if (rows.length === 0) {
            return res.status(400).json({ message: 'Invalid email or password' });
        }

        const user = rows[0];
        if (rejectInactiveUser(user, res)) {
            return;
        }

        // compare entered password to hash stored in db
        const isMatch = await bcrypt.compare(password, user.password_hash);

        if (!isMatch) {
            return res.status(400).json({ message: 'Invalid email or password' });
        }

        return finalizeLogin(user, res);
    } catch (err) {
        console.error(err);
        return res.status(500).json({ message: 'Server error' });
    }
});

router.post('/admin/login', async (req, res) => {
    try {
        const { email, password } = req.body;

        const [rows] = await db.query(
            'SELECT * FROM users WHERE email = ? AND role = "admin"',
            [email]
        );

        if (rows.length === 0) {
            return res.status(400).json({ message: 'Invalid email or password' });
        }

        const user = rows[0];
        if (rejectInactiveUser(user, res)) {
            return;
        }
        const isMatch = await bcrypt.compare(password, user.password_hash);

        if (!isMatch) {
            return res.status(400).json({ message: 'Invalid email or password' });
        }

        await writeAuditLog({
          actorUserId: user.id,
          action: "auth.admin_login",
          entityType: "user",
          entityId: user.id,
          summary: `Admin login for ${user.email}`,
        });

        return finalizeLogin(user, res);
    } catch (err) {
        console.error(err);
        return res.status(500).json({ message: 'Server error' });
    }
});


    //request password reset process
    router.post('/request-reset', async (req, res) =>{
        const { email } = req.body;

        try {
            //check if user exists
            const [users] = await db.query(
                'SELECT id FROM users WHERE email = ?',
                [email]
            );

            if (users.length === 0) {
                return res.status(400).json({ message: 'Email not found'});
            }

            //overwrite existing password reset code
            await db.query(
                'DELETE FROM password_resets where EMAIL = ?',
                [email]
            );

            //generate 6-character password reset code
            function generateResetCode(length = 6){
                const chars = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";
                let code = "";
                for (let i = 0; i < length; i++) {
                    code += chars[Math.floor(Math.random() * chars.length)];
                }
                return code;
            }

            const code = generateResetCode();
            const expiresAt = new Date(Date.now() + 15 * 60 * 1000) //15 minutees before code expires

            //store code in password_reset table for validation
            await db.query(
                'INSERT INTO password_resets (email, code, expires_at) VALUES (?, ?, ?)',
                [email, code, expiresAt]
            );

            //send psasword reset code to users' email
            await transporter.sendMail({
                from: '"SpeecFlo Support"',
                to: email,
                subject: 'Your password reset code',
                text: `You request a password reset.\n\nYour code is: ${code}\n\nIT expires in 15 minutes.`,
            });

            //respond to server to confirm
            res.json({ message: "Reset code sent to user."});

        } catch (err) {
            console.error(err);
            res.status(500).json({ message: "Server error."});
        }
    });

    //verify reset code endpoint
    router.post("/verify-reset-code", async (req, res) => {
const { email, code } = req.body;

    try {

        //check if code exists for this email
        const [codes] = await db.query(
            "SELECT * FROM password_resets WHERE email = ? AND code = ? ",
            [email, code]
        );

        if (codes.length === 0) {
            return res.status(400).json({ message: "Invalid code."});
        }

        //check expiration
        const reset = codes[0];
        if(new Date(reset.expires_at) < new Date()) {
            return res.status(400).json({ message: "Code is expired."});
        }

        //code is valid
        res.json({ message: "Code verified successfully."});

    } catch (err) {
        console.error(err);
        res.status(500).json({ message: "Server error"});
    }
});

//update password in db afte confirming code
router.post("/reset-password", async (req, res) => {
    const { email, code, newPassword } = req.body;

    try {

        //verify code exists for this email
        const [codes] = await db.query(
            "SELECT * FROM password_resets WHERE email = ? AND code = ?",
            [email, code]
        );

        if (codes.length === 0) {
            return res.status(400).json({ message: "Invalid reset code."});
        }

        const reset = codes[0];

        //check if code is still valid
        if(new Date(reset.expires_at) < new Date()) {
            return res.status(400).json({ message: "Reset code is expired."});
        }

        //hash the new password
        const salt = 10;
        const password_hash = await bcrypt.hash(newPassword, salt);

        //update the users password
        await db.query(
            "UPDATE users SET password_hash = ? WHERE email = ?",
            [password_hash, email]
        );

        //delete the reset code
        await db.query("DELETE FROM password_resets WHERE email = ?", [email]);

        //respond to server
        res.json({ message: "Password reset successful."});
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: "Server error."});
    }
});

router.get("/account", checkAuth, async (req, res) => {
  try {
    const [rows] = await db.query(
      "SELECT id, first_name, last_name, email, role, department, is_active, password_reset_required, last_login_at, created_at, updated_at FROM users WHERE id = ? LIMIT 1",
      [req.user.id]
    );

    if (!rows.length) {
      return res.status(404).json({ message: "User not found" });
    }

    const user = rows[0];
    return res.json({
      id: user.id,
      firstName: user.first_name,
      lastName: user.last_name,
      email: user.email,
      role: user.role,
      department: user.department || "",
      isActive: Boolean(user.is_active),
      passwordResetRequired: Boolean(user.password_reset_required),
      lastLoginAt: user.last_login_at,
      createdAt: user.created_at,
      updatedAt: user.updated_at,
    });
  } catch (err) {
    console.error("[AUTH][GET /account] error:", err);
    return res.status(500).json({ message: "Server error" });
  }
});

router.put("/account", checkAuth, async (req, res) => {
  try {
    const { firstName, lastName, email, department } = req.body;
    const cleanFirst = String(firstName || "").trim();
    const cleanLast = String(lastName || "").trim();
    const cleanEmail = String(email || "").trim().toLowerCase();
    const cleanDepartment = String(department || "").trim();

    if (!cleanFirst || !cleanLast || !cleanEmail) {
      return res.status(400).json({ message: "First name, last name, and email are required." });
    }

    const [dupe] = await db.query(
      "SELECT id FROM users WHERE email = ? AND id <> ? LIMIT 1",
      [cleanEmail, req.user.id]
    );
    if (dupe.length) {
      return res.status(400).json({ message: "Email is already in use." });
    }

    await db.query(
      "UPDATE users SET first_name = ?, last_name = ?, email = ?, department = ? WHERE id = ?",
      [cleanFirst, cleanLast, cleanEmail, cleanDepartment || null, req.user.id]
    );

    return res.json({ message: "Account updated successfully." });
  } catch (err) {
    console.error("[AUTH][PUT /account] error:", err);
    return res.status(500).json({ message: "Server error" });
  }
});

router.post("/change-password", checkAuth, async (req, res) => {
  try {
    const { currentPassword, newPassword } = req.body;
    const current = String(currentPassword || "");
    const next = String(newPassword || "");

    if (!current || !next) {
      return res.status(400).json({ message: "Current and new password are required." });
    }
    if (next.length < 8) {
      return res.status(400).json({ message: "New password must be at least 8 characters." });
    }

    const [rows] = await db.query(
      "SELECT id, password_hash FROM users WHERE id = ? LIMIT 1",
      [req.user.id]
    );
    if (!rows.length) {
      return res.status(404).json({ message: "User not found" });
    }

    const user = rows[0];
    const valid = await bcrypt.compare(current, user.password_hash);
    if (!valid) {
      return res.status(400).json({ message: "Current password is incorrect." });
    }

    const salt = 10;
    const passwordHash = await bcrypt.hash(next, salt);
    await db.query("UPDATE users SET password_hash = ? WHERE id = ?", [passwordHash, req.user.id]);

    return res.json({ message: "Password changed successfully." });
  } catch (err) {
    console.error("[AUTH][POST /change-password] error:", err);
    return res.status(500).json({ message: "Server error" });
  }
});

// check current user (fresh from DB so profile edits show immediately)
router.get('/me', checkAuth, async (req, res) => {
  try {
    const [rows] = await db.query(
      "SELECT id, first_name, last_name, email, role, department, is_active, password_reset_required, last_login_at FROM users WHERE id = ? LIMIT 1",
      [req.user.id]
    );

    if (!rows.length) {
      return res.status(404).json({ message: "User not found" });
    }

    const user = rows[0];
    return res.json({
      id: user.id,
      firstName: user.first_name,
      lastName: user.last_name,
      email: user.email,
      role: user.role,
      department: user.department || "",
      isActive: Boolean(user.is_active),
      passwordResetRequired: Boolean(user.password_reset_required),
      lastLoginAt: user.last_login_at,
    });
  } catch (err) {
    console.error("[AUTH][GET /me] error:", err);
    return res.status(500).json({ message: "Server error" });
  }
});


export default router;
