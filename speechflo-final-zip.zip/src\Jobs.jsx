import { useEffect, useMemo, useState } from "react";
import { Link } from "react-router-dom";
import { apiUrl } from "./api";

export default function Jobs() {
  const [jobs, setJobs] = useState([]);
  const [appliedJobIds, setAppliedJobIds] = useState(new Set());
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    let alive = true;

    const loadJobs = async () => {
      setLoading(true);
      setError("");
      try {
        const res = await fetch(apiUrl("/public/jobs"));
        if (!res.ok) {
          const text = await res.text();
          throw new Error(text || "Failed to load jobs.");
        }
        const data = await res.json();
        if (alive) {
          setJobs(Array.isArray(data) ? data : []);
        }

        const token = localStorage.getItem("token");
        if (token) {
          const myRes = await fetch(apiUrl("/applications/my"), {
            headers: { Authorization: `Bearer ${token}` },
          });
          if (myRes.ok) {
            const apps = await myRes.json();
            if (alive) {
              setAppliedJobIds(
                new Set(
                  (Array.isArray(apps) ? apps : [])
                    .map((app) => Number(app.job_id))
                    .filter((id) => Number.isFinite(id))
                )
              );
            }
          }
        }
      } catch (err) {
        if (alive) {
          setError(err.message || "Failed to load jobs.");
        }
      } finally {
        if (alive) setLoading(false);
      }
    };

    loadJobs();
    return () => {
      alive = false;
    };
  }, []);

  const content = useMemo(() => {
    if (loading) {
      return (
        <div className="text-sm text-slate-700 rounded-xl border border-slate-200 bg-white p-5">
          Loading jobs...
        </div>
      );
    }

    if (error) {
      return (
        <div className="text-sm text-rose-700 rounded-xl border border-rose-200 bg-rose-50 p-5">
          {error}
        </div>
      );
    }

    if (!jobs.length) {
      return (
        <div className="text-sm text-slate-700 rounded-xl border border-slate-200 bg-white p-5">
          No active jobs are available right now.
        </div>
      );
    }

    return (
      <div className="w-full max-w-7xl mx-auto px-6 md:px-16 py-10 grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-8">
        {jobs.map((job) => (
          <JobCard
            key={job.id}
            job={job}
            isApplied={appliedJobIds.has(Number(job.id))}
          />
        ))}
      </div>
    );
  }, [loading, error, jobs, appliedJobIds]);

  return (
    <div className="w-screen min-h-screen app-bg overflow-x-hidden">
      <div className="bg-[#E6F0FA] py-4 px-10 relative shadow-md">
        <div className="max-w-7xl mx-auto flex items-center gap-4">
          <div className="relative">
            <img
              src="/worker.png"
              alt="Workers"
              className="h-20 w-auto object-contain scale-135 -mt-4 origin-left"
            />
          </div>
          <span className="font-extrabold text-3xl text-slate-900 tracking-wide pl-18">
            JOBS
          </span>
        </div>
      </div>

      {content}
    </div>
  );
}

function JobCard({ job, isApplied }) {
  const summary =
    String(job.description || "")
      .replace(/\s+/g, " ")
      .trim() || "No description provided yet.";

  return (
    <Link to={`/jobs/${job.id}`} className="block h-full">
      <div className="group relative flex h-full min-h-[320px] min-w-0 flex-col overflow-hidden rounded-xl border border-slate-100 bg-white shadow-md transition-shadow duration-300 hover:shadow-lg">
        <div className="flex flex-1 flex-col px-5 py-5">
          <div className="flex items-start justify-between gap-3">
            <h3 className="text-base font-semibold text-slate-900 leading-snug">
              {job.title}
            </h3>
            <span className="text-[11px] rounded-full bg-sky-100 text-sky-800 px-2 py-1 font-semibold">
              Job #{job.id}
            </span>
          </div>

          <div className="mt-2 min-h-[20px]">
            {isApplied ? (
              <span className="text-[11px] rounded-full bg-emerald-100 text-emerald-800 px-2 py-1 font-semibold">
                Applied
              </span>
            ) : null}
          </div>

          <p className="mt-2 min-h-[5.5rem] text-sm text-slate-600 line-clamp-4">{summary}</p>

          <div className="mt-4 flex min-h-[3.5rem] flex-wrap content-start gap-2">
            {job.companyName ? (
              <span className="text-xs bg-slate-100 text-slate-700 px-2 py-1 rounded-full">
                {job.companyName}
              </span>
            ) : null}
            {job.employmentType ? (
              <span className="text-xs bg-slate-100 text-slate-700 px-2 py-1 rounded-full">
                {job.employmentType}
              </span>
            ) : null}
            {job.workSetup ? (
              <span className="text-xs bg-slate-100 text-slate-700 px-2 py-1 rounded-full">
                {job.workSetup}
              </span>
            ) : null}
            {job.city || job.region ? (
              <span className="text-xs bg-slate-100 text-slate-700 px-2 py-1 rounded-full">
                {[job.city, job.region].filter(Boolean).join(", ")}
              </span>
            ) : null}
          </div>
        </div>

        <div className="px-5 py-4 text-center bg-[#2a9df4] rounded-b-xl">
          <span className="text-sm font-semibold text-[#0B1456]">View Details</span>
        </div>
      </div>
    </Link>
  );
}
