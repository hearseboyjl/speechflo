﻿import Menubar from "../components/Menubar";
import { useEffect, useMemo, useState } from "react";
import { applyTheme, getSavedTheme } from "../theme";
import { useNavigate } from "react-router-dom";
import { apiUrl } from "../api";
import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell,
  ScatterChart,
  Scatter,
} from "recharts";

const PIE_COLORS = ["#10b981", "#38bdf8", "#f59e0b"];

export default function Analytics() {
  useEffect(() => {
    applyTheme(getSavedTheme());
  }, []);

  const navigate = useNavigate();
  const [filters, setFilters] = useState({
    role: "All Roles",
    date: "Date",
  });
  const [roleOptions, setRoleOptions] = useState(["All Roles"]);
  const [loading, setLoading] = useState(true);
  const [data, setData] = useState({
    stats: {
      interviewsUploaded: 0,
      completionRate: 0,
      rejectionRate: 0,
      avgSkillValidationConfidence: 0,
      avgExperienceAlignment: 0,
      avgCommunicationClarity: 0,
      candidateDifferentiationIndex: 0,
      lowConfidenceRate: 0,
      manualReviewQueue: 0,
      medianTimeToCompletionDays: 0,
      p90TimeToCompletionDays: 0,
    },
    distribution: { high: 0, medium: 0, low: 0 },
    topicCoverage: [],
    missingSkills: [],
    candidates: [],
    charts: {
      timeline: [],
      histogram: [],
      rolePerformance: [],
      confidenceVsScore: [],
    },
  });

  useEffect(() => {
    const token = localStorage.getItem("token");
    if (!token) {
      navigate("/recruiter/login");
      return;
    }

    const verifyUser = async () => {
      try {
        const res = await fetch(apiUrl("/auth/me"), {
          headers: { Authorization: `Bearer ${token}` },
        });
        if (!res.ok) throw new Error("Unauthorized");
        const me = await res.json();
        localStorage.setItem("user", me.firstName || "User");
      } catch {
        localStorage.removeItem("token");
        localStorage.removeItem("user");
        navigate("/recruiter/login");
      }
    };
    verifyUser();
  }, [navigate]);

  const fetchSummary = async (nextFilters = filters) => {
    const token = localStorage.getItem("token");
    if (!token) return;

    setLoading(true);
    try {
      const params = new URLSearchParams();
      params.set("role", nextFilters.role);
      params.set("date", nextFilters.date);

      const res = await fetch(apiUrl(`/analytics/summary?${params.toString()}`), {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (!res.ok) {
        const text = await res.text();
        throw new Error(text || "Failed to load analytics");
      }
      const payload = await res.json();
      setData({
        stats: payload.stats || data.stats,
        distribution: payload.distribution || data.distribution,
        topicCoverage: payload.topicCoverage || [],
        missingSkills: payload.missingSkills || [],
        candidates: payload.candidates || [],
        charts: payload.charts || data.charts,
      });
      if (payload.filters?.roleOptions?.length) {
        setRoleOptions(payload.filters.roleOptions);
      }
    } catch (err) {
      console.error("[Analytics] fetch failed:", err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchSummary(filters);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
  function onChange(e) {
    setFilters((p) => ({ ...p, [e.target.name]: e.target.value }));
  }

  function onApply() {
    fetchSummary(filters);
  }

  const kpis = useMemo(
    () => [
      { label: "Interviews Uploaded", value: loading ? "--" : data.stats.interviewsUploaded },
      { label: "Finalized", value: loading ? "--" : `${Math.round(data.stats.completionRate * 100)}%` },
      { label: "Endorsed", value: loading ? "--" : data.stats.endorsedCount ?? 0 },
      { label: "Rejected", value: loading ? "--" : `${Math.round(data.stats.rejectionRate * 100)}%` },
      { label: "Avg Match Score", value: loading ? "--" : data.stats.avgExperienceAlignment.toFixed(2) },
      { label: "Low Confidence", value: loading ? "--" : `${Math.round(data.stats.lowConfidenceRate * 100)}%` },
      { label: "To-Check List", value: loading ? "--" : data.stats.manualReviewQueue },
      { label: "Median TAT (days)", value: loading ? "--" : data.stats.medianTimeToCompletionDays.toFixed(1) },
      { label: "P90 TAT (days)", value: loading ? "--" : data.stats.p90TimeToCompletionDays.toFixed(1) },
    ],
    [data, loading]
  );

  const distributionPie = [
    { name: "High", value: data.distribution.high },
    { name: "Medium", value: data.distribution.medium },
    { name: "Low", value: data.distribution.low },
  ];

  const cardCls = "rounded-2xl bg-surface backdrop-blur-md border-2 border-token shadow-[0_12px_30px_rgba(15,23,42,0.08)]";
  const chartWrapCls = "mt-4 h-[280px] rounded-xl bg-surface-soft border border-token p-2";
  const selectCls = "h-9 w-full rounded-xl text-sm font-semibold bg-surface-strong text-main border border-token px-3 pr-8 shadow-sm appearance-none outline-none";
  const primaryBtn = "h-9 px-5 rounded-xl bg-btn-primary font-semibold shadow-[0_8px_20px_rgba(15,23,42,0.15)] hover:brightness-95 transition";

  return (
    <div className="min-h-screen w-full bg-app">
      <Menubar />
      <main className="min-h-screen bg-app layout-main">
        <div className="max-w-[1300px] mx-auto px-6 sm:px-8 py-8">
          <h1 className="text-4xl font-bold text-title">Analytics</h1>
          <p className="mt-2 text-sm text-muted">Simple charts showing interview results and progress.</p>

          <div className={`mt-6 p-4 ${cardCls}`}>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 xl:grid-cols-8 gap-3">
              {kpis.map((k) => (
                <div key={k.label} className="rounded-xl border border-token bg-surface-strong px-3 py-3">
                  <div className="text-[11px] text-muted">{k.label}</div>
                  <div className="mt-1 text-lg font-bold text-main">{k.value}</div>
                </div>
              ))}
            </div>
          </div>

          <section className={`mt-6 p-6 ${cardCls}`}>
            <h2 className="text-lg font-semibold text-main">Filters</h2>
            <div className="mt-4 grid grid-cols-1 md:grid-cols-3 gap-3">
              <SelectPill name="role" value={filters.role} onChange={onChange} options={roleOptions} className={selectCls} />
              <SelectPill name="date" value={filters.date} onChange={onChange} options={["Date", "This Week", "This Month", "This Year"]} className={selectCls} />
              <div className="flex md:justify-end">
                <button onClick={onApply} className={primaryBtn} type="button">
                  Apply Filters
                </button>
              </div>
            </div>
          </section>

          <div className="mt-6 grid grid-cols-1 xl:grid-cols-2 gap-6">
            <section className={`p-6 ${cardCls}`}>
              <h2 className="text-lg font-semibold text-main">Interview Volume Over Time</h2>
              <div className={chartWrapCls}>
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={data.charts.timeline}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="date" />
                    <YAxis allowDecimals={false} />
                    <Tooltip />
                    <Legend />
                    <Line type="monotone" dataKey="uploaded" stroke="#0ea5e9" strokeWidth={2} />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </section>

            <section className={`p-6 ${cardCls}`}>
              <h2 className="text-lg font-semibold text-main">Status Mix</h2>
              <div className={chartWrapCls}>
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={data.charts.timeline}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="date" />
                    <YAxis allowDecimals={false} />
                    <Tooltip />
                    <Legend />
                    <Bar dataKey="submitted" stackId="a" fill="#94a3b8" />
                    <Bar dataKey="processing" stackId="a" fill="#38bdf8" />
                    <Bar dataKey="completed" stackId="a" fill="#10b981" />
                    <Bar dataKey="endorsed" stackId="a" fill="#8b5cf6" />
                    <Bar dataKey="rejected" stackId="a" fill="#f87171" />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </section>
          </div>

          <div className="mt-6 grid grid-cols-1 xl:grid-cols-2 gap-6">
            <section className={`p-6 ${cardCls}`}>
              <h2 className="text-lg font-semibold text-main">Validation Score Distribution</h2>
              <div className={chartWrapCls}>
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={data.charts.histogram}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="range" />
                    <YAxis allowDecimals={false} />
                    <Tooltip />
                    <Bar dataKey="count" fill="#6366f1" />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </section>

            <section className={`p-6 ${cardCls}`}>
              <h2 className="text-lg font-semibold text-main">High/Medium/Low Score Split</h2>
              <div className={chartWrapCls}>
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie data={distributionPie} dataKey="value" nameKey="name" outerRadius={95} label>
                      {distributionPie.map((entry, index) => (
                        <Cell key={entry.name} fill={PIE_COLORS[index % PIE_COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip />
                    <Legend />
                  </PieChart>
                </ResponsiveContainer>
              </div>
            </section>
          </div>

          <div className="mt-6 grid grid-cols-1 xl:grid-cols-2 gap-6">
            <section className={`p-6 ${cardCls}`}>
              <h2 className="text-lg font-semibold text-main">Average Score by Role</h2>
              <div className={chartWrapCls}>
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={data.charts.rolePerformance}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="role" />
                    <YAxis domain={[0, 1]} />
                    <Tooltip />
                    <Legend />
                    <Bar dataKey="avgScore" fill="#0ea5e9" />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </section>

            <section className={`p-6 ${cardCls}`}>
              <h2 className="text-lg font-semibold text-main">Confidence vs Validation Score</h2>
              <div className={chartWrapCls}>
                <ResponsiveContainer width="100%" height="100%">
                  <ScatterChart>
                    <CartesianGrid />
                    <XAxis type="number" dataKey="score" domain={[0, 1]} name="Score" />
                    <YAxis type="number" dataKey="confidence" domain={[0, 1]} name="Confidence" />
                    <Tooltip cursor={{ strokeDasharray: "3 3" }} />
                    <Scatter data={data.charts.confidenceVsScore} fill="#8b5cf6" />
                  </ScatterChart>
                </ResponsiveContainer>
              </div>
            </section>
          </div>

          <div className="mt-6">
            <section className={`p-6 ${cardCls}`}>
              <h2 className="text-lg font-semibold text-main">Most-Missed Skills</h2>
              <div className={chartWrapCls}>
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={data.missingSkills} layout="vertical" margin={{ left: 40 }}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis type="number" allowDecimals={false} />
                    <YAxis type="category" dataKey="skill" width={180} />
                    <Tooltip />
                    <Bar dataKey="count" fill="#f97316" />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </section>
          </div>
        </div>
      </main>
    </div>
  );
}

function SelectPill({ name, value, onChange, options, className }) {
  return (
    <div className="relative min-w-0">
      <select name={name} value={value} onChange={onChange} className={className}>
        {options.map((o) => (
          <option key={o} value={o}>
            {o}
          </option>
        ))}
      </select>
      <span className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 text-main text-[10px]">
        v
      </span>
    </div>
  );
}

function toDisplayStatus(status = "") {
  if (status === "completed") return "Completed";
  if (status === "endorsed") return "Endorsed";
  if (status === "processing") return "Processing";
  if (status === "submitted") return "Pending";
  if (status === "rejected") return "Rejected";
  return status || "Unknown";
}

