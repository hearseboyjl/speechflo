import express from "express";
import { db } from "../db.js";
import { authMiddleware, requireRole } from "./authMiddleware.js";
import { writeAuditLog } from "../utils/auditLog.js";

const router = express.Router();
router.use(authMiddleware);

/**
 * Extracts a named section from stored report_raw text payloads.
 * This allows backwards-compatible reads even when only report_raw exists.
 */
function extractSection(content = "", title = "") {
  const source = String(content || "");
  if (!source || !title) return "";
  const match = source.match(new RegExp(`${title}:\\n([\\s\\S]*?)(\\n\\n|$)`, "i"));
  return match ? String(match[1] || "").trim() : "";
}

/**
 * Generates and stores a structured text report for one application.
 * The generated content is later read by recruiter report pages and exports.
 */
router.post("/generate", requireRole("recruiter", "admin"), async (req, res) => {
  try {
    const {
      applicationId,
      applicantId,
      applicantName,
      jobTitle,
      recruiterName,
      date,
      skills,
      summary,
      recommendation,
      parsedSkills,
      sentiment,
      confidence,
      areasForImprovement,
    } = req.body;

    if (!applicationId || !applicantId) {
      return res.status(400).json({ error: "applicationId and applicantId are required" });
    }

    // Build report content with full details including applicantId
    const reportContent = `
Applicant ID:
${applicantId}

Applicant Name:
${applicantName}

Position:
${jobTitle}

Recruiter Name:
${recruiterName}

Date:
${date}

Skills Extracted:
${skills.join(", ")}

Summary:
${summary}

Sentiment:
${sentiment || "N/A"}

Confidence:
${Number(confidence ?? 0).toFixed(2)}

Role Compatibility Score:
${parsedSkills?.compatibility_score ?? "N/A"}

Role Compatibility Flag:
${parsedSkills?.compatibility_flag ?? "N/A"}

Recommendation Class:
${parsedSkills?.recommendation_class ?? "N/A"}

Response Consistency Score:
${parsedSkills?.response_consistency_score ?? "N/A"}

Resume Consistency Score:
${parsedSkills?.resume_consistency_score ?? "N/A"}

Resume Consistency Flag:
${parsedSkills?.resume_consistency_flag ?? "N/A"}

Resume Skill Alignment Score:
${parsedSkills?.resume_consistency_details?.skill_alignment_score ?? "N/A"}

Resume Experience Consistency Score:
${parsedSkills?.resume_consistency_details?.experience_consistency_score ?? "N/A"}

Resume Tooling Consistency Score:
${parsedSkills?.resume_consistency_details?.tooling_consistency_score ?? "N/A"}

Resume Credential Consistency Score:
${parsedSkills?.resume_consistency_details?.credential_consistency_score ?? "N/A"}

Hard Contradictions:
${parsedSkills?.resume_consistency_details?.hard_contradiction_count ?? 0}

Soft Gaps:
${parsedSkills?.resume_consistency_details?.soft_gap_count ?? 0}

Insufficient Evidence Count:
${parsedSkills?.resume_consistency_details?.insufficient_evidence_count ?? 0}

Areas for Improvement:
${areasForImprovement}

Recommended Next Step:
${recommendation}
`.trim();

    await db.query(
      `
      INSERT INTO interview_artifacts (application_id, report_raw)
      VALUES (?, ?)
      ON DUPLICATE KEY UPDATE report_raw = VALUES(report_raw)
      `,
      [applicationId, reportContent]
    );

    await writeAuditLog({
      actorUserId: req.user.id,
      action: "report.generate",
      entityType: "application",
      entityId: applicationId,
      summary: `Generated report for application ${applicationId}`,
    });

    const filename = `RPT_${applicationId}.txt`;

    res.json({ message: "Report exported successfully!", filename });
  } catch (err) {
    console.error("Error generating report:", err);
    res.status(500).json({ error: "Failed to generate report" });
  }
});

/**
 * Returns applicant-side report summary list for the logged-in applicant.
 * Access is intentionally limited to their own applications.
 */
router.get("/applicant/my", requireRole("applicant"), async (req, res) => {
  try {
    const [rows] = await db.query(
      `
      SELECT
        ja.id AS application_id,
        ja.status,
        ja.applied_at,
        j.id AS job_id,
        j.title AS job_title,
        j.company_name,
        ia.report_raw,
        ia.summary AS interview_summary,
        ia.recommendation AS interview_recommendation,
        ia.sentiment,
        ia.confidence,
        ia.updated_at AS report_updated_at
      FROM job_applications ja
      JOIN jobs j ON j.id = ja.job_id
      LEFT JOIN interview_artifacts ia ON ia.application_id = ja.id
      WHERE ja.user_id = ?
      ORDER BY ja.applied_at DESC, ja.id DESC
      `,
      [req.user.id]
    );

    res.json(
      rows.map((row) => {
        const reportRaw = row.report_raw || "";
        const summary = row.interview_summary || extractSection(reportRaw, "Summary");
        const recommendation =
          row.interview_recommendation || extractSection(reportRaw, "Recommended Next Step");

        return {
          applicationId: row.application_id,
          jobId: row.job_id,
          jobTitle: row.job_title || "",
          companyName: row.company_name || "",
          status: row.status || "",
          appliedAt: row.applied_at,
          reportUpdatedAt: row.report_updated_at || null,
          hasReport: Boolean(reportRaw),
          summary: summary || "",
          recommendation: recommendation || "",
          sentiment: row.sentiment || "",
          confidence:
            row.confidence === null || row.confidence === undefined
              ? null
              : Number(row.confidence),
        };
      })
    );
  } catch (err) {
    console.error("Error loading applicant reports:", err);
    res.status(500).json({ error: "Failed to load applicant reports" });
  }
});

/**
 * Returns full report content and parsed sections for recruiter/admin viewers.
 */
router.get("/:applicationId", requireRole("recruiter", "admin"), async (req, res) => {
  try {
    const { applicationId } = req.params;
    const filename = `RPT_${applicationId}.txt`;
    const [rows] = await db.query(
      `
      SELECT
        ia.report_raw,
        ja.status AS application_status
      FROM interview_artifacts ia
      LEFT JOIN job_applications ja ON ja.id = ia.application_id
      WHERE ia.application_id = ?
      LIMIT 1
      `,
      [applicationId]
    );
    if (!rows.length || !rows[0].report_raw) {
      return res.status(404).json({ error: "Report not found" });
    }
    const content = rows[0].report_raw;
    const applicationStatus = rows[0].application_status || "";

    await writeAuditLog({
      actorUserId: req.user.id,
      action: "report.read",
      entityType: "application",
      entityId: applicationId,
      summary: `Viewed report for application ${applicationId}`,
    });

    // Extract key sections for frontend convenience
    const reportData = {
      applicantId: extractSection(content, "Applicant ID"),
      applicantName: extractSection(content, "Applicant Name"),
      jobTitle: extractSection(content, "Position"),
      recruiterName: extractSection(content, "Recruiter Name"),
      date: extractSection(content, "Date"),
      skills: (extractSection(content, "Skills Extracted") || "").split(", ").filter(Boolean),
      summary: extractSection(content, "Summary"),
      sentiment: extractSection(content, "Sentiment"),
      confidence: extractSection(content, "Confidence"),
      compatibilityScore: extractSection(content, "Role Compatibility Score"),
      compatibilityFlag: extractSection(content, "Role Compatibility Flag"),
      recommendationClass: extractSection(content, "Recommendation Class"),
      responseConsistencyScore: extractSection(content, "Response Consistency Score"),
      resumeConsistencyScore: extractSection(content, "Resume Consistency Score"),
      resumeConsistencyFlag: extractSection(content, "Resume Consistency Flag"),
      resumeSkillAlignmentScore: extractSection(content, "Resume Skill Alignment Score"),
      resumeExperienceConsistencyScore: extractSection(content, "Resume Experience Consistency Score"),
      resumeToolingConsistencyScore: extractSection(content, "Resume Tooling Consistency Score"),
      resumeCredentialConsistencyScore: extractSection(content, "Resume Credential Consistency Score"),
      hardContradictions: extractSection(content, "Hard Contradictions"),
      softGaps: extractSection(content, "Soft Gaps"),
      insufficientEvidenceCount: extractSection(content, "Insufficient Evidence Count"),
      areasForImprovement: extractSection(content, "Areas for Improvement"),
      recommendation: extractSection(content, "Recommended Next Step"),
    };

    res.json({ content, filename, reportData, applicationStatus });
  } catch (err) {
    console.error("Error fetching report:", err);
    res.status(500).json({ error: "Failed to fetch report" });
  }
});

export default router;
