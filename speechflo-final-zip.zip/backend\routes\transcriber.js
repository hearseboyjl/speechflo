import express from "express";
import multer from "multer";
import OpenAI from "openai";
import { toFile } from "openai/uploads";
import dotenv from "dotenv";
import { db } from "../db.js";
import { authMiddleware, requireRole } from "./authMiddleware.js";
import {
  parseAnalysisSections,
} from "../utils/interviewStore.js";
import { getActivePromptConfig } from "../utils/promptStore.js";
import { writeAuditLog } from "../utils/auditLog.js";
import { appendApplicationStatusEvent } from "../utils/applicationTimeline.js";

dotenv.config();
const router = express.Router();
const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

router.use(authMiddleware);
router.use(requireRole("recruiter", "admin"));

/**
 * Runs one prompt task against GPT using the currently published prompt config.
 * This keeps analysis behavior centralized in prompt_versions instead of hardcoded prompts.
 */
async function callGPT(taskName, transcriptContent, maxTokens = 2000) {
  const prompts = await getActivePromptConfig();
  const taskPrompt = prompts.tasks[taskName];
  if (!taskPrompt) throw new Error(`Task ${taskName} not found`);

  const fullPrompt = `${prompts.master_prompt}\n\n${taskPrompt}\n\nTranscript:\n"""${transcriptContent}"""`;

  const response = await openai.chat.completions.create({
    model: "gpt-4",
    messages: [{ role: "user", content: fullPrompt }],
    max_tokens: maxTokens,
  });

  return response.choices[0].message.content;
}

/**
 * Ensures sentiment and confidence are always embedded in analysis_raw,
 * even if the upstream prompt output omits these sections.
 */
function buildAnalysisWithSignals(analysisText, sentimentText, confidenceText) {
  const parsedSentiment = sentimentText
    .replace(/^Sentiment:\s*/i, "")
    .trim();
  const confidenceMatch = confidenceText.match(/0(\.\d+)?|1(\.0+)?/);
  const parsedConfidence = confidenceMatch ? confidenceMatch[0] : "";

  let merged = (analysisText || "").trim();
  if (!/^Sentiment:/im.test(merged)) {
    merged += `\n\nSentiment:\n${parsedSentiment || "N/A"}`;
  }
  if (!/^Confidence:/im.test(merged)) {
    merged += `\n\nConfidence:\n${parsedConfidence || "0.00"}`;
  }
  return merged.trim();
}

/**
 * Maps UI language choices to Whisper language codes.
 * Returns:
 * - null for auto-detect/taglish modes
 * - "en" for English
 * - "tl" for Filipino/Tagalog
 * - undefined for invalid values
 */
function normalizeTranscriptionLanguage(value) {
  if (value === undefined || value === null || value === "") return null;

  const normalized = String(value).trim().toLowerCase();
  if (
    !normalized ||
    normalized === "auto" ||
    normalized === "detect" ||
    normalized === "taglish" ||
    normalized === "mixed"
  ) {
    return null;
  }
  if (normalized === "en" || normalized === "english") {
    return "en";
  }
  if (
    normalized === "tl" ||
    normalized === "fil" ||
    normalized === "filipino" ||
    normalized === "tagalog"
  ) {
    return "tl";
  }
  return undefined;
}

const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 100 * 1024 * 1024 }, // 100MB max
});

/**
 * Primary upload endpoint:
 * - validates applicant/application linkage
 * - transcribes audio via Whisper
 * - runs structured GPT analysis tasks
 * - persists transcript + analysis artifacts
 * - marks application status as completed
 */
router.post("/upload-audio", upload.single("audio"), async (req, res) => {
  try {
    const { applicationId, applicantId, transcriptionLanguage } = req.body;
    if (!applicationId || !applicantId) {
      return res
        .status(400)
        .json({ error: "applicationId and applicantId are required" });
    }

    if (!req.file?.buffer) {
      return res.status(400).json({ error: "audio file is required" });
    }

    const [rows] = await db.execute(
      "SELECT id FROM users WHERE id = ? AND role = 'applicant'",
      [applicantId]
    );
    if (rows.length === 0) {
      return res.status(404).json({ error: "Applicant account not found" });
    }

    const whisperLanguage = normalizeTranscriptionLanguage(transcriptionLanguage);
    if (whisperLanguage === undefined) {
      return res.status(400).json({
        error:
          "Invalid transcriptionLanguage. Use one of: taglish, auto, en, english, tl, tagalog, filipino.",
      });
    }

    const aiFile = await toFile(
      req.file.buffer,
      req.file.originalname || `audio-${Date.now()}.webm`
    );
    const transcriptionRequest = {
      file: aiFile,
      model: "whisper-1",
    };
    if (whisperLanguage) {
      transcriptionRequest.language = whisperLanguage;
    }
    const transcription = await openai.audio.transcriptions.create(
      transcriptionRequest
    );
    const rawTranscript = transcription.text;

    const labeledTranscript = await callGPT("speaker_labeling", rawTranscript, 3000);
    const analysisCore = await callGPT("analysis", labeledTranscript, 2000);
    const sentimentRaw = await callGPT("sentiment_analysis", labeledTranscript, 300);
    const confidenceRaw = await callGPT("confidence_scoring", labeledTranscript, 300);
    const analysisRaw = buildAnalysisWithSignals(
      analysisCore,
      sentimentRaw,
      confidenceRaw
    );
    const parsed = parseAnalysisSections(analysisRaw);

    await db.query(
      `
      INSERT INTO interview_artifacts (
        application_id,
        transcript,
        analysis_raw,
        skills_json,
        summary,
        areas_for_improvement,
        recommendation,
        sentiment,
        confidence
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
      ON DUPLICATE KEY UPDATE
        transcript = VALUES(transcript),
        analysis_raw = VALUES(analysis_raw),
        skills_json = VALUES(skills_json),
        summary = VALUES(summary),
        areas_for_improvement = VALUES(areas_for_improvement),
        recommendation = VALUES(recommendation),
        sentiment = VALUES(sentiment),
        confidence = VALUES(confidence)
      `,
      [
        applicationId,
        labeledTranscript,
        analysisRaw,
        JSON.stringify(parsed.skills || []),
        parsed.summary || "",
        parsed.areasForImprovement || "",
        parsed.recommendation || "",
        parsed.sentiment || "",
        parsed.confidence ?? null,
      ]
    );

    await db.query(
      "UPDATE job_applications SET transcript = ?, status = 'completed' WHERE id = ?",
      [labeledTranscript, applicationId]
    );

    await appendApplicationStatusEvent(db, {
      applicationId,
      status: "completed",
      note: "Interview analysis completed.",
      changedBy: req.user.id,
    });

    res.json({
      message: "Interview processed successfully",
      transcriptionLanguage: whisperLanguage || "auto",
      transcript: labeledTranscript,
      analysis: {
        skills: parsed.skills,
        summary: parsed.summary,
        areasForImprovement: parsed.areasForImprovement,
        recommendation: parsed.recommendation,
        sentiment: parsed.sentiment,
        confidence: parsed.confidence,
      },
    });
  } catch (err) {
    console.error("Error during processing:", err);
    res.status(500).json({ error: "Failed to process interview audio" });
  }
});

/**
 * Stores a pre-existing transcript without running full AI pipeline.
 * Used for manual/alternative transcript ingestion workflows.
 */
router.post("/analyze-audio", upload.none(), async (req, res) => {
  try {
    const { transcriptText, applicationId } = req.body;

    if (!transcriptText || !applicationId) {
      return res
        .status(400)
        .json({ error: "transcriptText and applicationId are required" });
    }

    await db.query(
      `
      INSERT INTO interview_artifacts (application_id, transcript)
      VALUES (?, ?)
      ON DUPLICATE KEY UPDATE transcript = VALUES(transcript)
      `,
      [applicationId, transcriptText]
    );

    await db.query(
      "UPDATE job_applications SET transcript = ? WHERE id = ?",
      [transcriptText, applicationId]
    );

    res.json({
      message: "Transcript saved successfully",
      applicationId,
      transcriptLength: transcriptText.length,
    });
  } catch (err) {
    console.error("Error saving transcript:", err);
    res.status(500).json({ error: "Failed to save transcript" });
  }
});

/**
 * Returns stored transcript for a given application and writes an audit trail.
 */
router.get("/get-transcript/:applicationId", async (req, res) => {
  try {
    const { applicationId } = req.params;

    const [rows] = await db.query(
      "SELECT transcript FROM interview_artifacts WHERE application_id = ?",
      [applicationId]
    );

    if (!rows.length || !rows[0].transcript) {
      return res.status(404).json({ error: "Transcript not found" });
    }

    await writeAuditLog({
      actorUserId: req.user.id,
      action: "transcript.read",
      entityType: "application",
      entityId: applicationId,
      summary: `Viewed transcript for application ${applicationId}`,
    });

    res.json({ transcript: rows[0].transcript });
  } catch (err) {
    console.error("Error fetching transcript:", err);
    res.status(500).json({ error: "Failed to fetch transcript" });
  }
});

/**
 * Returns parsed analysis fields used by the Interview Details view.
 * Falls back to parsing analysis_raw when structured columns are incomplete.
 */
router.get("/get-skills/:applicationId", async (req, res) => {
  try {
    const { applicationId } = req.params;

    const [rows] = await db.query(
      `
      SELECT
        skills_json,
        summary,
        areas_for_improvement,
        recommendation,
        sentiment,
        confidence,
        analysis_raw
      FROM interview_artifacts
      WHERE application_id = ?
      `,
      [applicationId]
    );

    if (!rows.length) {
      return res.status(404).json({ error: "Analysis not found" });
    }

    const row = rows[0];
    let skills = [];

    if (row.skills_json) {
      try {
        skills = JSON.parse(row.skills_json);
      } catch {
        skills = [];
      }
    }

    // Safety fallback if structured columns are empty.
    if (
      (!skills.length ||
        !row.summary ||
        !row.recommendation ||
        row.confidence === null) &&
      row.analysis_raw
    ) {
      const parsed = parseAnalysisSections(row.analysis_raw);
      if (!skills.length) skills = parsed.skills;
      if (!row.summary) row.summary = parsed.summary;
      if (!row.areas_for_improvement) {
        row.areas_for_improvement = parsed.areasForImprovement;
      }
      if (!row.recommendation) row.recommendation = parsed.recommendation;
      if (!row.sentiment) row.sentiment = parsed.sentiment;
      if (row.confidence === null) row.confidence = parsed.confidence;
    }

    await writeAuditLog({
      actorUserId: req.user.id,
      action: "analysis.read",
      entityType: "application",
      entityId: applicationId,
      summary: `Viewed analysis for application ${applicationId}`,
    });

    res.json({
      skills,
      summary: row.summary || "",
      areasForImprovement: row.areas_for_improvement || "",
      recommendation: row.recommendation || "",
      sentiment: row.sentiment || "",
      confidence: row.confidence === null ? null : Number(row.confidence),
    });
  } catch (err) {
    console.error("Error fetching analysis:", err);
    res.status(500).json({ error: "Failed to fetch analysis" });
  }
});

/**
 * Re-runs analysis tasks using an already stored transcript.
 * Keeps the original transcript but refreshes derived analysis outputs.
 */
router.post("/rerun-analysis/:applicationId", async (req, res) => {
  try {
    const { applicationId } = req.params;

    const [rows] = await db.query(
      `
      SELECT transcript
      FROM interview_artifacts
      WHERE application_id = ?
      `,
      [applicationId]
    );

    if (!rows.length || !rows[0].transcript) {
      return res.status(404).json({ error: "Transcript not found for this application" });
    }

    const transcript = rows[0].transcript;
    const analysisCore = await callGPT("analysis", transcript, 2000);
    const sentimentRaw = await callGPT("sentiment_analysis", transcript, 300);
    const confidenceRaw = await callGPT("confidence_scoring", transcript, 300);
    const analysisRaw = buildAnalysisWithSignals(
      analysisCore,
      sentimentRaw,
      confidenceRaw
    );
    const parsed = parseAnalysisSections(analysisRaw);

    await db.query(
      `
      UPDATE interview_artifacts
      SET
        analysis_raw = ?,
        skills_json = ?,
        summary = ?,
        areas_for_improvement = ?,
        recommendation = ?,
        sentiment = ?,
        confidence = ?
      WHERE application_id = ?
      `,
      [
        analysisRaw,
        JSON.stringify(parsed.skills || []),
        parsed.summary || "",
        parsed.areasForImprovement || "",
        parsed.recommendation || "",
        parsed.sentiment || "",
        parsed.confidence ?? null,
        applicationId,
      ]
    );

    res.json({
      message: "Analysis re-run successfully",
      analysis: {
        skills: parsed.skills || [],
        summary: parsed.summary || "",
        areasForImprovement: parsed.areasForImprovement || "",
        recommendation: parsed.recommendation || "",
        sentiment: parsed.sentiment || "",
        confidence: parsed.confidence ?? null,
      },
    });
  } catch (err) {
    console.error("[Transcriber] rerun analysis error:", err);
    res.status(500).json({ error: "Failed to re-run analysis" });
  }
});

export default router;
