import { useEffect, useMemo, useState } from "react";
import { NavLink, useNavigate, useParams } from "react-router-dom";
import Menubar from "../components/Menubar";
import { apiUrl } from "../api";

const SECTION_META = [
  {
    id: "functions",
    title: "Recruiter Functions",
    subtitle: "What each recruiter page does and when to use it.",
  },
  {
    id: "metrics",
    title: "Metrics Dictionary",
    subtitle: "What each score means and how to read it.",
  },
  {
    id: "analysis-flow",
    title: "Analysis Flow",
    subtitle: "How the system goes from upload to final recommendation.",
  },
  {
    id: "faq",
    title: "FAQ & Troubleshooting",
    subtitle: "Common issues and quick fixes.",
  },
];

const FUNCTION_GROUPS = [
  {
    title: "Main Navigation",
    items: [
      {
        name: "Dashboard",
        where: "/recruiter/dashboard",
        purpose: "Live overview of interview volume, pending review, trends, and quick actions.",
      },
      {
        name: "Interviews Hub",
        where: "/recruiter/interviewer-hub",
        purpose: "View applications, open interview details, and launch upload for analysis.",
      },
      {
        name: "Upload Interview",
        where: "/recruiter/upload-interview",
        purpose:
          "Upload interview audio/video, choose transcription language mode (Taglish recommended), then generate transcript, analysis, and scoring.",
      },
      {
        name: "Interview Details",
        where: "/recruiter/interview-details",
        purpose: "Review transcript, detected skills, score explanation, and recommendation.",
      },
    ],
  },
  {
    title: "Evaluation & Reporting",
    items: [
      {
        name: "Reports",
        where: "/recruiter/reports",
        purpose: "List generated reports and open detailed report views per application.",
      },
      {
        name: "Report Details",
        where: "/recruiter/reports/:applicationId",
        purpose: "Read final report summary and evaluation fields for one candidate.",
      },
      {
        name: "Analytics",
        where: "/recruiter/analytics",
        purpose: "View trends and score summaries by role and date range.",
      },
    ],
  },
  {
    title: "Operations & Governance",
    items: [
      {
        name: "Requests",
        where: "/recruiter/change-requests",
        purpose: "Submit and track platform change requests.",
      },
      {
        name: "Settings",
        where: "/recruiter/settings",
        purpose: "Manage profile-level and recruiter-side system settings.",
      },
      {
        name: "Re-run Analysis",
        where: "Interview Details -> Recommended Next Step card",
        purpose:
          "Run analysis again (with optional new file) and pick a transcription language mode before re-processing.",
      },
    ],
  },
];

const METRIC_GROUPS = [
  {
    title: "Transcript Surface Metrics",
    items: [
      {
        name: "Words spoken",
        range: "count",
        meaning: "Total words in displayed transcript text.",
        generation: "Simple word count from the transcript shown on screen.",
      },
      {
        name: "Filler words",
        range: "count",
        meaning: "Count of filler patterns such as um/uh/like/you know.",
        generation: "Looks for common filler words in the transcript.",
      },
      {
        name: "Skills mentioned",
        range: "count",
        meaning: "Number of extracted interview skills currently attached to the application.",
        generation: "Count of skills detected by the interview analysis.",
      },
      {
        name: "Sentiment",
        range: "Positive | Neutral | Negative",
        meaning: "Overall emotional/tonal classification of applicant responses.",
        generation: "AI classifies the overall tone of the applicant’s answers.",
      },
      {
        name: "Speech confidence (0-1)",
        range: "0 to 1",
        meaning: "How reliable the analysis is based on transcript quality and clarity.",
        generation: "AI gives a confidence value from 0 to 1.",
      },
      {
        name: "Areas for improvement",
        range: "count",
        meaning: "How many improvement statements were parsed from analysis output.",
        generation: "Count of improvement points listed in the analysis.",
      },
    ],
  },
  {
    title: "Skill Validation Metrics",
    items: [
      {
        name: "Weighted score",
        range: "0 to 1",
        meaning: "Role skill-fit score from matched/partial/missing required skills.",
        generation:
          "The system checks role skills against interview evidence, then combines the skill weights into one score.",
      },
      {
        name: "Weighted score label",
        range: "Excellent | Good | Moderate | Weak",
        meaning: "UI bucket for quick readability.",
        generation: "UI thresholds: >=0.70 Excellent, >=0.50 Good, >=0.35 Moderate, else Weak.",
      },
      {
        name: "Validation method",
        range: "Method label",
        meaning: "Shows which matching approach was used for this result.",
        generation: "Set automatically depending on available data and checks.",
      },
    ],
  },
  {
    title: "Compatibility & Decision Metrics",
    items: [
      {
        name: "Compatibility score",
        range: "0 to 100",
        meaning: "Final role-fit score used for hiring guidance.",
        generation:
          "Built from skill fit, required skill coverage, communication quality, confidence, and answer consistency.",
      },
      {
        name: "Compatibility flag",
        range: "High | Moderate | Low",
        meaning: "Label bucket for compatibility score.",
        generation: "Score bands: High (80+), Moderate (60-79.99), Low (below 60).",
      },
      {
        name: "Recommendation class",
        range: "Advance | Advance with Caution | Manual Review | Do Not Advance",
        meaning: "Recommended recruiter action based on all scores.",
        generation:
          "Starts from compatibility result, then can be lowered if confidence/resume checks are weak.",
      },
      {
        name: "Analysis confidence flag",
        range: "OK | Low Analysis Confidence",
        meaning: "Indicates if speech confidence passed minimum reliability threshold.",
        generation: "If confidence is below the minimum level, it is marked as Low.",
      },
      {
        name: "Response consistency",
        range: "0% to 100%",
        meaning: "How consistently applicant references extracted skills across responses.",
        generation:
          "Based on how often detected skills are supported across answers, with a penalty for conflicting experience statements.",
      },
    ],
  },
  {
    title: "Resume Cross-check Metrics",
    items: [
      {
        name: "Resume consistency",
        range: "0% to 100%",
        meaning: "Overall resume-vs-transcript consistency score.",
        generation:
          "Compares resume claims with interview statements and combines skill, experience, tools, and credentials.",
      },
      {
        name: "Resume consistency flag",
        range: "High | Moderate | Low | Insufficient Data",
        meaning: "Bucketed interpretation of resume consistency score.",
        generation: "Set from the resume consistency score range.",
      },
      {
        name: "Resume skill alignment",
        range: "0% to 100%",
        meaning: "How many resume skill claims are supported in transcript.",
        generation: "Each resume skill is scored as full support, partial support, or no clear support.",
      },
      {
        name: "Resume experience consistency",
        range: "0% to 100%",
        meaning: "Consistency between resume experience claims and transcript statements.",
        generation: "Compares years/experience statements between resume and interview.",
      },
      {
        name: "Hard contradictions",
        range: "count",
        meaning: "Strong conflicts between resume and transcript (for example years mismatch).",
        generation: "Number of clear resume-vs-interview conflicts.",
      },
      {
        name: "Soft gaps",
        range: "count",
        meaning: "Partial support cases where evidence is weak or incomplete.",
        generation: "Number of claims with weak or incomplete support.",
      },
    ],
  },
];

const ANALYSIS_FLOW_STEPS = [
  {
    step: "1. Upload",
    detail: "Recruiter uploads interview file from Upload Interview or re-run flow.",
  },
  {
    step: "2. Transcription",
    detail:
      "The system converts audio to text. Taglish (Recommended) uses auto-detect for mixed English/Filipino speech; you can also force English or Filipino/Tagalog.",
  },
  {
    step: "3. Core analysis",
    detail: "The system creates a skills list, summary, improvement points, and next-step suggestion.",
  },
  {
    step: "4. Sentiment + confidence",
    detail: "It also scores overall tone and analysis reliability.",
  },
  {
    step: "5. Role skill validation",
    detail: "Candidate skills are compared against role requirements using interview evidence.",
  },
  {
    step: "6. Compatibility scoring",
    detail: "All major score components are combined into compatibility and recommendation.",
  },
  {
    step: "7. Resume cross-check",
    detail: "Resume claims are checked against what the candidate said in the interview.",
  },
  {
    step: "8. Final guard + persistence",
    detail: "If resume consistency is weak, recommendation may be lowered before results are saved and shown.",
  },
];

const FAQ_ITEMS = [
  {
    q: "Why is a strong candidate marked Moderate instead of High?",
    a: "High needs both high compatibility score and policy conditions (for example no missing critical signals and acceptable confidence/consistency).",
  },
  {
    q: "Why do some claims show Unknown in resume cross-check?",
    a: "Unknown means the transcript did not provide clear support or contradiction for that resume claim.",
  },
  {
    q: "When should I use Re-run Analysis?",
    a: "Use it when transcript quality is poor, a wrong file was uploaded, or after major model/prompt updates.",
  },
  {
    q: "Which transcription mode should I use for Taglish interviews?",
    a: "Use Taglish (Recommended). It maps to auto-detect so mixed English and Filipino responses are handled better.",
  },
  {
    q: "What should I check first if scores look wrong?",
    a: "Check transcript quality, extracted skills list, role skill mapping, and evidence lines in validation reasoning.",
  },
  {
    q: "How do I interpret low response consistency?",
    a: "It usually means interview answers do not consistently support the same skills, or experience claims vary.",
  },
];

function SectionPill({ item, isActive }) {
  return (
    <NavLink
      to={`/recruiter/help/${item.id}`}
      className={[
        "block rounded-xl border px-3 py-2 text-sm transition",
        isActive
          ? "border-[#5aa4d4] bg-[#dff0fb] text-[#0a3d62] dark:border-[#6eb9ec] dark:bg-[#163149] dark:text-[#d3edff]"
          : "border-token bg-surface-soft text-main hover:brightness-105",
      ].join(" ")}
    >
      <div className="font-semibold">{item.title}</div>
      <div className="mt-0.5 text-xs text-muted">{item.subtitle}</div>
    </NavLink>
  );
}

export default function HelpCenter() {
  const navigate = useNavigate();
  const { section } = useParams();
  const [userName, setUserName] = useState("User");
  const [loading, setLoading] = useState(true);

  const activeSection = useMemo(() => {
    if (!section) return "home";
    const valid = new Set(SECTION_META.map((s) => s.id));
    return valid.has(section) ? section : "home";
  }, [section]);

  useEffect(() => {
    const token = localStorage.getItem("token");
    if (!token) {
      navigate("/recruiter/login");
      return;
    }

    const verify = async () => {
      try {
        const res = await fetch(apiUrl("/auth/me"), {
          headers: { Authorization: `Bearer ${token}` },
        });
        if (!res.ok) throw new Error("Unauthorized");
        const me = await res.json();
        setUserName(me.firstName || "User");
      } catch (err) {
        console.error("[HelpCenter] auth error:", err);
        localStorage.removeItem("token");
        localStorage.removeItem("user");
        navigate("/recruiter/login");
      } finally {
        setLoading(false);
      }
    };

    verify();
  }, [navigate]);

  const pageTitle = (() => {
    if (activeSection === "home") return "Help Center";
    return SECTION_META.find((s) => s.id === activeSection)?.title || "Help Center";
  })();

  return (
    <div className="min-h-screen bg-app-bloom">
      <Menubar userName={userName} />
      <main className="layout-main px-6 py-8">
        <div className="mx-auto max-w-[1280px]">
          <header className="rounded-2xl border border-token bg-surface p-6 shadow-soft">
            <h1 className="text-3xl font-bold text-title">{pageTitle}</h1>
            <p className="mt-2 text-sm text-muted">
              Central guide for recruiter tasks, score meanings, and result interpretation.
            </p>
          </header>

          <div className="mt-6 grid grid-cols-1 gap-6 lg:grid-cols-4">
            <aside className="rounded-2xl border border-token bg-surface p-4 shadow-soft lg:col-span-1">
              <div className="mb-3 text-xs font-semibold uppercase tracking-wide text-muted">
                Sections
              </div>
              <div className="space-y-2">
                <NavLink
                  to="/recruiter/help"
                  className={[
                    "block rounded-xl border px-3 py-2 text-sm transition",
                    activeSection === "home"
                      ? "border-[#5aa4d4] bg-[#dff0fb] text-[#0a3d62] dark:border-[#6eb9ec] dark:bg-[#163149] dark:text-[#d3edff]"
                      : "border-token bg-surface-soft text-main hover:brightness-105",
                  ].join(" ")}
                >
                  <div className="font-semibold">Overview</div>
                  <div className="mt-0.5 text-xs text-muted">Start here and open a section.</div>
                </NavLink>
                {SECTION_META.map((item) => (
                  <SectionPill
                    key={item.id}
                    item={item}
                    isActive={activeSection === item.id}
                  />
                ))}
              </div>
            </aside>

            <section className="rounded-2xl border border-token bg-surface p-5 shadow-soft lg:col-span-3">
              {loading ? (
                <div className="animate-pulse rounded-xl bg-slate-200/60 dark:bg-slate-200/10 h-40" />
              ) : null}

              {!loading && activeSection === "home" ? (
                <div>
                  <h2 className="text-xl font-semibold text-title">Start Here</h2>
                  <p className="mt-2 text-sm text-main">
                    Pick a section below for quick guidance. This replaces the old Interview Details
                    help popup and keeps everything in one place.
                  </p>

                  <div className="mt-5 grid grid-cols-1 gap-4 md:grid-cols-2">
                    {SECTION_META.map((item) => (
                      <button
                        key={item.id}
                        type="button"
                        onClick={() => navigate(`/recruiter/help/${item.id}`)}
                        className="rounded-xl border border-token bg-surface-strong p-4 text-left shadow-soft transition hover:brightness-105"
                      >
                        <div className="text-base font-semibold text-title">{item.title}</div>
                        <div className="mt-1 text-sm text-muted">{item.subtitle}</div>
                      </button>
                    ))}
                  </div>
                </div>
              ) : null}

              {!loading && activeSection === "functions" ? (
                <div className="space-y-6">
                  <h2 className="text-xl font-semibold text-title">Recruiter Feature Map</h2>
                  {FUNCTION_GROUPS.map((group) => (
                    <div key={group.title} className="rounded-xl border border-token bg-surface-strong p-4">
                      <h3 className="text-lg font-semibold text-title">{group.title}</h3>
                      <div className="mt-3 space-y-3">
                        {group.items.map((item) => (
                          <div key={item.name} className="rounded-lg border border-token bg-surface p-3">
                            <div className="text-sm font-semibold text-main">{item.name}</div>
                            <div className="mt-1 text-xs text-muted">
                              <span className="font-semibold">Where:</span> {item.where}
                            </div>
                            <div className="mt-1 text-sm text-main">{item.purpose}</div>
                          </div>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              ) : null}

              {!loading && activeSection === "metrics" ? (
                <div className="space-y-6">
                  <h2 className="text-xl font-semibold text-title">Metrics Dictionary</h2>
                  <p className="text-sm text-main">
                    Every metric on Interview Details explained in plain language.
                  </p>
                  {METRIC_GROUPS.map((group) => (
                    <div key={group.title} className="rounded-xl border border-token bg-surface-strong p-4">
                      <h3 className="text-lg font-semibold text-title">{group.title}</h3>
                      <div className="mt-3 space-y-3">
                        {group.items.map((m) => (
                          <div key={m.name} className="rounded-lg border border-token bg-surface p-3">
                            <div className="flex flex-wrap items-center justify-between gap-2">
                              <div className="text-sm font-semibold text-main">{m.name}</div>
                              <span className="rounded-full border border-token px-2 py-0.5 text-xs text-muted">
                                {m.range}
                              </span>
                            </div>
                            <div className="mt-1 text-sm text-main">{m.meaning}</div>
                            <div className="mt-1 text-xs text-muted">
                              <span className="font-semibold">Generated by:</span> {m.generation}
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              ) : null}

              {!loading && activeSection === "analysis-flow" ? (
                <div className="space-y-6">
                  <h2 className="text-xl font-semibold text-title">How Analysis is Produced</h2>
                  <div className="space-y-3">
                    {ANALYSIS_FLOW_STEPS.map((s) => (
                      <div key={s.step} className="rounded-lg border border-token bg-surface-strong p-3">
                        <div className="text-sm font-semibold text-main">{s.step}</div>
                        <div className="mt-1 text-sm text-main">{s.detail}</div>
                      </div>
                    ))}
                  </div>
                </div>
              ) : null}

              {!loading && activeSection === "faq" ? (
                <div className="space-y-6">
                  <h2 className="text-xl font-semibold text-title">FAQ & Troubleshooting</h2>
                  <div className="space-y-3">
                    {FAQ_ITEMS.map((item) => (
                      <div key={item.q} className="rounded-lg border border-token bg-surface-strong p-3">
                        <div className="text-sm font-semibold text-main">{item.q}</div>
                        <div className="mt-1 text-sm text-main">{item.a}</div>
                      </div>
                    ))}
                  </div>
                </div>
              ) : null}
            </section>
          </div>
        </div>
      </main>
    </div>
  );
}
