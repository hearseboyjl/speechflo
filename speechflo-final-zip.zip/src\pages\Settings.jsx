import Menubar from "../components/Menubar";
import { useMemo, useState, useEffect } from "react";
import SettingsModal from "../components/SettingsModal";
import { getSavedTheme, saveTheme } from "../theme";
import { useNavigate } from "react-router-dom";
import { apiUrl } from "../api";

const PREFS_KEY = "speechflo.recruiter.prefs";
const NOTIFY_KEY = "speechflo.recruiter.notify";

function loadJson(key, fallback) {
  try {
    const raw = localStorage.getItem(key);
    if (!raw) return fallback;
    return { ...fallback, ...JSON.parse(raw) };
  } catch {
    return fallback;
  }
}

function passwordStrengthLabel(value) {
  if (!value) return "Not set";
  if (value.length < 8) return "Weak";
  if (value.length < 12) return "Medium";
  return "Strong";
}

export default function Settings() {
  const navigate = useNavigate();
  const themes = useMemo(() => ["Light", "Dark"], []);

  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [userName, setUserName] = useState("User");

  const [showModal, setShowModal] = useState(false);
  const [modalMessage, setModalMessage] = useState("");

  const [account, setAccount] = useState({
    firstName: "",
    lastName: "",
    email: "",
    role: "recruiter",
    isActive: true,
    updatedAt: null,
  });
  const [accountBaseline, setAccountBaseline] = useState(null);

  const [security, setSecurity] = useState({
    currentPassword: "",
    newPassword: "",
    confirmPassword: "",
  });

  const [prefs, setPrefs] = useState(() =>
    loadJson(PREFS_KEY, {
      theme: getSavedTheme(),
      defaultDateRange: "This Month",
      defaultRoleFilter: "All Roles",
      confidenceThreshold: 0.7,
    })
  );
  const [prefsBaseline, setPrefsBaseline] = useState(null);

  const [notify, setNotify] = useState(() =>
    loadJson(NOTIFY_KEY, {
      processingTooLong: true,
      lowConfidenceCompleted: true,
      dailySummary: false,
    })
  );
  const [notifyBaseline, setNotifyBaseline] = useState(null);

  useEffect(() => {
    const token = localStorage.getItem("token");
    if (!token) {
      navigate("/recruiter/login");
      return;
    }

    const load = async () => {
      try {
        const accountRes = await fetch(apiUrl("/auth/account"), {
          headers: { Authorization: `Bearer ${token}` },
        });

        if (!accountRes.ok) throw new Error("Failed to load account");

        const data = await accountRes.json();
        const next = {
          firstName: data.firstName || "",
          lastName: data.lastName || "",
          email: data.email || "",
          role: data.role || "recruiter",
          isActive: Boolean(data.isActive),
          updatedAt: data.updatedAt || null,
        };

        setUserName(next.firstName || "User");
        localStorage.setItem("user", next.firstName || "User");

        setAccount(next);
        setAccountBaseline(next);
        setPrefsBaseline(prefs);
        setNotifyBaseline(notify);
      } catch (err) {
        console.error("[Settings] load error:", err);
        localStorage.removeItem("token");
        localStorage.removeItem("user");
        navigate("/recruiter/login");
      } finally {
        setLoading(false);
      }
    };

    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [navigate]);

  const accountDirty = JSON.stringify(account) !== JSON.stringify(accountBaseline);
  const prefsDirty = JSON.stringify(prefs) !== JSON.stringify(prefsBaseline);
  const notifyDirty = JSON.stringify(notify) !== JSON.stringify(notifyBaseline);
  const hasUnsaved = accountDirty || prefsDirty || notifyDirty;

  const cardCls =
    "rounded-2xl bg-surface backdrop-blur-md border-2 border-token shadow-[0_12px_30px_rgba(15,23,42,0.08)]";

  const inputCls =
    "h-10 w-full rounded-xl bg-surface-strong border border-token px-4 text-sm text-main shadow-sm outline-none focus:ring-2 focus:ring-[#2F8DCD]/30 focus:border-[#2F8DCD]/40";

  const btnPrimary =
    "h-10 px-5 rounded-xl bg-btn-primary text-white font-semibold shadow-[0_8px_20px_rgba(15,23,42,0.15)] hover:brightness-95 active:translate-y-[1px] transition";

  const btnSecondary =
    "h-10 px-5 rounded-xl bg-surface-strong text-main font-semibold border border-token hover:brightness-[0.98] active:translate-y-[1px] transition";

  const handleAccountChange = (e) => {
    const { name, value } = e.target;
    setAccount((prev) => ({ ...prev, [name]: value }));
  };

  const handleSecurityChange = (e) => {
    const { name, value } = e.target;
    setSecurity((prev) => ({ ...prev, [name]: value }));
  };

  const handlePrefsChange = (e) => {
    const { name, value } = e.target;
    setPrefs((prev) => ({ ...prev, [name]: name === "confidenceThreshold" ? Number(value) : value }));
    if (name === "theme") saveTheme(value);
  };

  const handleNotifyToggle = (key) => {
    setNotify((prev) => ({ ...prev, [key]: !prev[key] }));
  };

  const saveAccount = async (e) => {
    e.preventDefault();
    try {
      setSaving(true);
      const token = localStorage.getItem("token");
      const res = await fetch(apiUrl("/auth/account"), {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          firstName: account.firstName,
          lastName: account.lastName,
          email: account.email,
        }),
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.message || "Failed to update account");

      setAccountBaseline(account);
      localStorage.setItem("user", account.firstName || "User");
      setUserName(account.firstName || "User");
      setModalMessage("Account updated successfully.");
      setShowModal(true);
    } catch (err) {
      setModalMessage(err.message || "Failed to update account.");
      setShowModal(true);
    } finally {
      setSaving(false);
    }
  };

  const changePassword = async (e) => {
    e.preventDefault();

    if (!security.currentPassword || !security.newPassword || !security.confirmPassword) {
      setModalMessage("Please complete all password fields.");
      setShowModal(true);
      return;
    }
    if (security.newPassword !== security.confirmPassword) {
      setModalMessage("New password and confirmation do not match.");
      setShowModal(true);
      return;
    }

    try {
      setSaving(true);
      const token = localStorage.getItem("token");
      const res = await fetch(apiUrl("/auth/change-password"), {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          currentPassword: security.currentPassword,
          newPassword: security.newPassword,
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.message || "Failed to change password");

      setSecurity({ currentPassword: "", newPassword: "", confirmPassword: "" });
      setModalMessage("Password changed successfully.");
      setShowModal(true);
    } catch (err) {
      setModalMessage(err.message || "Failed to change password.");
      setShowModal(true);
    } finally {
      setSaving(false);
    }
  };

  const savePreferences = () => {
    localStorage.setItem(PREFS_KEY, JSON.stringify(prefs));
    localStorage.setItem(NOTIFY_KEY, JSON.stringify(notify));
    setPrefsBaseline(prefs);
    setNotifyBaseline(notify);
    setModalMessage("Preferences saved successfully.");
    setShowModal(true);
  };

  const resetUnsaved = () => {
    if (accountBaseline) setAccount(accountBaseline);
    if (prefsBaseline) setPrefs(prefsBaseline);
    if (notifyBaseline) setNotify(notifyBaseline);
  };

  return (
    <div className="min-h-screen w-full bg-app">
      <Menubar userName={userName} />

      <main className="min-h-screen bg-app layout-main">
        <div className="max-w-[1200px] mx-auto px-8 py-8 pb-32">
          <h1 className="text-4xl font-bold text-title">Settings</h1>
          <p className="mt-2 text-sm text-muted">Manage account details, security, and app preferences.</p>

          <div className="mt-8 grid grid-cols-1 lg:grid-cols-2 gap-6">
            <section className={`${cardCls} p-6`}>
              <h2 className="text-lg font-semibold text-main">Profile</h2>
              <p className="mt-1 text-xs text-muted">Update your core account details.</p>

              <form onSubmit={saveAccount} className="mt-5 space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <Field label="First Name">
                    <input name="firstName" value={account.firstName} onChange={handleAccountChange} className={inputCls} />
                  </Field>
                  <Field label="Last Name">
                    <input name="lastName" value={account.lastName} onChange={handleAccountChange} className={inputCls} />
                  </Field>
                </div>

                <Field label="Email">
                  <input type="email" name="email" value={account.email} onChange={handleAccountChange} className={inputCls} />
                </Field>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <Field label="Role">
                    <input value={account.role} readOnly className={`${inputCls} opacity-80`} />
                  </Field>
                  <Field label="Account Status">
                    <input value={account.isActive ? "Active" : "Inactive"} readOnly className={`${inputCls} opacity-80`} />
                  </Field>
                </div>

                <div className="text-xs text-muted">
                  Last updated: {account.updatedAt ? new Date(account.updatedAt).toLocaleString() : "--"}
                </div>

                <div className="pt-1">
                  <button disabled={saving || loading} className={btnPrimary}>
                    {saving ? "Saving..." : "Save Profile"}
                  </button>
                </div>
              </form>
            </section>

            <section className={`${cardCls} p-6`}>
              <h2 className="text-lg font-semibold text-main">Security</h2>
              <p className="mt-1 text-xs text-muted">Change your password for this account.</p>

              <form onSubmit={changePassword} className="mt-5 space-y-4">
                <Field label="Current Password">
                  <input type="password" name="currentPassword" value={security.currentPassword} onChange={handleSecurityChange} className={inputCls} />
                </Field>

                <Field label="New Password">
                  <input type="password" name="newPassword" value={security.newPassword} onChange={handleSecurityChange} className={inputCls} />
                </Field>

                <Field label="Confirm New Password">
                  <input type="password" name="confirmPassword" value={security.confirmPassword} onChange={handleSecurityChange} className={inputCls} />
                </Field>

                <div className="text-xs text-muted">
                  Password strength: <span className="font-semibold text-main">{passwordStrengthLabel(security.newPassword)}</span>
                </div>

                <div className="pt-1">
                  <button disabled={saving || loading} className={btnPrimary}>
                    {saving ? "Updating..." : "Update Password"}
                  </button>
                </div>
              </form>
            </section>

            <section className={`${cardCls} p-6`}>
              <h2 className="text-lg font-semibold text-main">Project Preferences</h2>
              <p className="mt-1 text-xs text-muted">Set default behavior for charts and review lists.</p>

              <div className="mt-5 space-y-4">
                <Field label="Theme">
                  <select name="theme" value={prefs.theme} onChange={handlePrefsChange} className={inputCls}>
                    {themes.map((t) => (
                      <option key={t} value={t}>{t}</option>
                    ))}
                  </select>
                </Field>

                <Field label="Default Dashboard Range">
                  <select name="defaultDateRange" value={prefs.defaultDateRange} onChange={handlePrefsChange} className={inputCls}>
                    <option>Today</option>
                    <option>This Week</option>
                    <option>This Month</option>
                    <option>This Year</option>
                  </select>
                </Field>

                <Field label="Default Role Filter">
                  <input name="defaultRoleFilter" value={prefs.defaultRoleFilter} onChange={handlePrefsChange} className={inputCls} />
                </Field>

                <Field label={`Low-Confidence Threshold (${prefs.confidenceThreshold.toFixed(2)})`}>
                  <input
                    type="range"
                    min="0.5"
                    max="0.95"
                    step="0.01"
                    name="confidenceThreshold"
                    value={prefs.confidenceThreshold}
                    onChange={handlePrefsChange}
                    className="w-full accent-[#2F8DCD]"
                  />
                </Field>
              </div>
            </section>

            <section className={`${cardCls} p-6`}>
              <h2 className="text-lg font-semibold text-main">Notifications</h2>
              <p className="mt-1 text-xs text-muted">Choose which alerts you want to see while using the app.</p>

              <div className="mt-5 space-y-3">
                <ToggleRow
                  title="Processing too long"
                  subtitle="Alert when applications remain in processing state for too long."
                  enabled={notify.processingTooLong}
                  onToggle={() => handleNotifyToggle("processingTooLong")}
                />
                <ToggleRow
                  title="Low-confidence completed"
                  subtitle="Alert when completed interviews have low AI confidence."
                  enabled={notify.lowConfidenceCompleted}
                  onToggle={() => handleNotifyToggle("lowConfidenceCompleted")}
                />
                <ToggleRow
                  title="Daily summary"
                  subtitle="Show a simple daily summary with follow-up counts."
                  enabled={notify.dailySummary}
                  onToggle={() => handleNotifyToggle("dailySummary")}
                />
              </div>
            </section>
          </div>
        </div>

        <div className="fixed bottom-4 right-6 left-[130px] z-20">
          <div className="max-w-[1200px] mx-auto rounded-2xl border border-token bg-surface-strong backdrop-blur-md px-5 py-4 shadow-card">
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
              <p className="text-sm text-main">
                {hasUnsaved ? "You have unsaved settings changes." : "All settings are up to date."}
              </p>
              <div className="flex items-center gap-2">
                <button type="button" onClick={resetUnsaved} className={btnSecondary} disabled={!hasUnsaved || saving}>
                  Reset
                </button>
                <button type="button" onClick={savePreferences} className={btnPrimary} disabled={saving || (!prefsDirty && !notifyDirty)}>
                  Save Preferences
                </button>
              </div>
            </div>
          </div>
        </div>
      </main>

      <SettingsModal
        open={showModal}
        onClose={() => setShowModal(false)}
        message={modalMessage}
      />
    </div>
  );
}

function Field({ label, children }) {
  return (
    <label className="block">
      <div className="text-xs font-semibold text-muted mb-2">{label}</div>
      {children}
    </label>
  );
}

function ToggleRow({ title, subtitle, enabled, onToggle }) {
  return (
    <button
      type="button"
      onClick={onToggle}
      className="w-full rounded-xl bg-surface-strong border border-token px-4 py-3 text-left"
    >
      <div className="flex items-start justify-between gap-3">
        <div>
          <p className="text-sm font-semibold text-main">{title}</p>
          <p className="text-xs text-muted mt-0.5">{subtitle}</p>
        </div>
        <span className={`inline-flex items-center rounded-full px-2.5 py-1 text-xs font-semibold border ${enabled ? "bg-sky-100 text-sky-800 border-sky-200" : "bg-slate-100 text-slate-600 border-slate-200"}`}>
          {enabled ? "On" : "Off"}
        </span>
      </div>
    </button>
  );
}

