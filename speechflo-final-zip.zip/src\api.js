const devApiBaseUrl = "http://localhost:3000";

export function apiUrl(path) {
  if (/^https?:\/\//i.test(path)) {
    return path;
  }

  const normalizedPath = path.startsWith("/") ? path : `/${path}`;
  const configuredBase = String(import.meta.env.VITE_API_BASE_URL || "")
    .trim()
    .replace(/\/+$/, "");
  const baseUrl = configuredBase || (import.meta.env.DEV ? devApiBaseUrl : "");

  return baseUrl ? `${baseUrl}${normalizedPath}` : normalizedPath;
}
