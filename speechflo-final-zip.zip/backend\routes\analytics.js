import express from "express";
import { db } from "../db.js";
import { authMiddleware, requireRole } from "./authMiddleware.js";

const router = express.Router();
router.use(authMiddleware);
router.use(requireRole("recruiter", "admin"));

function parseDateWindow(dateFilter = "Date") {
  const now = new Date();
  const start = new Date(0);
  if (dateFilter === "This Week") {
    start.setTime(now.getTime() - 7 * 24 * 60 * 60 * 1000);
  } else if (dateFilter === "This Month") {
    start.setTime(now.getTime() - 30 * 24 * 60 * 60 * 1000);
  } else if (dateFilter === "This Year") {
    start.setTime(now.getTime() - 365 * 24 * 60 * 60 * 1000);
  }
  return start;
}

function safeJsonArray(value) {
  if (!value) return [];
  try {
    const parsed = JSON.parse(value);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

function computeClarityScore(transcript = "") {
  const words = transcript.trim().split(/\s+/).filter(Boolean);
  if (!words.length) return 0;
  const filler = (transcript.match(/\b(um|uh|like|you know)\b/gi) || []).length;
  const ratio = filler / words.length;
  return Math.max(0, 1 - ratio * 8);
}

function formatDay(dateValue) {
  const d = new Date(dateValue);
  if (Number.isNaN(d.getTime())) return "";
  return d.toISOString().slice(0, 10);
}

function percentile(values, p) {
  if (!values.length) return 0;
  const sorted = [...values].sort((a, b) => a - b);
  const idx = Math.min(sorted.length - 1, Math.max(0, Math.floor((p / 100) * (sorted.length - 1))));
  return sorted[idx];
}

router.get("/summary", async (req, res) => {
  try {
    const role = req.query.role || "All Roles";
    const date = req.query.date || "Date";
    const startDate = parseDateWindow(date);

    const [rows] = await db.query(
      `
      SELECT
        ja.id AS application_id,
        ja.status,
        ja.applied_at,
        ja.updated_at,
        j.title AS role,
        u.id AS applicant_id,
        u.first_name,
        u.last_name,
        ia.transcript,
        ia.skills_json,
        ia.weighted_score,
        ia.confidence,
        ia.missing_skills_json
      FROM job_applications ja
      JOIN jobs j ON j.id = ja.job_id
      JOIN users u ON u.id = ja.user_id
      LEFT JOIN interview_artifacts ia ON ia.application_id = ja.id
      ORDER BY ja.applied_at DESC
      `
    );

    const filtered = rows.filter((r) => {
      const roleOk = role === "All Roles" || r.role === role;
      const dateOk = !r.applied_at || new Date(r.applied_at) >= startDate;
      return roleOk && dateOk;
    });

    const total = filtered.length;
    const submitted = filtered.filter((r) => r.status === "submitted").length;
    const processing = filtered.filter((r) => r.status === "processing").length;
    const completed = filtered.filter((r) => r.status === "completed").length;
    const endorsed = filtered.filter((r) => r.status === "endorsed").length;
    const rejected = filtered.filter((r) => r.status === "rejected").length;

    const withScore = filtered.filter((r) => r.weighted_score !== null && r.weighted_score !== undefined);
    const withConfidence = filtered.filter((r) => r.confidence !== null && r.confidence !== undefined);
    const avgWeighted =
      withScore.length > 0
        ? withScore.reduce((sum, r) => sum + Number(r.weighted_score || 0), 0) / withScore.length
        : 0;
    const avgConfidence =
      withConfidence.length > 0
        ? withConfidence.reduce((sum, r) => sum + Number(r.confidence || 0), 0) / withConfidence.length
        : 0;

    const clarityRows = filtered.filter((r) => r.transcript);
    const avgClarity =
      clarityRows.length > 0
        ? clarityRows.reduce((sum, r) => sum + computeClarityScore(r.transcript), 0) / clarityRows.length
        : 0;

    const variance =
      withScore.length > 1
        ? withScore.reduce((sum, r) => {
            const d = Number(r.weighted_score || 0) - avgWeighted;
            return sum + d * d;
          }, 0) / withScore.length
        : 0;
    const differentiationIndex = Math.sqrt(variance);

    const completionRate = total > 0 ? (completed + endorsed) / total : 0;
    const rejectionRate = total > 0 ? rejected / total : 0;
    const lowConfidenceCount = withConfidence.filter((r) => Number(r.confidence) < 0.7).length;
    const lowConfidenceRate = withConfidence.length > 0 ? lowConfidenceCount / withConfidence.length : 0;
    const openQueueCount = submitted + processing;

    const completedDurationsDays = filtered
      .filter((r) => (r.status === "completed" || r.status === "endorsed") && r.applied_at && r.updated_at)
      .map((r) => {
        const ms = new Date(r.updated_at).getTime() - new Date(r.applied_at).getTime();
        return ms > 0 ? ms / (1000 * 60 * 60 * 24) : 0;
      });
    const medianTimeToCompletion = percentile(completedDurationsDays, 50);
    const p90TimeToCompletion = percentile(completedDurationsDays, 90);

    const distribution = {
      high: withScore.filter((r) => Number(r.weighted_score) >= 0.85).length,
      medium: withScore.filter((r) => Number(r.weighted_score) >= 0.7 && Number(r.weighted_score) < 0.85).length,
      low: withScore.filter((r) => Number(r.weighted_score) < 0.7).length,
    };

    const skillCounts = new Map();
    let totalExtractedSkills = 0;
    filtered.forEach((r) => {
      const extracted = safeJsonArray(r.skills_json);
      totalExtractedSkills += extracted.length;
      extracted.forEach((s) => {
        const key = String(s || "").trim();
        if (!key) return;
        skillCounts.set(key, (skillCounts.get(key) || 0) + 1);
      });
    });
    const topicCoverage = Array.from(skillCounts.entries())
      .sort((a, b) => b[1] - a[1])
      .slice(0, 12)
      .map(([skill, count]) => ({ skill, count }));
    const topSkillMentioned = topicCoverage[0]?.skill || "N/A";
    const avgKeywordCoverage = total > 0 ? totalExtractedSkills / total : 0;

    const missingCounts = new Map();
    filtered.forEach((r) => {
      safeJsonArray(r.missing_skills_json).forEach((s) => {
        const key = String(s || "").trim();
        if (!key) return;
        missingCounts.set(key, (missingCounts.get(key) || 0) + 1);
      });
    });
    const missingSkills = Array.from(missingCounts.entries())
      .sort((a, b) => b[1] - a[1])
      .slice(0, 10)
      .map(([skill, count]) => ({ skill, count }));

    const candidates = filtered
      .map((r) => ({
        applicationId: r.application_id,
        name: `${r.first_name} ${r.last_name}`.trim(),
        role: r.role,
        date: r.applied_at,
        status: r.status,
        weightedScore: r.weighted_score === null ? null : Number(r.weighted_score),
        confidence: r.confidence === null ? null : Number(r.confidence),
      }))
      .sort((a, b) => Number(b.weightedScore || -1) - Number(a.weightedScore || -1))
      .slice(0, 10);

    const recentApplications = filtered
      .map((r) => ({
        applicationId: r.application_id,
        name: `${r.first_name} ${r.last_name}`.trim(),
        role: r.role,
        date: r.applied_at,
        status: r.status,
      }))
      .sort((a, b) => new Date(b.date || 0).getTime() - new Date(a.date || 0).getTime())
      .slice(0, 8);

    const oldestProcessing = filtered
      .filter((r) => r.status === "submitted" || r.status === "processing")
      .sort((a, b) => new Date(a.applied_at || 0).getTime() - new Date(b.applied_at || 0).getTime())
      .slice(0, 5)
      .map((r) => ({
        applicationId: r.application_id,
        applicantId: r.applicant_id,
        name: `${r.first_name} ${r.last_name}`.trim(),
        role: r.role,
        date: r.applied_at,
        status: r.status,
      }));

    const lowConfidenceCompleted = filtered
      .filter((r) => (r.status === "completed" || r.status === "endorsed") && r.confidence !== null && Number(r.confidence) < 0.7)
      .sort((a, b) => Number(a.confidence || 1) - Number(b.confidence || 1))
      .slice(0, 5)
      .map((r) => ({
        applicationId: r.application_id,
        name: `${r.first_name} ${r.last_name}`.trim(),
        role: r.role,
        confidence: Number(r.confidence),
        date: r.applied_at,
      }));

    const priorityCandidates = filtered
      .map((r) => ({
        applicationId: r.application_id,
        name: `${r.first_name} ${r.last_name}`.trim(),
        role: r.role,
        status: r.status,
        weightedScore: r.weighted_score === null ? null : Number(r.weighted_score),
        confidence: r.confidence === null ? null : Number(r.confidence),
      }))
      .filter((r) => r.status === "submitted" || (r.confidence !== null && r.confidence < 0.7))
      .sort((a, b) => {
        const aPri = a.status === "submitted" ? 2 : 1;
        const bPri = b.status === "submitted" ? 2 : 1;
        if (aPri !== bPri) return bPri - aPri;
        return Number(a.confidence ?? 1) - Number(b.confidence ?? 1);
      })
      .slice(0, 10);

    const byDay = new Map();
    filtered.forEach((r) => {
      const day = formatDay(r.applied_at);
      if (!day) return;
      if (!byDay.has(day)) {
        byDay.set(day, { date: day, uploaded: 0, submitted: 0, processing: 0, completed: 0, endorsed: 0, rejected: 0 });
      }
      const row = byDay.get(day);
      row.uploaded += 1;
      if (r.status === "submitted") row.submitted += 1;
      if (r.status === "processing") row.processing += 1;
      if (r.status === "completed") row.completed += 1;
      if (r.status === "endorsed") row.endorsed += 1;
      if (r.status === "rejected") row.rejected += 1;
    });
    const timeline = Array.from(byDay.values()).sort((a, b) => a.date.localeCompare(b.date));

    const scoreHistogram = [
      { range: "0.00-0.19", min: 0.0, max: 0.2, count: 0 },
      { range: "0.20-0.39", min: 0.2, max: 0.4, count: 0 },
      { range: "0.40-0.59", min: 0.4, max: 0.6, count: 0 },
      { range: "0.60-0.79", min: 0.6, max: 0.8, count: 0 },
      { range: "0.80-1.00", min: 0.8, max: 1.01, count: 0 },
    ];
    withScore.forEach((r) => {
      const score = Number(r.weighted_score || 0);
      const bucket = scoreHistogram.find((b) => score >= b.min && score < b.max);
      if (bucket) bucket.count += 1;
    });
    const histogram = scoreHistogram.map((b) => ({ range: b.range, count: b.count }));

    const roleMap = new Map();
    filtered.forEach((r) => {
      if (!roleMap.has(r.role)) {
        roleMap.set(r.role, { role: r.role, total: 0, scoreTotal: 0, scoreCount: 0, rejectCount: 0, missingCount: 0 });
      }
      const item = roleMap.get(r.role);
      item.total += 1;
      if (r.status === "rejected") item.rejectCount += 1;
      if (r.weighted_score !== null && r.weighted_score !== undefined) {
        item.scoreTotal += Number(r.weighted_score);
        item.scoreCount += 1;
      }
      item.missingCount += safeJsonArray(r.missing_skills_json).length;
    });
    const rolePerformance = Array.from(roleMap.values())
      .map((r) => ({
        role: r.role,
        avgScore: r.scoreCount > 0 ? Number((r.scoreTotal / r.scoreCount).toFixed(2)) : 0,
        rejectionRate: r.total > 0 ? Number((r.rejectCount / r.total).toFixed(2)) : 0,
        difficultyIndex: r.total > 0 ? Number((r.missingCount / r.total).toFixed(2)) : 0,
      }))
      .sort((a, b) => b.avgScore - a.avgScore);
    const roleWithLowestAvgScore =
      rolePerformance.length > 0
        ? [...rolePerformance].sort((a, b) => a.avgScore - b.avgScore)[0]
        : null;

    const confidenceVsScore = filtered
      .filter((r) => r.weighted_score !== null && r.confidence !== null)
      .map((r) => ({
        applicationId: r.application_id,
        score: Number(r.weighted_score),
        confidence: Number(r.confidence),
      }));

    const roleOptions = ["All Roles", ...Array.from(new Set(rows.map((r) => r.role).filter(Boolean)))];

    res.json({
      stats: {
        interviewsUploaded: total,
        endorsedCount: endorsed,
        completionRate: Number(completionRate.toFixed(2)),
        rejectionRate: Number(rejectionRate.toFixed(2)),
        avgSkillValidationConfidence: Number(avgConfidence.toFixed(2)),
        avgExperienceAlignment: Number(avgWeighted.toFixed(2)),
        avgCommunicationClarity: Number(avgClarity.toFixed(2)),
        candidateDifferentiationIndex: Number(differentiationIndex.toFixed(2)),
        lowConfidenceRate: Number(lowConfidenceRate.toFixed(2)),
        manualReviewQueue: openQueueCount,
        pendingReviewCount: openQueueCount,
        medianTimeToCompletionDays: Number(medianTimeToCompletion.toFixed(2)),
        p90TimeToCompletionDays: Number(p90TimeToCompletion.toFixed(2)),
        avgKeywordCoverage: Number(avgKeywordCoverage.toFixed(2)),
        topSkillMentioned,
        roleWithLowestAvgScore,
        topMissingSkill: missingSkills[0] || null,
      },
      distribution,
      topicCoverage,
      missingSkills,
      candidates,
      recentApplications,
      priorityCandidates,
      workflow: {
        oldestProcessing,
        lowConfidenceCompleted,
        candidatesNeedingManualReview: priorityCandidates,
        roleWithLowestAvgScore,
        topMissingSkill: missingSkills[0] || null,
      },
      charts: {
        timeline,
        histogram,
        rolePerformance,
        confidenceVsScore,
      },
      filters: {
        roleOptions,
      },
    });
  } catch (err) {
    console.error("[Analytics] error:", err);
    res.status(500).json({ error: "Failed to fetch analytics summary" });
  }
});

export default router;
