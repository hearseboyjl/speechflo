import express from "express";
import { db } from "../db.js";
import { authMiddleware, requireRole } from "./authMiddleware.js";
import { writeAuditLog } from "../utils/auditLog.js";
import { appendApplicationStatusEvent } from "../utils/applicationTimeline.js";

const router = express.Router();

router.use(authMiddleware);

const ALLOWED_ACTIONS = new Set(["create", "update", "delete"]);
const ALLOWED_APPLICATION_STATUSES = new Set([
  "submitted",
  "processing",
  "completed",
  "endorsed",
  "rejected",
]);
const JOB_LIFECYCLE_STATUSES = new Set(["draft", "published", "closed"]);
const ALLOWED_APPLICATION_REQUEST_ACTIONS = new Set([
  "status_update",
  "status_change",
  "update_status",
  "undo",
  "correct",
  "correct_status",
]);

function cleanString(value, { lower = false } = {}) {
  const normalized = String(value || "").trim();
  return lower ? normalized.toLowerCase() : normalized;
}

function coerceBoolean(value, defaultValue = false) {
  if (typeof value === "boolean") return value;
  if (value === 1 || value === "1" || value === "true") return true;
  if (value === 0 || value === "0" || value === "false") return false;
  return defaultValue;
}

function normalizeLegacyLifecycle(value = "") {
  const status = cleanString(value, { lower: true });
  if (status === "archived") return "closed";
  return status;
}

function normalizeWeight(value, fallback = 1) {
  const parsed = Number(value);
  if (!Number.isFinite(parsed)) return fallback;
  if (parsed < 0) return 0;
  if (parsed > 1) return 1;
  return parsed;
}

function parseJsonValue(value, fallback = null) {
  if (!value) return fallback;
  try {
    return JSON.parse(value);
  } catch {
    return fallback;
  }
}

function slugifyRoleKey(value) {
  return cleanString(value, { lower: true })
    .replace(/[^a-z0-9]+/g, "_")
    .replace(/^_+|_+$/g, "")
    .slice(0, 120);
}

function normalizeJobSkills(skills = []) {
  return (Array.isArray(skills) ? skills : [])
    .map((skill) => ({
      name: cleanString(skill?.name),
      category: cleanString(skill?.category),
      required: coerceBoolean(skill?.required, true),
      weight: normalizeWeight(skill?.weight, 1),
    }))
    .filter((skill) => skill.name);
}

function normalizeKbSkills(skills = []) {
  return (Array.isArray(skills) ? skills : [])
    .map((skill) => ({
      name: cleanString(skill?.name),
      aliases: Array.isArray(skill?.aliases)
        ? skill.aliases.map((alias) => cleanString(alias)).filter(Boolean)
        : String(skill?.aliasesText || "")
            .split(",")
            .map((alias) => cleanString(alias))
            .filter(Boolean),
      category: cleanString(skill?.category),
      required: coerceBoolean(skill?.required, true),
      weight: Number(skill?.weight ?? 0),
      isCritical: coerceBoolean(skill?.isCritical, false),
    }))
    .filter((skill) => skill.name);
}

function normalizeJobPayload(raw = {}) {
  const lifecycleStatus = normalizeLegacyLifecycle(raw.lifecycleStatus);
  return {
    title: cleanString(raw.title),
    description: cleanString(raw.description),
    companyName: cleanString(raw.companyName),
    employmentType: cleanString(raw.employmentType),
    workSetup: cleanString(raw.workSetup),
    city: cleanString(raw.city),
    region: cleanString(raw.region),
    isActive: coerceBoolean(raw.isActive, true),
    lifecycleStatus: JOB_LIFECYCLE_STATUSES.has(lifecycleStatus) ? lifecycleStatus : "",
    skills: normalizeJobSkills(raw.skills),
  };
}

function resolveJobLifecycleSnapshot(payload = {}, existing = null) {
  const requested = normalizeLegacyLifecycle(payload?.lifecycleStatus);
  const existingStatus = normalizeLegacyLifecycle(existing?.lifecycle_status);
  const status = JOB_LIFECYCLE_STATUSES.has(requested)
    ? requested
    : existingStatus || (coerceBoolean(payload?.isActive, true) ? "published" : "draft");

  const now = new Date();
  const publishedAt =
    status === "published" ? existing?.published_at || now : existing?.published_at || null;
  const closedAt =
    status === "closed"
      ? existingStatus === "closed"
        ? existing?.closed_at || now
        : now
      : null;

  return {
    lifecycleStatus: status,
    isActive: status === "published",
    publishedAt,
    closedAt,
    archivedAt: null,
  };
}

function deriveJobTitleFromSummary(summary = "") {
  const text = String(summary || "").trim();
  if (!text) return "";
  const createMatch = text.match(/requested\s+job\s+create:\s*(.+)$/i);
  if (createMatch?.[1]) return cleanString(createMatch[1]);
  const updateMatch = text.match(/requested\s+job\s+update\s*#\d+:\s*(.+)$/i);
  if (updateMatch?.[1]) return cleanString(updateMatch[1]);
  return "";
}

function parseLegacyJobSkillsText(value = "") {
  const lines = String(value || "")
    .split(/\r?\n/)
    .map((line) => line.trim())
    .filter(Boolean);

  const skills = [];
  for (const line of lines) {
    const parts = line.split("|").map((part) => String(part || "").trim());
    const [name, category = "", requiredRaw = "true", weightRaw = "1"] = parts;
    if (!name) continue;
    skills.push({
      name,
      category,
      required: coerceBoolean(requiredRaw, true),
      weight: normalizeWeight(weightRaw, 1),
    });
  }

  return sanitizeJobSkillsForApply(skills);
}

function dedupeSkillsByName(skills = []) {
  const seen = new Set();
  const result = [];
  for (const skill of Array.isArray(skills) ? skills : []) {
    const key = cleanString(skill?.name, { lower: true });
    if (!key || seen.has(key)) continue;
    seen.add(key);
    result.push(skill);
  }
  return result;
}

function sanitizeJobSkillsForApply(skills = []) {
  const normalized = (Array.isArray(skills) ? skills : [])
    .map((skill) => ({
      name: cleanString(skill?.name),
      category: cleanString(skill?.category),
      required: coerceBoolean(skill?.required, true),
      weight: normalizeWeight(skill?.weight, 1),
    }))
    .filter((skill) => skill.name);

  return dedupeSkillsByName(normalized);
}

function normalizeJobPayloadForApproval(rawPayload = {}, summary = "") {
  const source =
    rawPayload && typeof rawPayload === "object" && !Array.isArray(rawPayload)
      ? rawPayload
      : {};

  const nested =
    source.payload && typeof source.payload === "object" && !Array.isArray(source.payload)
      ? source.payload
      : source;

  const normalized = normalizeJobPayload({
    title:
      nested.title ||
      nested.jobTitle ||
      nested.job_name ||
      nested.name ||
      deriveJobTitleFromSummary(summary),
    description: nested.description || nested.jobDescription || nested.details || "",
    companyName: nested.companyName || nested.company || nested.company_name || "",
    employmentType: nested.employmentType || nested.employment_type || nested.type || "",
    workSetup: nested.workSetup || nested.work_setup || "",
    city: nested.city || "",
    region: nested.region || "",
    isActive:
      nested.isActive !== undefined
        ? nested.isActive
        : nested.active !== undefined
        ? nested.active
        : true,
    skills: Array.isArray(nested.skills)
      ? nested.skills
      : parseLegacyJobSkillsText(nested.skillsText || nested.skills_text || ""),
  });

  // If title is still missing, preserve a final fallback from summary.
  if (!normalized.title) {
    normalized.title = deriveJobTitleFromSummary(summary);
  }

  // Preserve legacy parsed skills if modern normalizer filtered everything out.
  if ((!normalized.skills || !normalized.skills.length) && !Array.isArray(nested.skills)) {
    normalized.skills = parseLegacyJobSkillsText(nested.skillsText || nested.skills_text || "");
  }

  return normalized;
}

function normalizeKbPayload(raw = {}) {
  const name = cleanString(raw.name);
  return {
    kbRoleKey: slugifyRoleKey(raw.kbRoleKey || name),
    name,
    industry: cleanString(raw.industry),
    level: cleanString(raw.level),
    policy: {
      highThreshold: Number(raw.policy?.highThreshold ?? 80),
      moderateThreshold: Number(raw.policy?.moderateThreshold ?? 60),
      lowConfidenceThreshold: Number(raw.policy?.lowConfidenceThreshold ?? 0.7),
      criticalSkillPenalty: Number(raw.policy?.criticalSkillPenalty ?? 15),
    },
    skills: normalizeKbSkills(raw.skills),
  };
}

function mapRequestRow(row) {
  return {
    id: row.id,
    entityType: row.entity_type,
    actionType: row.action_type,
    targetId: row.target_id,
    payload: parseJsonValue(row.payload_json, null),
    summary: row.summary,
    status: row.status,
    submittedBy: row.submitted_by,
    submittedAt: row.submitted_at,
    requesterName: row.requester_name || "",
    requesterEmail: row.requester_email || "",
    reviewedBy: row.reviewed_by,
    reviewedAt: row.reviewed_at,
    reviewerName: row.reviewer_name || "",
    reviewerEmail: row.reviewer_email || "",
    reviewNote: row.review_note || "",
  };
}

function inferActionFromSummary(summary = "") {
  const text = cleanString(summary, { lower: true });
  if (!text) return "";
  if (text.includes(" create")) return "create";
  if (text.includes(" update")) return "update";
  if (text.includes(" delete")) return "delete";
  return "";
}

function normalizeActionTypeForApply(actionTypeRaw = "", summary = "") {
  const action = cleanString(actionTypeRaw, { lower: true })
    .replace(/[\s-]+/g, "_")
    .trim();

  if (!action) return inferActionFromSummary(summary);

  const createAliases = new Set(["create", "job_create", "create_job", "add", "insert"]);
  const updateAliases = new Set(["update", "job_update", "update_job", "edit", "modify"]);
  const deleteAliases = new Set([
    "delete",
    "job_delete",
    "delete_job",
    "remove",
    "archive",
    "deactivate",
  ]);

  if (createAliases.has(action)) return "create";
  if (updateAliases.has(action)) return "update";
  if (deleteAliases.has(action)) return "delete";
  return action;
}

async function insertRequest({
  entityType,
  actionType,
  targetId = null,
  payload = null,
  summary,
  submittedBy,
}) {
  const [result] = await db.query(
    `
    INSERT INTO change_requests (
      entity_type,
      action_type,
      target_id,
      payload_json,
      summary,
      status,
      submitted_by
    ) VALUES (?, ?, ?, ?, ?, 'pending', ?)
    `,
    [
      entityType,
      actionType,
      targetId ? String(targetId) : null,
      payload ? JSON.stringify(payload) : null,
      summary,
      submittedBy,
    ]
  );

  return result.insertId;
}

function resolveApplicationTargetId(targetId, payload = {}) {
  const directId = Number(targetId);
  if (Number.isFinite(directId)) return directId;

  const payloadTarget = Number(payload?.targetId);
  if (Number.isFinite(payloadTarget)) return payloadTarget;

  const payloadAppId = Number(payload?.applicationId);
  if (Number.isFinite(payloadAppId)) return payloadAppId;

  return null;
}

function normalizeApplicationRequestAction(actionTypeRaw = "") {
  const action = cleanString(actionTypeRaw, { lower: true })
    .replace(/[\s-]+/g, "_")
    .trim();
  if (!action) return "status_update";

  if (action === "update") return "status_update";
  return action;
}

async function loadApplicationReference(executor, applicationId) {
  const [rows] = await executor.query(
    `
    SELECT
      ja.id,
      ja.status,
      ja.rejection_reason,
      ja.applied_at,
      u.id AS applicant_id,
      u.first_name,
      u.last_name,
      u.email,
      j.title AS job_title
    FROM job_applications ja
    JOIN users u ON u.id = ja.user_id
    JOIN jobs j ON j.id = ja.job_id
    WHERE ja.id = ?
    LIMIT 1
    `,
    [applicationId]
  );

  return rows[0] || null;
}

async function applyApplicationStatusChange(
  connection,
  actionType,
  targetId,
  payload,
  actorUserId = null
) {
  const normalizedAction = normalizeApplicationRequestAction(actionType);
  if (!ALLOWED_APPLICATION_REQUEST_ACTIONS.has(normalizedAction)) {
    throw new Error(`Unsupported application action: ${actionType}`);
  }

  const applicationId = resolveApplicationTargetId(targetId, payload);
  if (!Number.isFinite(applicationId)) {
    throw new Error("Valid application id is required.");
  }

  const nextStatus = cleanString(payload?.toStatus || payload?.status, { lower: true });
  if (!ALLOWED_APPLICATION_STATUSES.has(nextStatus)) {
    throw new Error("Invalid target status for application correction.");
  }

  const application = await loadApplicationReference(connection, applicationId);
  if (!application) {
    throw new Error("Application not found.");
  }

  const currentStatus = cleanString(application.status, { lower: true });
  const requestedReason = cleanString(payload?.reason || payload?.note || payload?.reviewNote);
  const requestedRejectionReason = cleanString(payload?.rejectionReason);
  const clearRejectionReason = coerceBoolean(payload?.clearRejectionReason, true);

  if (currentStatus === nextStatus) {
    const sameRejectionReason =
      nextStatus !== "rejected" ||
      cleanString(application.rejection_reason) === requestedRejectionReason;
    if (sameRejectionReason) {
      throw new Error("Application is already in the requested status.");
    }
  }

  let nextRejectionReason = application.rejection_reason || null;
  if (nextStatus === "rejected") {
    const finalReason = requestedRejectionReason || cleanString(application.rejection_reason);
    if (!finalReason) {
      throw new Error("Rejection reason is required when moving to rejected status.");
    }
    nextRejectionReason = finalReason;
  } else if (clearRejectionReason) {
    nextRejectionReason = null;
  }

  await connection.query(
    `
    UPDATE job_applications
    SET
      status = ?,
      rejection_reason = ?,
      updated_at = NOW()
    WHERE id = ?
    `,
    [nextStatus, nextRejectionReason, applicationId]
  );

  const timelineNote =
    requestedReason ||
    `Status corrected from ${currentStatus || "unknown"} to ${nextStatus} via admin-approved request.`;

  await appendApplicationStatusEvent(connection, {
    applicationId,
    status: nextStatus,
    note: timelineNote,
    changedBy: actorUserId || null,
  });

  return { entityType: "application", entityId: String(applicationId) };
}

async function applyJobChange(connection, actionType, targetId, payload) {
  if (actionType === "create") {
    if (!payload?.title) {
      throw new Error("Job title is required for create requests.");
    }

    const lifecycle = resolveJobLifecycleSnapshot(payload);
    const [insertResult] = await connection.query(
      `
      INSERT INTO jobs (
        title,
        description,
        company_name,
        employment_type,
        work_setup,
        city,
        region,
        is_active,
        lifecycle_status,
        published_at,
        closed_at,
        archived_at
      )
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `,
      [
        payload.title,
        payload.description || null,
        payload.companyName || null,
        payload.employmentType || null,
        payload.workSetup || null,
        payload.city || null,
        payload.region || null,
        lifecycle.isActive ? 1 : 0,
        lifecycle.lifecycleStatus,
        lifecycle.publishedAt,
        lifecycle.closedAt,
        lifecycle.archivedAt,
      ]
    );

    const jobId = insertResult.insertId;
    for (const skill of dedupeSkillsByName(payload.skills || [])) {
      await connection.query(
        `
        INSERT INTO job_skills (
          job_id,
          job_name,
          skill_name,
          category,
          required,
          weight
        ) VALUES (?, ?, ?, ?, ?, ?)
        `,
        [
          jobId,
          payload.title,
          skill.name,
          skill.category || null,
          skill.required ? 1 : 0,
          skill.weight,
        ]
      );
    }

    return { entityType: "job", entityId: String(jobId) };
  }

  const jobId = Number(targetId);
  if (!Number.isFinite(jobId)) {
    throw new Error("Valid job id is required.");
  }

  const [existingRows] = await connection.query(
    `
    SELECT
      id,
      title,
      description,
      company_name,
      employment_type,
      work_setup,
      city,
      region,
      is_active,
      lifecycle_status,
      published_at,
      closed_at,
      archived_at
    FROM jobs
    WHERE id = ?
    LIMIT 1
    `,
    [jobId]
  );
  if (!existingRows.length) {
    throw new Error("Job not found.");
  }

  const existing = existingRows[0];

  if (actionType === "delete") {
    await connection.query("UPDATE jobs SET is_active = 0 WHERE id = ?", [jobId]);
    return { entityType: "job", entityId: String(jobId) };
  }

  if (actionType !== "update") {
    throw new Error(`Unsupported job action: ${actionType}`);
  }

  const nextTitle = payload?.title || existing.title;
  if (!nextTitle) {
    throw new Error("Job title is required.");
  }

  const lifecycle = resolveJobLifecycleSnapshot(payload, existing);

  await connection.query(
    `
    UPDATE jobs
    SET
      title = ?,
      description = ?,
      company_name = ?,
      employment_type = ?,
      work_setup = ?,
      city = ?,
      region = ?,
      is_active = ?,
      lifecycle_status = ?,
      published_at = ?,
      closed_at = ?,
      archived_at = ?
    WHERE id = ?
    `,
    [
      nextTitle,
      payload?.description || existing.description || null,
      payload?.companyName || existing.company_name || null,
      payload?.employmentType || existing.employment_type || null,
      payload?.workSetup || existing.work_setup || null,
      payload?.city || existing.city || null,
      payload?.region || existing.region || null,
      lifecycle.isActive ? 1 : 0,
      lifecycle.lifecycleStatus,
      lifecycle.publishedAt,
      lifecycle.closedAt,
      lifecycle.archivedAt,
      jobId,
    ]
  );

  if (Array.isArray(payload?.skills) && payload.skills.length > 0) {
    await connection.query("DELETE FROM job_skills WHERE job_id = ?", [jobId]);
    for (const skill of dedupeSkillsByName(payload.skills)) {
      await connection.query(
        `
        INSERT INTO job_skills (
          job_id,
          job_name,
          skill_name,
          category,
          required,
          weight
        ) VALUES (?, ?, ?, ?, ?, ?)
        `,
        [
          jobId,
          nextTitle,
          skill.name,
          skill.category || null,
          skill.required ? 1 : 0,
          skill.weight,
        ]
      );
    }
  } else {
    await connection.query("UPDATE job_skills SET job_name = ? WHERE job_id = ?", [
      nextTitle,
      jobId,
    ]);
  }

  return { entityType: "job", entityId: String(jobId) };
}

async function insertKbSkills(connection, roleId, skills = []) {
  for (const skill of skills) {
    await connection.query(
      `
      INSERT INTO knowledgebase_skills (
        role_id,
        skill_name,
        aliases_json,
        category,
        required,
        weight,
        is_critical
      ) VALUES (?, ?, ?, ?, ?, ?, ?)
      `,
      [
        roleId,
        skill.name,
        JSON.stringify(skill.aliases || []),
        skill.category || null,
        skill.required ? 1 : 0,
        skill.weight,
        skill.isCritical ? 1 : 0,
      ]
    );
  }
}

async function upsertKbPolicy(connection, roleId, policy = {}) {
  await connection.query(
    `
    INSERT INTO knowledgebase_role_policy (
      role_id,
      high_threshold,
      moderate_threshold,
      low_confidence_threshold,
      critical_skill_penalty
    ) VALUES (?, ?, ?, ?, ?)
    ON DUPLICATE KEY UPDATE
      high_threshold = VALUES(high_threshold),
      moderate_threshold = VALUES(moderate_threshold),
      low_confidence_threshold = VALUES(low_confidence_threshold),
      critical_skill_penalty = VALUES(critical_skill_penalty)
    `,
    [
      roleId,
      Number(policy.highThreshold ?? 80),
      Number(policy.moderateThreshold ?? 60),
      Number(policy.lowConfidenceThreshold ?? 0.7),
      Number(policy.criticalSkillPenalty ?? 15),
    ]
  );
}

async function applyKbChange(connection, actionType, targetId, payload) {
  if (actionType === "create") {
    if (!payload?.name || !payload?.kbRoleKey) {
      throw new Error("KB role name and key are required for create requests.");
    }

    const [dupe] = await connection.query(
      "SELECT id FROM knowledgebase_roles WHERE kb_role_key = ? LIMIT 1",
      [payload.kbRoleKey]
    );
    if (dupe.length) {
      throw new Error("KB role key already exists.");
    }

    const [result] = await connection.query(
      `
      INSERT INTO knowledgebase_roles (
        kb_role_key,
        name,
        industry,
        level
      ) VALUES (?, ?, ?, ?)
      `,
      [
        payload.kbRoleKey,
        payload.name,
        payload.industry || null,
        payload.level || null,
      ]
    );
    const roleId = result.insertId;

    await insertKbSkills(connection, roleId, payload.skills || []);
    await upsertKbPolicy(connection, roleId, payload.policy || {});

    return { entityType: "kb_role", entityId: String(roleId) };
  }

  const roleId = Number(targetId);
  if (!Number.isFinite(roleId)) {
    throw new Error("Valid KB role id is required.");
  }

  const [existingRows] = await connection.query(
    `
    SELECT
      id,
      kb_role_key,
      name,
      industry,
      level
    FROM knowledgebase_roles
    WHERE id = ?
    LIMIT 1
    `,
    [roleId]
  );
  if (!existingRows.length) {
    throw new Error("Knowledge base role not found.");
  }
  const existing = existingRows[0];

  if (actionType === "delete") {
    await connection.query("DELETE FROM knowledgebase_roles WHERE id = ?", [roleId]);
    return { entityType: "kb_role", entityId: String(roleId) };
  }

  if (actionType !== "update") {
    throw new Error(`Unsupported KB role action: ${actionType}`);
  }

  const nextName = payload?.name || existing.name;
  const nextKey = payload?.kbRoleKey || existing.kb_role_key;
  if (!nextName || !nextKey) {
    throw new Error("KB role name and key are required.");
  }

  const [dupeKey] = await connection.query(
    `
    SELECT id
    FROM knowledgebase_roles
    WHERE kb_role_key = ? AND id <> ?
    LIMIT 1
    `,
    [nextKey, roleId]
  );
  if (dupeKey.length) {
    throw new Error("KB role key already exists.");
  }

  await connection.query(
    `
    UPDATE knowledgebase_roles
    SET
      kb_role_key = ?,
      name = ?,
      industry = ?,
      level = ?
    WHERE id = ?
    `,
    [
      nextKey,
      nextName,
      payload?.industry || existing.industry || null,
      payload?.level || existing.level || null,
      roleId,
    ]
  );

  if (Array.isArray(payload?.skills) && payload.skills.length > 0) {
    await connection.query("DELETE FROM knowledgebase_skills WHERE role_id = ?", [roleId]);
    await insertKbSkills(connection, roleId, payload.skills);
  }

  await upsertKbPolicy(connection, roleId, payload?.policy || {});
  return { entityType: "kb_role", entityId: String(roleId) };
}

async function applyRequestByType(connection, requestRow, actorUserId = null) {
  const payloadValue = parseJsonValue(requestRow.payload_json, {});
  const payload =
    payloadValue && typeof payloadValue === "object" && !Array.isArray(payloadValue)
      ? payloadValue
      : {};

  const entityType = cleanString(requestRow.entity_type, { lower: true });
  const actionType = normalizeActionTypeForApply(
    requestRow.action_type,
    requestRow.summary
  );
  const targetId = requestRow.target_id;

  if (entityType === "job" || entityType === "jobs") {
    const normalizedPayload = normalizeJobPayloadForApproval(payload, requestRow.summary);
    return applyJobChange(
      connection,
      actionType,
      targetId,
      normalizedPayload
    );
  }

  if (
    entityType === "kb_role" ||
    entityType === "knowledgebase_role" ||
    entityType === "knowledgebase_roles" ||
    entityType === "knowledgebase-role" ||
    entityType === "knowledgebase-roles"
  ) {
    return applyKbChange(
      connection,
      actionType,
      targetId,
      payload
    );
  }

  if (entityType === "application" || entityType === "applications") {
    return applyApplicationStatusChange(
      connection,
      actionType,
      targetId,
      payload,
      actorUserId
    );
  }

  throw new Error(`Unsupported entity type: ${requestRow.entity_type}`);
}

router.get("/reference/jobs", requireRole("recruiter", "admin"), async (_req, res) => {
  try {
    const [rows] = await db.query(
      `
      SELECT
        id,
        title,
        company_name,
        is_active,
        lifecycle_status
      FROM jobs
      ORDER BY title ASC, id DESC
      `
    );

    res.json(
      rows.map((row) => ({
        id: row.id,
        title: row.title,
        companyName: row.company_name || "",
        isActive: Boolean(row.is_active),
        lifecycleStatus:
          normalizeLegacyLifecycle(row.lifecycle_status) ||
          (Boolean(row.is_active) ? "published" : "closed"),
      }))
    );
  } catch (err) {
    console.error("[ChangeRequests][reference:jobs] error:", err);
    res.status(500).json({ message: "Failed to load jobs reference." });
  }
});

router.get(
  "/reference/jobs/:id",
  requireRole("recruiter", "admin"),
  async (req, res) => {
    try {
      const jobId = Number(req.params.id);
      if (!Number.isFinite(jobId)) {
        return res.status(400).json({ message: "Invalid job id." });
      }

      const [jobRows] = await db.query(
        `
        SELECT
          id,
          title,
          description,
          company_name,
          employment_type,
          work_setup,
          city,
          region,
          is_active,
          lifecycle_status,
          published_at,
          closed_at,
          archived_at
        FROM jobs
        WHERE id = ?
        LIMIT 1
        `,
        [jobId]
      );
      if (!jobRows.length) {
        return res.status(404).json({ message: "Job not found." });
      }

      const [skillRows] = await db.query(
        `
        SELECT
          skill_name,
          category,
          required,
          weight
        FROM job_skills
        WHERE job_id = ?
        ORDER BY required DESC, weight DESC, skill_name ASC
        `,
        [jobId]
      );

      res.json({
        id: jobRows[0].id,
        title: jobRows[0].title,
        description: jobRows[0].description || "",
        companyName: jobRows[0].company_name || "",
        employmentType: jobRows[0].employment_type || "",
        workSetup: jobRows[0].work_setup || "",
        city: jobRows[0].city || "",
        region: jobRows[0].region || "",
        isActive: Boolean(jobRows[0].is_active),
        lifecycleStatus:
          normalizeLegacyLifecycle(jobRows[0].lifecycle_status) ||
          (Boolean(jobRows[0].is_active) ? "published" : "closed"),
        publishedAt: jobRows[0].published_at || null,
        closedAt: jobRows[0].closed_at || null,
        archivedAt: jobRows[0].archived_at || null,
        skills: skillRows.map((row) => ({
          name: row.skill_name,
          category: row.category || "",
          required: Boolean(row.required),
          weight: Number(row.weight ?? 0),
        })),
      });
    } catch (err) {
      console.error("[ChangeRequests][reference:job-detail] error:", err);
      res.status(500).json({ message: "Failed to load job reference detail." });
    }
  }
);

router.get(
  "/reference/applications",
  requireRole("recruiter", "admin"),
  async (req, res) => {
    try {
      const limit = Math.min(Math.max(Number(req.query.limit || 300), 1), 1000);
      const [rows] = await db.query(
        `
        SELECT
          ja.id,
          ja.status,
          ja.rejection_reason,
          ja.applied_at,
          u.id AS applicant_id,
          u.first_name,
          u.last_name,
          u.email,
          j.title AS job_title
        FROM job_applications ja
        JOIN users u ON u.id = ja.user_id
        JOIN jobs j ON j.id = ja.job_id
        ORDER BY ja.applied_at DESC, ja.id DESC
        LIMIT ?
        `,
        [limit]
      );

      res.json(
        rows.map((row) => ({
          id: row.id,
          status: cleanString(row.status, { lower: true }),
          rejectionReason: row.rejection_reason || "",
          appliedAt: row.applied_at,
          applicantId: row.applicant_id,
          applicantName: `${cleanString(row.first_name)} ${cleanString(row.last_name)}`.trim(),
          applicantEmail: row.email || "",
          jobTitle: row.job_title || "",
        }))
      );
    } catch (err) {
      console.error("[ChangeRequests][reference:applications] error:", err);
      res.status(500).json({ message: "Failed to load applications reference." });
    }
  }
);

router.get(
  "/reference/knowledgebase-roles",
  requireRole("recruiter", "admin"),
  async (_req, res) => {
    try {
      const [rows] = await db.query(
        `
        SELECT
          id,
          kb_role_key,
          name,
          industry,
          level
        FROM knowledgebase_roles
        ORDER BY name ASC, id DESC
        `
      );

      res.json(
        rows.map((row) => ({
          id: row.id,
          kbRoleKey: row.kb_role_key,
          name: row.name,
          industry: row.industry || "",
          level: row.level || "",
        }))
      );
    } catch (err) {
      console.error("[ChangeRequests][reference:kb] error:", err);
      res.status(500).json({ message: "Failed to load KB role reference." });
    }
  }
);

router.get(
  "/reference/knowledgebase-roles/:id",
  requireRole("recruiter", "admin"),
  async (req, res) => {
    try {
      const roleId = Number(req.params.id);
      if (!Number.isFinite(roleId)) {
        return res.status(400).json({ message: "Invalid KB role id." });
      }

      const [roleRows] = await db.query(
        `
        SELECT
          kr.id,
          kr.kb_role_key,
          kr.name,
          kr.industry,
          kr.level,
          rp.high_threshold,
          rp.moderate_threshold,
          rp.low_confidence_threshold,
          rp.critical_skill_penalty
        FROM knowledgebase_roles kr
        LEFT JOIN knowledgebase_role_policy rp ON rp.role_id = kr.id
        WHERE kr.id = ?
        LIMIT 1
        `,
        [roleId]
      );
      if (!roleRows.length) {
        return res.status(404).json({ message: "KB role not found." });
      }

      const [skillRows] = await db.query(
        `
        SELECT
          skill_name,
          aliases_json,
          category,
          required,
          weight,
          is_critical
        FROM knowledgebase_skills
        WHERE role_id = ?
        ORDER BY required DESC, weight DESC, skill_name ASC
        `,
        [roleId]
      );

      const role = roleRows[0];
      res.json({
        id: role.id,
        kbRoleKey: role.kb_role_key,
        name: role.name,
        industry: role.industry || "",
        level: role.level || "",
        policy: {
          highThreshold: Number(role.high_threshold ?? 80),
          moderateThreshold: Number(role.moderate_threshold ?? 60),
          lowConfidenceThreshold: Number(role.low_confidence_threshold ?? 0.7),
          criticalSkillPenalty: Number(role.critical_skill_penalty ?? 15),
        },
        skills: skillRows.map((row) => ({
          name: row.skill_name,
          aliases: parseJsonValue(row.aliases_json, []),
          category: row.category || "",
          required: Boolean(row.required),
          weight: Number(row.weight ?? 0),
          isCritical: Boolean(row.is_critical),
        })),
      });
    } catch (err) {
      console.error("[ChangeRequests][reference:kb-detail] error:", err);
      res.status(500).json({ message: "Failed to load KB role reference detail." });
    }
  }
);

router.get("/mine", requireRole("recruiter"), async (req, res) => {
  try {
    const limit = Math.min(Math.max(Number(req.query.limit || 100), 1), 300);
    const [rows] = await db.query(
      `
      SELECT
        cr.*,
        CONCAT(COALESCE(submitter.first_name, ''), ' ', COALESCE(submitter.last_name, '')) AS requester_name,
        submitter.email AS requester_email,
        CONCAT(COALESCE(reviewer.first_name, ''), ' ', COALESCE(reviewer.last_name, '')) AS reviewer_name,
        reviewer.email AS reviewer_email
      FROM change_requests cr
      LEFT JOIN users submitter ON submitter.id = cr.submitted_by
      LEFT JOIN users reviewer ON reviewer.id = cr.reviewed_by
      WHERE cr.submitted_by = ?
      ORDER BY cr.submitted_at DESC, cr.id DESC
      LIMIT ?
      `,
      [req.user.id, limit]
    );

    res.json(rows.map(mapRequestRow));
  } catch (err) {
    console.error("[ChangeRequests][mine] error:", err);
    res.status(500).json({ message: "Failed to load your requests." });
  }
});

router.post("/jobs", requireRole("recruiter"), async (req, res) => {
  try {
    const actionType = cleanString(req.body.actionType || req.body.action, {
      lower: true,
    });
    if (!ALLOWED_ACTIONS.has(actionType)) {
      return res
        .status(400)
        .json({ message: "actionType must be create, update, or delete." });
    }

    const targetId =
      req.body.targetId !== undefined && req.body.targetId !== null
        ? Number(req.body.targetId)
        : null;

    if ((actionType === "update" || actionType === "delete") && !Number.isFinite(targetId)) {
      return res
        .status(400)
        .json({ message: "targetId is required for update and delete requests." });
    }

    const payload = actionType === "delete" ? null : normalizeJobPayload(req.body.payload || {});
    if ((actionType === "create" || actionType === "update") && !payload?.title) {
      return res.status(400).json({ message: "Job title is required." });
    }

    if (actionType === "update" || actionType === "delete") {
      const [rows] = await db.query("SELECT id FROM jobs WHERE id = ? LIMIT 1", [targetId]);
      if (!rows.length) {
        return res.status(404).json({ message: "Target job not found." });
      }
    }

    const summary =
      actionType === "create"
        ? `Requested job create: ${payload.title}`
        : actionType === "update"
        ? `Requested job update #${targetId}: ${payload.title}`
        : `Requested job delete #${targetId}`;

    const requestId = await insertRequest({
      entityType: "job",
      actionType,
      targetId: Number.isFinite(targetId) ? targetId : null,
      payload,
      summary,
      submittedBy: req.user.id,
    });

    await writeAuditLog({
      actorUserId: req.user.id,
      action: "change_request.submit",
      entityType: "change_request",
      entityId: requestId,
      summary,
      metadata: {
        requestId,
        entityType: "job",
        actionType,
      },
    });

    res.status(201).json({
      message: "Job change request submitted for admin approval.",
      requestId,
    });
  } catch (err) {
    console.error("[ChangeRequests][submit:job] error:", err);
    res.status(500).json({ message: "Failed to submit job change request." });
  }
});

router.post(
  "/knowledgebase-roles",
  requireRole("recruiter"),
  async (req, res) => {
    try {
      const actionType = cleanString(req.body.actionType || req.body.action, {
        lower: true,
      });
      if (!ALLOWED_ACTIONS.has(actionType)) {
        return res
          .status(400)
          .json({ message: "actionType must be create, update, or delete." });
      }

      const targetId =
        req.body.targetId !== undefined && req.body.targetId !== null
          ? Number(req.body.targetId)
          : null;

      if ((actionType === "update" || actionType === "delete") && !Number.isFinite(targetId)) {
        return res
          .status(400)
          .json({ message: "targetId is required for update and delete requests." });
      }

      const payload =
        actionType === "delete" ? null : normalizeKbPayload(req.body.payload || {});
      if ((actionType === "create" || actionType === "update") && !payload?.name) {
        return res.status(400).json({ message: "Role name is required." });
      }

      if (actionType === "update" || actionType === "delete") {
        const [rows] = await db.query(
          "SELECT id FROM knowledgebase_roles WHERE id = ? LIMIT 1",
          [targetId]
        );
        if (!rows.length) {
          return res.status(404).json({ message: "Target KB role not found." });
        }
      }

      const summary =
        actionType === "create"
          ? `Requested KB role create: ${payload.name}`
          : actionType === "update"
          ? `Requested KB role update #${targetId}: ${payload.name}`
          : `Requested KB role delete #${targetId}`;

      const requestId = await insertRequest({
        entityType: "kb_role",
        actionType,
        targetId: Number.isFinite(targetId) ? targetId : null,
        payload,
        summary,
        submittedBy: req.user.id,
      });

      await writeAuditLog({
        actorUserId: req.user.id,
        action: "change_request.submit",
        entityType: "change_request",
        entityId: requestId,
        summary,
        metadata: {
          requestId,
          entityType: "kb_role",
          actionType,
        },
      });

      res.status(201).json({
        message: "Knowledge-base change request submitted for admin approval.",
        requestId,
      });
    } catch (err) {
      console.error("[ChangeRequests][submit:kb] error:", err);
      res.status(500).json({ message: "Failed to submit KB change request." });
    }
  }
);

router.post("/applications", requireRole("recruiter"), async (req, res) => {
  try {
    const targetId = resolveApplicationTargetId(req.body?.targetId, req.body);
    if (!Number.isFinite(targetId)) {
      return res.status(400).json({ message: "Valid targetId (application id) is required." });
    }

    const actionType = normalizeApplicationRequestAction(req.body?.actionType || req.body?.action);
    if (!ALLOWED_APPLICATION_REQUEST_ACTIONS.has(actionType)) {
      return res.status(400).json({
        message:
          "actionType must be status_update (or alias: status_change, update_status, undo, correct).",
      });
    }

    const toStatus = cleanString(req.body?.toStatus || req.body?.status, { lower: true });
    if (!ALLOWED_APPLICATION_STATUSES.has(toStatus)) {
      return res.status(400).json({ message: "Invalid target status." });
    }

    const requestedReason = cleanString(req.body?.reason || req.body?.note || req.body?.reviewNote);
    const requestedRejectionReason = cleanString(req.body?.rejectionReason);
    const clearRejectionReason = coerceBoolean(req.body?.clearRejectionReason, true);

    const application = await loadApplicationReference(db, targetId);
    if (!application) {
      return res.status(404).json({ message: "Target application not found." });
    }

    const fromStatus = cleanString(application.status, { lower: true });
    if (fromStatus === toStatus) {
      return res
        .status(400)
        .json({ message: "Target status must be different from the current status." });
    }

    if (toStatus === "rejected") {
      const finalReason = requestedRejectionReason || cleanString(application.rejection_reason);
      if (!finalReason) {
        return res
          .status(400)
          .json({ message: "Rejection reason is required when requesting rejected status." });
      }
    }

    const payload = {
      applicationId: targetId,
      fromStatus,
      toStatus,
      reason: requestedReason || null,
      rejectionReason: requestedRejectionReason || null,
      clearRejectionReason,
    };

    const candidateName = `${cleanString(application.first_name)} ${cleanString(
      application.last_name
    )}`.trim();
    const summary = `Requested application status correction #${targetId}: ${fromStatus} -> ${toStatus} (${candidateName || "Unknown Candidate"})`;

    const requestId = await insertRequest({
      entityType: "application",
      actionType,
      targetId,
      payload,
      summary,
      submittedBy: req.user.id,
    });

    await writeAuditLog({
      actorUserId: req.user.id,
      action: "change_request.submit",
      entityType: "change_request",
      entityId: requestId,
      summary,
      metadata: {
        requestId,
        entityType: "application",
        actionType,
        applicationId: targetId,
        fromStatus,
        toStatus,
      },
    });

    res.status(201).json({
      message: "Application correction request submitted for admin approval.",
      requestId,
    });
  } catch (err) {
    console.error("[ChangeRequests][submit:application] error:", err);
    res.status(500).json({ message: "Failed to submit application correction request." });
  }
});

router.get("/", requireRole("admin"), async (req, res) => {
  try {
    const statusFilter = cleanString(req.query.status || "pending", { lower: true });
    const limit = Math.min(Math.max(Number(req.query.limit || 150), 1), 500);
    const hasStatusFilter = statusFilter && statusFilter !== "all";

    const [rows] = await db.query(
      `
      SELECT
        cr.*,
        CONCAT(COALESCE(submitter.first_name, ''), ' ', COALESCE(submitter.last_name, '')) AS requester_name,
        submitter.email AS requester_email,
        CONCAT(COALESCE(reviewer.first_name, ''), ' ', COALESCE(reviewer.last_name, '')) AS reviewer_name,
        reviewer.email AS reviewer_email
      FROM change_requests cr
      LEFT JOIN users submitter ON submitter.id = cr.submitted_by
      LEFT JOIN users reviewer ON reviewer.id = cr.reviewed_by
      ${hasStatusFilter ? "WHERE cr.status = ?" : ""}
      ORDER BY cr.submitted_at DESC, cr.id DESC
      LIMIT ?
      `,
      hasStatusFilter ? [statusFilter, limit] : [limit]
    );

    res.json(rows.map(mapRequestRow));
  } catch (err) {
    console.error("[ChangeRequests][list] error:", err);
    res.status(500).json({ message: "Failed to load change requests." });
  }
});

router.post("/:id/approve", requireRole("admin"), async (req, res) => {
  const requestId = Number(req.params.id);
  if (!Number.isFinite(requestId)) {
    return res.status(400).json({ message: "Invalid request id." });
  }

  const reviewNote = cleanString(req.body?.reviewNote);
  const connection = await db.getConnection();
  try {
    await connection.beginTransaction();

    const [rows] = await connection.query(
      "SELECT * FROM change_requests WHERE id = ? FOR UPDATE",
      [requestId]
    );
    if (!rows.length) {
      await connection.rollback();
      connection.release();
      return res.status(404).json({ message: "Change request not found." });
    }

    const requestRow = rows[0];
    if (cleanString(requestRow.status, { lower: true }) !== "pending") {
      await connection.rollback();
      connection.release();
      return res
        .status(400)
        .json({ message: "Only pending requests can be approved." });
    }

    const applyResult = await applyRequestByType(connection, requestRow, req.user.id);

    await connection.query(
      `
      UPDATE change_requests
      SET
        status = 'approved',
        reviewed_by = ?,
        reviewed_at = NOW(),
        review_note = ?,
        updated_at = NOW()
      WHERE id = ?
      `,
      [req.user.id, reviewNote || null, requestId]
    );

    await connection.commit();
    connection.release();

    await writeAuditLog({
      actorUserId: req.user.id,
      action: "change_request.approve",
      entityType: "change_request",
      entityId: requestId,
      summary: `Approved ${requestRow.entity_type} ${requestRow.action_type} request #${requestId}`,
      metadata: {
        requestId,
        entityType: requestRow.entity_type,
        actionType: requestRow.action_type,
        appliedEntityType: applyResult.entityType,
        appliedEntityId: applyResult.entityId,
        reviewNote: reviewNote || null,
      },
    });

    res.json({ message: "Change request approved and applied." });
  } catch (err) {
    await connection.rollback();
    connection.release();
    console.error("[ChangeRequests][approve] error:", err);
    res.status(500).json({ message: err.message || "Failed to approve request." });
  }
});

router.post("/:id/reject", requireRole("admin"), async (req, res) => {
  const requestId = Number(req.params.id);
  if (!Number.isFinite(requestId)) {
    return res.status(400).json({ message: "Invalid request id." });
  }

  const reviewNote = cleanString(req.body?.reviewNote);
  if (!reviewNote) {
    return res
      .status(400)
      .json({ message: "Rejection note is required for rejected requests." });
  }

  try {
    const [rows] = await db.query(
      "SELECT id, status, entity_type, action_type FROM change_requests WHERE id = ? LIMIT 1",
      [requestId]
    );
    if (!rows.length) {
      return res.status(404).json({ message: "Change request not found." });
    }
    if (rows[0].status !== "pending") {
      return res
        .status(400)
        .json({ message: "Only pending requests can be rejected." });
    }

    await db.query(
      `
      UPDATE change_requests
      SET
        status = 'rejected',
        reviewed_by = ?,
        reviewed_at = NOW(),
        review_note = ?,
        updated_at = NOW()
      WHERE id = ?
      `,
      [req.user.id, reviewNote, requestId]
    );

    await writeAuditLog({
      actorUserId: req.user.id,
      action: "change_request.reject",
      entityType: "change_request",
      entityId: requestId,
      summary: `Rejected ${rows[0].entity_type} ${rows[0].action_type} request #${requestId}`,
      metadata: {
        requestId,
        entityType: rows[0].entity_type,
        actionType: rows[0].action_type,
        reviewNote,
      },
    });

    res.json({ message: "Change request rejected." });
  } catch (err) {
    console.error("[ChangeRequests][reject] error:", err);
    res.status(500).json({ message: "Failed to reject request." });
  }
});

export default router;
