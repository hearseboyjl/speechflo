import express from "express";
import { db } from "../db.js";
import { authMiddleware } from "./authMiddleware.js";

const router = express.Router();

// GET email by user ID
router.get("/:userId", authMiddleware, async (req, res) => {
  try {
    const { userId } = req.params;


    const [rows] = await db.query(
      "SELECT email FROM users WHERE id = ?",
      [userId]
    );

    if (rows.length === 0) {
      return res.status(404).json({ message: "User not found" });
    }

    res.json({ email: rows[0].email });
  } catch (err) {
    console.error("Error fetching email:", err);
    res.status(500).json({ message: "Server error", error: err.message });
  }
});

export default router;
