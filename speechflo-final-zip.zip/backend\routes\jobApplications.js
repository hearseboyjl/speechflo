import express from 'express';
import { db } from '../db.js'; // your existing db.js
import { authMiddleware, requireRole } from './authMiddleware.js';
import { writeAuditLog } from "../utils/auditLog.js";
import { appendApplicationStatusEvent } from "../utils/applicationTimeline.js";

const router = express.Router();
router.use(authMiddleware);
router.use(requireRole("recruiter", "admin"));
const ALLOWED_APPLICATION_STATUSES = new Set(["submitted", "processing", "completed", "endorsed", "rejected"]);

// GET all job applications
router.get('/', async (req, res) => {
  try {
    let rows;
    try {
      const [withNotesRows] = await db.query(`
        SELECT
               ja.id,
               CASE
                 WHEN ja.resume_path IS NULL OR ja.resume_path = '' OR ja.resume_path LIKE '%test_resume.pdf'
                   THEN p.resume_path
                 ELSE ja.resume_path
               END AS resume_path,
               ja.status,
               ja.rejection_reason,
               ja.assigned_recruiter_id,
               ja.assigned_at,
               ja.applied_at,
               COALESCE(notes.note_count, 0) AS note_count,
               notes.last_note_at,
               COALESCE(int_comments.comment_count, 0) AS internal_comment_count,
               COALESCE(handoffs.handoff_count, 0) AS handoff_count,
               CONCAT(COALESCE(assignee.first_name, ''), ' ', COALESCE(assignee.last_name, '')) AS assigned_recruiter_name,
               assignee.email AS assigned_recruiter_email,
               u.id AS applicantId,
               u.first_name AS firstName, u.last_name AS lastName, j.title AS role
        FROM job_applications AS ja
        JOIN users AS u ON ja.user_id = u.id
        JOIN jobs AS j ON ja.job_id = j.id
        LEFT JOIN profiles AS p ON p.user_id = ja.user_id
        LEFT JOIN users AS assignee ON assignee.id = ja.assigned_recruiter_id
        LEFT JOIN (
          SELECT application_id, COUNT(*) AS note_count, MAX(created_at) AS last_note_at
          FROM application_case_notes
          GROUP BY application_id
        ) notes ON notes.application_id = ja.id
        LEFT JOIN (
          SELECT application_id, COUNT(*) AS comment_count
          FROM application_internal_comments
          GROUP BY application_id
        ) int_comments ON int_comments.application_id = ja.id
        LEFT JOIN (
          SELECT application_id, COUNT(*) AS handoff_count
          FROM application_handoff_history
          GROUP BY application_id
        ) handoffs ON handoffs.application_id = ja.id
        ORDER BY ja.applied_at DESC
      `);
      rows = withNotesRows;
    } catch (err) {
      if (err?.code !== "ER_NO_SUCH_TABLE" && err?.code !== "ER_BAD_FIELD_ERROR") throw err;
      const [fallbackRows] = await db.query(`
        SELECT
               ja.id,
               CASE
                 WHEN ja.resume_path IS NULL OR ja.resume_path = '' OR ja.resume_path LIKE '%test_resume.pdf'
                   THEN p.resume_path
                 ELSE ja.resume_path
               END AS resume_path,
               ja.status,
               ja.rejection_reason,
               ja.applied_at,
               u.id AS applicantId,
               u.first_name AS firstName, u.last_name AS lastName, j.title AS role
        FROM job_applications AS ja
        JOIN users AS u ON ja.user_id = u.id
        JOIN jobs AS j ON ja.job_id = j.id
        LEFT JOIN profiles AS p ON p.user_id = ja.user_id
        ORDER BY ja.applied_at DESC
      `);
      rows = fallbackRows.map((item) => ({
        ...item,
        note_count: 0,
        last_note_at: null,
        assigned_recruiter_id: null,
        assigned_at: null,
        internal_comment_count: 0,
        handoff_count: 0,
        assigned_recruiter_name: "",
        assigned_recruiter_email: "",
      }));
    }

    const data = rows.map(r => ({
      id: r.id,  //application id
      applicantId: r.applicantId, //applicant id
      file: r.resume_path ? r.resume_path.split("/").pop() : "No file",
      candidate: `${r.firstName} ${r.lastName}`,
      role: r.role,
      status: r.status,
      rejection_reason: r.rejection_reason || "",
      applied_at : r.applied_at,
      note_count: Number(r.note_count || 0),
      last_note_at: r.last_note_at || null,
      assigned_recruiter_id: r.assigned_recruiter_id || null,
      assigned_recruiter_name: String(r.assigned_recruiter_name || "").trim(),
      assigned_recruiter_email: r.assigned_recruiter_email || "",
      assigned_at: r.assigned_at || null,
      internal_comment_count: Number(r.internal_comment_count || 0),
      handoff_count: Number(r.handoff_count || 0),
    }));



    res.json(data); 

  } catch (err) {
    console.error("Error fetching job applications:", err);
    res.status(500).json({ error: "Failed to fetch job applications" });
  }
});

// GET all completed/endorsed job applications
router.get("/completed", async (req, res) => {
  try {
    const [rows] = await db.query(`
      SELECT 
        ja.id AS applicationId,
        CASE
          WHEN ja.resume_path IS NULL OR ja.resume_path = '' OR ja.resume_path LIKE '%test_resume.pdf'
            THEN p.resume_path
          ELSE ja.resume_path
        END AS resume_path,
        ja.status,
        ja.applied_at,
        u.id AS applicantId,
        u.first_name AS firstName,
        u.last_name AS lastName,
        j.title AS role
      FROM job_applications AS ja
      JOIN users AS u ON ja.user_id = u.id
      JOIN jobs AS j ON ja.job_id = j.id
      LEFT JOIN profiles AS p ON p.user_id = ja.user_id
      WHERE ja.status IN ('completed', 'endorsed')
      ORDER BY ja.applied_at DESC
    `);

    const data = rows.map(r => ({
      id: r.applicationId,
      applicantId: r.applicantId,
      candidate: `${r.firstName} ${r.lastName}`,
      role: r.role,
      file: r.resume_path ? r.resume_path.split("/").pop() : "No file",
      status: r.status,
      applied_at: r.applied_at
    }));

    res.json(data);

  } catch (err) {
    console.error("Error fetching completed job applications:", err);
    res.status(500).json({ error: "Failed to fetch completed job applications" });
  }
});

//get all roles/jobs
router.get("/jobs", async (req, res) => {
  try {
    const [jobs] = await db.query(`
      SELECT id, title, company_name, employment_type, work_setup, city, region
      FROM jobs
      WHERE is_active = 1
      ORDER BY created_at DESC
    `);

    res.json(jobs);
  } catch (err) {
    console.error("Error fetching jobs:", err);
    res.status(500).json({ error: "Failed to fetch jobs" });
  }
});

router.get("/recruiters", async (_req, res) => {
  try {
    const [rows] = await db.query(
      `
      SELECT
        id,
        first_name,
        last_name,
        email,
        role
      FROM users
      WHERE is_active = 1
        AND role IN ('recruiter', 'admin')
      ORDER BY
        FIELD(role, 'recruiter', 'admin'),
        first_name ASC,
        last_name ASC
      `
    );

    res.json(
      rows.map((row) => ({
        id: row.id,
        firstName: row.first_name || "",
        lastName: row.last_name || "",
        fullName: `${row.first_name || ""} ${row.last_name || ""}`.trim() || row.email,
        email: row.email,
        role: row.role,
      }))
    );
  } catch (err) {
    console.error("Error fetching recruiters:", err);
    res.status(500).json({ error: "Failed to fetch recruiters" });
  }
});

router.patch("/:id/assignment", async (req, res) => {
  const applicationId = Number(req.params.id);
  if (!Number.isFinite(applicationId)) {
    return res.status(400).json({ error: "Invalid application ID" });
  }

  const assignedRecruiterIdRaw = req.body?.assignedRecruiterId;
  const assignedRecruiterId =
    assignedRecruiterIdRaw === null || assignedRecruiterIdRaw === "" || assignedRecruiterIdRaw === undefined
      ? null
      : Number(assignedRecruiterIdRaw);
  if (assignedRecruiterId !== null && !Number.isFinite(assignedRecruiterId)) {
    return res.status(400).json({ error: "Invalid assignee ID" });
  }
  const note = String(req.body?.note || "").trim();

  const connection = await db.getConnection();
  try {
    await connection.beginTransaction();

    const [appRows] = await connection.query(
      `
      SELECT
        id,
        assigned_recruiter_id
      FROM job_applications
      WHERE id = ?
      LIMIT 1
      FOR UPDATE
      `,
      [applicationId]
    );
    if (!appRows.length) {
      await connection.rollback();
      connection.release();
      return res.status(404).json({ error: "Application not found" });
    }

    if (assignedRecruiterId !== null) {
      const [userRows] = await connection.query(
        "SELECT id FROM users WHERE id = ? AND role IN ('recruiter', 'admin') LIMIT 1",
        [assignedRecruiterId]
      );
      if (!userRows.length) {
        await connection.rollback();
        connection.release();
        return res.status(404).json({ error: "Assignee not found" });
      }
    }

    const previousAssignee = appRows[0].assigned_recruiter_id || null;
    await connection.query(
      `
      UPDATE job_applications
      SET
        assigned_recruiter_id = ?,
        assigned_at = ?,
        updated_at = NOW()
      WHERE id = ?
      `,
      [assignedRecruiterId, assignedRecruiterId ? new Date() : null, applicationId]
    );

    if (previousAssignee !== assignedRecruiterId) {
      await connection.query(
        `
        INSERT INTO application_handoff_history (
          application_id,
          from_recruiter_id,
          to_recruiter_id,
          note,
          created_by
        ) VALUES (?, ?, ?, ?, ?)
        `,
        [applicationId, previousAssignee, assignedRecruiterId, note || null, req.user.id || null]
      );
    }

    await connection.commit();
    connection.release();

    await writeAuditLog({
      actorUserId: req.user.id,
      action: "application.assignment_update",
      entityType: "application",
      entityId: applicationId,
      summary: `Updated assignment for application ${applicationId}`,
      metadata: {
        fromRecruiterId: previousAssignee,
        toRecruiterId: assignedRecruiterId,
        note: note || null,
      },
    });

    res.json({ message: "Assignment updated successfully." });
  } catch (err) {
    await connection.rollback();
    connection.release();
    console.error("Error updating assignment:", err);
    res.status(500).json({ error: "Failed to update assignment" });
  }
});

router.get("/:id/internal-comments", async (req, res) => {
  const applicationId = Number(req.params.id);
  if (!Number.isFinite(applicationId)) {
    return res.status(400).json({ error: "Invalid application ID" });
  }

  try {
    const [rows] = await db.query(
      `
      SELECT
        c.id,
        c.comment,
        c.created_by,
        c.created_at,
        CONCAT(COALESCE(u.first_name, ''), ' ', COALESCE(u.last_name, '')) AS author_name,
        u.role AS author_role
      FROM application_internal_comments c
      LEFT JOIN users u ON u.id = c.created_by
      WHERE c.application_id = ?
      ORDER BY c.created_at DESC, c.id DESC
      `,
      [applicationId]
    );

    res.json(
      rows.map((row) => ({
        id: row.id,
        comment: row.comment,
        createdBy: row.created_by,
        createdAt: row.created_at,
        authorName: String(row.author_name || "").trim(),
        authorRole: row.author_role || "",
      }))
    );
  } catch (err) {
    if (err?.code === "ER_NO_SUCH_TABLE") return res.json([]);
    console.error("Error loading internal comments:", err);
    res.status(500).json({ error: "Failed to load internal comments" });
  }
});

router.post("/:id/internal-comments", async (req, res) => {
  const applicationId = Number(req.params.id);
  if (!Number.isFinite(applicationId)) {
    return res.status(400).json({ error: "Invalid application ID" });
  }
  const comment = String(req.body?.comment || "").trim();
  if (!comment) {
    return res.status(400).json({ error: "Comment is required" });
  }

  try {
    const [appRows] = await db.query("SELECT id FROM job_applications WHERE id = ? LIMIT 1", [applicationId]);
    if (!appRows.length) {
      return res.status(404).json({ error: "Application not found" });
    }

    const [result] = await db.query(
      `
      INSERT INTO application_internal_comments (application_id, comment, created_by)
      VALUES (?, ?, ?)
      `,
      [applicationId, comment, req.user.id || null]
    );

    await writeAuditLog({
      actorUserId: req.user.id,
      action: "application.internal_comment_create",
      entityType: "application",
      entityId: applicationId,
      summary: `Added internal comment to application ${applicationId}`,
      metadata: { commentId: result.insertId },
    });

    res.status(201).json({ message: "Internal comment added.", commentId: result.insertId });
  } catch (err) {
    if (err?.code === "ER_NO_SUCH_TABLE") {
      return res.status(500).json({ error: "Collaboration table not ready. Run latest migration first." });
    }
    console.error("Error adding internal comment:", err);
    res.status(500).json({ error: "Failed to add internal comment" });
  }
});

router.get("/:id/handoffs", async (req, res) => {
  const applicationId = Number(req.params.id);
  if (!Number.isFinite(applicationId)) {
    return res.status(400).json({ error: "Invalid application ID" });
  }

  try {
    const [rows] = await db.query(
      `
      SELECT
        h.id,
        h.application_id,
        h.from_recruiter_id,
        h.to_recruiter_id,
        h.note,
        h.created_by,
        h.created_at,
        CONCAT(COALESCE(fr.first_name, ''), ' ', COALESCE(fr.last_name, '')) AS from_name,
        CONCAT(COALESCE(tr.first_name, ''), ' ', COALESCE(tr.last_name, '')) AS to_name,
        CONCAT(COALESCE(cb.first_name, ''), ' ', COALESCE(cb.last_name, '')) AS created_by_name
      FROM application_handoff_history h
      LEFT JOIN users fr ON fr.id = h.from_recruiter_id
      LEFT JOIN users tr ON tr.id = h.to_recruiter_id
      LEFT JOIN users cb ON cb.id = h.created_by
      WHERE h.application_id = ?
      ORDER BY h.created_at DESC, h.id DESC
      `,
      [applicationId]
    );

    res.json(
      rows.map((row) => ({
        id: row.id,
        applicationId: row.application_id,
        fromRecruiterId: row.from_recruiter_id,
        toRecruiterId: row.to_recruiter_id,
        fromName: String(row.from_name || "").trim(),
        toName: String(row.to_name || "").trim(),
        createdBy: row.created_by,
        createdByName: String(row.created_by_name || "").trim(),
        note: row.note || "",
        createdAt: row.created_at,
      }))
    );
  } catch (err) {
    if (err?.code === "ER_NO_SUCH_TABLE") return res.json([]);
    console.error("Error loading handoff history:", err);
    res.status(500).json({ error: "Failed to load handoff history" });
  }
});

router.get("/:id/notes", async (req, res) => {
  const applicationId = Number(req.params.id);
  if (!Number.isFinite(applicationId)) {
    return res.status(400).json({ error: "Invalid application ID" });
  }

  try {
    const [appRows] = await db.query(
      "SELECT id FROM job_applications WHERE id = ? LIMIT 1",
      [applicationId]
    );
    if (!appRows.length) {
      return res.status(404).json({ error: "Application not found" });
    }

    const [rows] = await db.query(
      `
      SELECT
        n.id,
        n.note,
        n.created_by,
        n.created_at,
        CONCAT(COALESCE(u.first_name, ''), ' ', COALESCE(u.last_name, '')) AS author_name,
        u.role AS author_role
      FROM application_case_notes n
      LEFT JOIN users u ON u.id = n.created_by
      WHERE n.application_id = ?
      ORDER BY n.created_at DESC, n.id DESC
      `,
      [applicationId]
    );

    res.json(
      rows.map((row) => ({
        id: row.id,
        note: row.note,
        createdBy: row.created_by,
        createdAt: row.created_at,
        authorName: String(row.author_name || "").trim(),
        authorRole: row.author_role || "",
      }))
    );
  } catch (err) {
    if (err?.code === "ER_NO_SUCH_TABLE") {
      return res.json([]);
    }
    console.error("Error fetching case notes:", err);
    res.status(500).json({ error: "Failed to fetch case notes" });
  }
});

router.post("/:id/notes", async (req, res) => {
  const applicationId = Number(req.params.id);
  if (!Number.isFinite(applicationId)) {
    return res.status(400).json({ error: "Invalid application ID" });
  }

  const note = String(req.body?.note || "").trim();
  if (!note) {
    return res.status(400).json({ error: "Note is required" });
  }

  try {
    const [appRows] = await db.query(
      "SELECT id FROM job_applications WHERE id = ? LIMIT 1",
      [applicationId]
    );
    if (!appRows.length) {
      return res.status(404).json({ error: "Application not found" });
    }

    const [result] = await db.query(
      `
      INSERT INTO application_case_notes (application_id, note, created_by)
      VALUES (?, ?, ?)
      `,
      [applicationId, note, req.user.id || null]
    );

    await writeAuditLog({
      actorUserId: req.user.id,
      action: "application.note_create",
      entityType: "application",
      entityId: applicationId,
      summary: `Added case note to application ${applicationId}`,
      metadata: { noteId: result.insertId },
    });

    res.status(201).json({
      message: "Case note added.",
      noteId: result.insertId,
    });
  } catch (err) {
    if (err?.code === "ER_NO_SUCH_TABLE") {
      return res.status(500).json({ error: "Case notes table not ready. Run latest migration first." });
    }
    console.error("Error creating case note:", err);
    res.status(500).json({ error: "Failed to create case note" });
  }
});

// Download applicant resume for a specific application (recruiter/admin only)
router.get("/:id/resume", async (req, res) => {
  const { id } = req.params;
  try {
    const [rows] = await db.query(
      `
      SELECT arf.file_name, arf.mime_type, arf.file_data
      FROM job_applications ja
      JOIN applicant_resume_files arf ON arf.user_id = ja.user_id
      WHERE ja.id = ?
      LIMIT 1
      `,
      [id]
    );

    if (!rows.length) {
      return res.status(404).json({ error: "Resume not found for this application" });
    }

    const resume = rows[0];
    await writeAuditLog({
      actorUserId: req.user.id,
      action: "resume.download",
      entityType: "application",
      entityId: id,
      summary: `Downloaded resume for application ${id}`,
    });

    res.setHeader("Content-Type", resume.mime_type || "application/octet-stream");
    res.setHeader(
      "Content-Disposition",
      `attachment; filename="${String(resume.file_name || "resume").replace(/"/g, "")}"`
    );
    return res.send(resume.file_data);
  } catch (err) {
    console.error("Failed to fetch resume:", err);
    return res.status(500).json({ error: "Failed to fetch resume" });
  }
});


//change application status once button is clicked
router.patch("/:id/status", async (req, res) => {
  const { id } = req.params;
  const { status } = req.body;

  try {
    const [currentRows] = await db.query(
      "SELECT status FROM job_applications WHERE id = ? LIMIT 1",
      [id]
    );

    if (!currentRows.length) {
      return res.status(404).json({ error: "Application not found" });
    }

    const currentStatus = String(currentRows[0].status || "").trim().toLowerCase();
    const nextStatus = String(status || "").trim().toLowerCase();
    if (!nextStatus) {
      return res.status(400).json({ error: "Status is required" });
    }
    if (!ALLOWED_APPLICATION_STATUSES.has(nextStatus)) {
      return res.status(400).json({ error: "Invalid status value" });
    }

    const [result] = await db.query(
      `UPDATE job_applications SET status = ? WHERE id = ?`,
      [nextStatus, id]
    );

    if (result.affectedRows === 0) {
      return res.status(404).json({ error: "Application not found" });
    }

    if (currentStatus !== nextStatus) {
      await appendApplicationStatusEvent(db, {
        applicationId: id,
        status: nextStatus,
        note: `Application moved to ${nextStatus}.`,
        changedBy: req.user.id,
      });
    }

    await writeAuditLog({
      actorUserId: req.user.id,
      action: "application.status_update",
      entityType: "application",
      entityId: id,
      summary: `Updated application ${id} status to ${nextStatus}`,
      metadata: { status: nextStatus },
    });

    res.json({ success: true, id, status: nextStatus });
  } catch (err) {
    console.error("Failed to update status:", err);
    res.status(500).json({ error: "Failed to update status" });
  }
});


export default router;
