import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { apiUrl } from "../api";
import { clearSession, getToken, storeSession } from "../session";

export default function RecruiterLogin() {
  const navigate = useNavigate();

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    const token = getToken();
    if (token) {
      navigate("/recruiter/dashboard");
    }
  }, [navigate]);

  async function handleLogin(e) {
    e.preventDefault();
    setError("");
    setLoading(true);

    try {
      const res = await fetch(apiUrl("/auth/recruiter/login"), {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ email, password }),
      });

      const data = await res.json();

      if (!res.ok) {
        setError(data.message || "Login failed");
        setLoading(false);
        return;
      }

      clearSession();
      storeSession(data);
      navigate("/recruiter/dashboard");
    } catch (err) {
      console.error(err);
      setError("Something went wrong. Please try again.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="min-h-screen w-full relative overflow-hidden">
      <div
        className="absolute inset-0"
        style={{
          backgroundImage:
            "url('https://images.unsplash.com/photo-1521737604893-d14cc237f11d')",
          backgroundSize: "cover",
          backgroundPosition: "center",
        }}
      />

      <div className="absolute inset-0 bg-gradient-to-br from-[#002853]/35 via-[#2F8DCD]/10 to-white/15" />

      <div className="relative z-10 min-h-screen">
        <div className="mx-auto max-w-[1200px] min-h-screen p-6 md:p-10 flex items-center">
          <div className="w-full grid grid-cols-1 lg:grid-cols-2 gap-10 items-center">
            <div className="text-white max-w-lg mx-auto lg:mx-0 lg:ml-16">
              <button
                onClick={() => navigate("/")}
                className="inline-flex items-center text-white/90 hover:text-white text-2xl font-semibold tracking-wide"
              >
                SpeechFlo
              </button>

              <h1 className="mt-14 text-4xl md:text-5xl font-bold leading-tight">
                Recruit smarter.
                <br />
                Interview better.
              </h1>

              <p className="mt-5 text-sm md:text-base text-white/80">
                Student-built interview assistant for organizing uploads, AI analysis, and reports.
              </p>

              <div className="mt-10 text-xs text-white/60">(c) 2026 SpeechFlo</div>
            </div>

            <div className="lg:flex lg:justify-end">
              <div className="w-full lg:w-[520px] rounded-[28px] bg-white/75 backdrop-blur-xl shadow-2xl border border-white/50 p-8 sm:p-10">
                <div className="text-center">
                  <h2 className="text-3xl font-bold text-[#002853]">Welcome back</h2>
                  <p className="mt-2 text-sm text-slate-600">Sign in to continue</p>
                </div>

                <form onSubmit={handleLogin} className="mt-8">
                  {error && (
                    <div className="mb-4 text-sm text-red-600 text-center">{error}</div>
                  )}

                  <div>
                    <label className="block text-sm font-semibold text-slate-700">Email</label>
                    <input
                      type="email"
                      required
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="you@company.com"
                      className="mt-2 w-full h-11 px-4 rounded-xl bg-white/90 border border-slate-200 shadow-sm outline-none focus:ring-2 focus:ring-[#2F8DCD]/30"
                    />
                  </div>

                  <div className="mt-6">
                    <label className="block text-sm font-semibold text-slate-700">Password</label>
                    <input
                      type="password"
                      required
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder="Enter password"
                      className="mt-2 w-full h-11 px-4 rounded-xl bg-white/90 border border-slate-200 shadow-sm outline-none focus:ring-2 focus:ring-[#2F8DCD]/30"
                    />

                    <div className="mt-2 flex justify-end">
                      <button
                        type="button"
                        className="text-sm text-[#2F8DCD] hover:underline"
                        onClick={() => navigate("/reset_password")}
                      >
                        Forgot password?
                      </button>
                    </div>
                  </div>

                  <div className="mt-8">
                    <button
                      type="submit"
                      disabled={loading}
                      className="h-11 px-10 rounded-xl bg-[#2F8DCD] text-white font-semibold hover:brightness-95 transition-all disabled:opacity-60"
                    >
                      {loading ? "Logging in..." : "Login"}
                    </button>
                    <div className="mt-4 text-sm text-slate-600">
                      No account?{" "}
                      <button
                        type="button"
                        onClick={() => navigate("/signup")}
                        className="font-semibold text-[#2F8DCD] hover:underline"
                      >
                        Create one
                      </button>
                    </div>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
