import { useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import Menubar from "../components/Menubar";
import { apiUrl } from "../api";
import { authHeaders, clearSession, getToken } from "../session";

function statusBadge(status = "") {
  if (status === "approved") return "bg-emerald-100 text-emerald-800 border-emerald-200";
  if (status === "rejected") return "bg-rose-100 text-rose-800 border-rose-200";
  return "bg-amber-100 text-amber-800 border-amber-200";
}

function emptySkill() {
  return {
    name: "",
    category: "",
    required: true,
    weight: 1,
  };
}

function sanitizeSkills(skills = []) {
  return (Array.isArray(skills) ? skills : [])
    .map((skill) => ({
      name: String(skill?.name || "").trim(),
      category: String(skill?.category || "").trim(),
      required: Boolean(skill?.required),
      weight: Number(skill?.weight ?? 0),
    }))
    .filter((skill) => skill.name);
}

function mapJobToForm(job = {}) {
  return {
    title: job.title || "",
    companyName: job.companyName || "",
    description: job.description || "",
    employmentType: job.employmentType || "",
    workSetup: job.workSetup || "",
    city: job.city || "",
    region: job.region || "",
    isActive: Boolean(job.isActive),
  };
}

function statusLabel(value = "") {
  const key = String(value || "").trim().toLowerCase();
  if (!key) return "Unknown";
  return key.charAt(0).toUpperCase() + key.slice(1);
}

export default function ChangeRequests() {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [notice, setNotice] = useState("");
  const [userName, setUserName] = useState("User");
  const [activeEntity, setActiveEntity] = useState("job");
  const [jobRefs, setJobRefs] = useState([]);
  const [applicationRefs, setApplicationRefs] = useState([]);
  const [requests, setRequests] = useState([]);

  const [jobForm, setJobForm] = useState({
    actionType: "create",
    targetId: "",
    title: "",
    companyName: "",
    description: "",
    employmentType: "",
    workSetup: "",
    city: "",
    region: "",
    isActive: true,
  });

  const [skillForm, setSkillForm] = useState({
    targetId: "",
    title: "",
    companyName: "",
    description: "",
    employmentType: "",
    workSetup: "",
    city: "",
    region: "",
    isActive: true,
    skills: [emptySkill()],
  });

  const [applicationForm, setApplicationForm] = useState({
    targetId: "",
    fromStatus: "",
    toStatus: "processing",
    reason: "",
    rejectionReason: "",
    clearRejectionReason: true,
  });

  async function readApiResponse(res) {
    const text = await res.text();
    if (!text) return null;
    try {
      return JSON.parse(text);
    } catch {
      return { message: text };
    }
  }

  async function fetchJson(path, options = {}) {
    const res = await fetch(apiUrl(path), {
      ...options,
      headers: authHeaders(options.headers || {}),
    });
    const data = await readApiResponse(res);
    if (!res.ok) {
      throw new Error(data?.message || data?.error || `Request failed (${res.status})`);
    }
    return data;
  }

  async function refreshAll() {
    const [nextJobs, nextApplications, nextRequests] = await Promise.all([
      fetchJson("/change-requests/reference/jobs"),
      fetchJson("/change-requests/reference/applications?limit=500"),
      fetchJson("/change-requests/mine?limit=200"),
    ]);
    setJobRefs(nextJobs || []);
    setApplicationRefs(nextApplications || []);
    setRequests(nextRequests || []);
  }

  useEffect(() => {
    const token = getToken();
    if (!token) {
      navigate("/recruiter/login", { replace: true });
      return;
    }

    let alive = true;
    const boot = async () => {
      try {
        const me = await fetchJson("/auth/me");
        if (!alive) return;
        if (me.role !== "recruiter") {
          clearSession();
          navigate("/recruiter/login", { replace: true });
          return;
        }
        setUserName(me.firstName || "User");
        await refreshAll();
      } catch {
        if (alive) {
          clearSession();
          navigate("/recruiter/login", { replace: true });
        }
      } finally {
        if (alive) setLoading(false);
      }
    };

    boot();
    return () => {
      alive = false;
    };
  }, [navigate]);

  useEffect(() => {
    if (!notice) return undefined;
    const timer = window.setTimeout(() => setNotice(""), 3500);
    return () => window.clearTimeout(timer);
  }, [notice]);

  useEffect(() => {
    let alive = true;

    const loadJobDetail = async () => {
      if (jobForm.actionType === "create" || !jobForm.targetId) {
        return;
      }

      try {
        const detail = await fetchJson(`/change-requests/reference/jobs/${jobForm.targetId}`);
        if (!alive) return;
        const mapped = mapJobToForm(detail);
        setJobForm((prev) => ({
          ...prev,
          ...mapped,
        }));
      } catch (err) {
        if (alive) setNotice(err.message);
      }
    };

    loadJobDetail();
    return () => {
      alive = false;
    };
  }, [jobForm.actionType, jobForm.targetId]);

  useEffect(() => {
    let alive = true;

    const loadSkillsJob = async () => {
      if (!skillForm.targetId) {
        return;
      }

      try {
        const detail = await fetchJson(`/change-requests/reference/jobs/${skillForm.targetId}`);
        if (!alive) return;
        setSkillForm((prev) => ({
          ...prev,
          ...mapJobToForm(detail),
          skills: (detail.skills || []).length
            ? detail.skills.map((skill) => ({
                name: skill.name || "",
                category: skill.category || "",
                required: Boolean(skill.required),
                weight: Number(skill.weight ?? 0),
              }))
            : [emptySkill()],
        }));
      } catch (err) {
        if (alive) setNotice(err.message);
      }
    };

    loadSkillsJob();
    return () => {
      alive = false;
    };
  }, [skillForm.targetId]);

  const selectedApplication = useMemo(() => {
    if (!applicationForm.targetId) return null;
    return (
      applicationRefs.find(
        (item) => String(item.id) === String(applicationForm.targetId)
      ) || null
    );
  }, [applicationForm.targetId, applicationRefs]);

  useEffect(() => {
    if (!selectedApplication) {
      setApplicationForm((prev) => ({
        ...prev,
        fromStatus: "",
        toStatus: "processing",
        reason: "",
        rejectionReason: "",
        clearRejectionReason: true,
      }));
      return;
    }

    const currentStatus = String(selectedApplication.status || "").toLowerCase();
    setApplicationForm((prev) => ({
      ...prev,
      fromStatus: currentStatus,
      toStatus: currentStatus || "processing",
      reason: "",
      rejectionReason: selectedApplication.rejectionReason || "",
      clearRejectionReason: currentStatus === "rejected",
    }));
  }, [selectedApplication]);

  const sortedRequests = useMemo(
    () =>
      [...requests].sort(
        (a, b) => new Date(b.submittedAt || 0).getTime() - new Date(a.submittedAt || 0).getTime()
      ),
    [requests]
  );

  const inputCls =
    "h-10 w-full rounded-xl bg-surface-strong border border-token px-4 text-sm text-main outline-none focus:ring-2 focus:ring-[#2F8DCD]/30";
  const textareaCls =
    "w-full rounded-xl bg-surface-strong border border-token px-4 py-3 text-sm text-main outline-none focus:ring-2 focus:ring-[#2F8DCD]/30";
  const cardCls =
    "rounded-2xl bg-surface backdrop-blur-md border border-token shadow-[0_12px_30px_rgba(15,23,42,0.08)]";
  const btnPrimary =
    "h-10 px-5 rounded-xl bg-btn-primary text-white font-semibold shadow-[0_8px_20px_rgba(15,23,42,0.15)] hover:brightness-95 transition";

  const submitJobRequest = async (e) => {
    e.preventDefault();
    setSaving(true);
    try {
      const body = {
        actionType: jobForm.actionType,
        targetId: jobForm.actionType === "create" ? undefined : Number(jobForm.targetId),
        payload:
          jobForm.actionType === "delete"
            ? undefined
            : {
                title: jobForm.title,
                companyName: jobForm.companyName,
                description: jobForm.description,
                employmentType: jobForm.employmentType,
                workSetup: jobForm.workSetup,
                city: jobForm.city,
                region: jobForm.region,
                isActive: Boolean(jobForm.isActive),
              },
      };
      const data = await fetchJson("/change-requests/jobs", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });
      setNotice(data.message || "Job request submitted.");
      await refreshAll();
    } catch (err) {
      setNotice(err.message);
    } finally {
      setSaving(false);
    }
  };

  const submitSkillsRequest = async (e) => {
    e.preventDefault();
    if (!skillForm.targetId) {
      setNotice("Select a job first.");
      return;
    }

    setSaving(true);
    try {
      const body = {
        actionType: "update",
        targetId: Number(skillForm.targetId),
        payload: {
          title: skillForm.title,
          companyName: skillForm.companyName,
          description: skillForm.description,
          employmentType: skillForm.employmentType,
          workSetup: skillForm.workSetup,
          city: skillForm.city,
          region: skillForm.region,
          isActive: Boolean(skillForm.isActive),
          skills: sanitizeSkills(skillForm.skills),
        },
      };

      const data = await fetchJson("/change-requests/jobs", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });

      setNotice(data.message || "Skills update request submitted.");
      await refreshAll();
    } catch (err) {
      setNotice(err.message);
    } finally {
      setSaving(false);
    }
  };

  const submitApplicationCorrectionRequest = async (e) => {
    e.preventDefault();
    if (!applicationForm.targetId) {
      setNotice("Select an application first.");
      return;
    }
    if (!applicationForm.toStatus) {
      setNotice("Target status is required.");
      return;
    }
    if (
      String(applicationForm.toStatus).toLowerCase() === "rejected" &&
      !String(applicationForm.rejectionReason || "").trim()
    ) {
      setNotice("Rejection reason is required when moving to rejected.");
      return;
    }

    setSaving(true);
    try {
      const body = {
        actionType: "status_update",
        targetId: Number(applicationForm.targetId),
        fromStatus: String(applicationForm.fromStatus || "").toLowerCase(),
        toStatus: String(applicationForm.toStatus || "").toLowerCase(),
        reason: applicationForm.reason,
        rejectionReason:
          String(applicationForm.toStatus || "").toLowerCase() === "rejected"
            ? applicationForm.rejectionReason
            : undefined,
        clearRejectionReason:
          String(applicationForm.toStatus || "").toLowerCase() === "rejected"
            ? false
            : Boolean(applicationForm.clearRejectionReason),
      };

      const data = await fetchJson("/change-requests/applications", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });

      setNotice(data.message || "Application correction request submitted.");
      setApplicationForm((prev) => ({
        ...prev,
        reason: "",
        rejectionReason: "",
        clearRejectionReason: true,
      }));
      await refreshAll();
    } catch (err) {
      setNotice(err.message);
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <div className="grid min-h-screen place-items-center bg-app">
        <div className="rounded-3xl border border-token bg-surface px-8 py-6 shadow-soft">
          Loading request workspace...
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen w-full bg-app">
      <Menubar userName={userName} />
      <main className="min-h-screen bg-app layout-main">
        <div className="max-w-[1280px] mx-auto px-8 py-8 space-y-6">
          <div>
            <h1 className="text-4xl font-bold text-title">Requests</h1>
            <p className="mt-2 text-sm text-muted">Recruiters submit requests; admins approve before anything goes live.</p>
          </div>

          {notice ? <div className={`${cardCls} px-4 py-3 text-sm text-main`}>{notice}</div> : null}

          <section className={`${cardCls} p-5`}>
            <div className="flex flex-wrap gap-2">
              <button
                type="button"
                onClick={() => setActiveEntity("job")}
                className={`rounded-xl px-4 py-2 text-sm font-semibold ${activeEntity === "job" ? "bg-[#0b1f3b] text-white" : "bg-surface-strong text-main border border-token"}`}
              >
                Job Entry
              </button>
              <button
                type="button"
                onClick={() => setActiveEntity("skills")}
                className={`rounded-xl px-4 py-2 text-sm font-semibold ${activeEntity === "skills" ? "bg-[#0b1f3b] text-white" : "bg-surface-strong text-main border border-token"}`}
              >
                Job Skills
              </button>
              <button
                type="button"
                onClick={() => setActiveEntity("application")}
                className={`rounded-xl px-4 py-2 text-sm font-semibold ${activeEntity === "application" ? "bg-[#0b1f3b] text-white" : "bg-surface-strong text-main border border-token"}`}
              >
                Decision Corrections
              </button>
            </div>

            {activeEntity === "job" ? (
              <form onSubmit={submitJobRequest} className="mt-5 grid gap-4">
                <div className="grid gap-4 md:grid-cols-2">
                  <select
                    className={inputCls}
                    value={jobForm.actionType}
                    onChange={(e) =>
                      setJobForm((prev) => ({
                        ...prev,
                        actionType: e.target.value,
                        targetId: "",
                      }))
                    }
                  >
                    <option value="create">Create</option>
                    <option value="update">Update</option>
                    <option value="delete">Delete</option>
                  </select>
                  {jobForm.actionType !== "create" ? (
                    <select
                      className={inputCls}
                      value={jobForm.targetId}
                      onChange={(e) =>
                        setJobForm((prev) => ({ ...prev, targetId: e.target.value }))
                      }
                      required
                    >
                      <option value="">Select target job</option>
                      {jobRefs.map((job) => (
                        <option key={job.id} value={job.id}>
                          #{job.id} - {job.title}
                        </option>
                      ))}
                    </select>
                  ) : null}
                </div>

                {jobForm.actionType !== "delete" ? (
                  <>
                    <div className="grid gap-4 md:grid-cols-2">
                      <input
                        className={inputCls}
                        placeholder="Title"
                        value={jobForm.title}
                        onChange={(e) =>
                          setJobForm((prev) => ({ ...prev, title: e.target.value }))
                        }
                        required
                      />
                      <input
                        className={inputCls}
                        placeholder="Company"
                        value={jobForm.companyName}
                        onChange={(e) =>
                          setJobForm((prev) => ({ ...prev, companyName: e.target.value }))
                        }
                      />
                      <input
                        className={inputCls}
                        placeholder="Employment Type"
                        value={jobForm.employmentType}
                        onChange={(e) =>
                          setJobForm((prev) => ({ ...prev, employmentType: e.target.value }))
                        }
                      />
                      <input
                        className={inputCls}
                        placeholder="Work Setup"
                        value={jobForm.workSetup}
                        onChange={(e) =>
                          setJobForm((prev) => ({ ...prev, workSetup: e.target.value }))
                        }
                      />
                      <input
                        className={inputCls}
                        placeholder="City"
                        value={jobForm.city}
                        onChange={(e) =>
                          setJobForm((prev) => ({ ...prev, city: e.target.value }))
                        }
                      />
                      <input
                        className={inputCls}
                        placeholder="Region"
                        value={jobForm.region}
                        onChange={(e) =>
                          setJobForm((prev) => ({ ...prev, region: e.target.value }))
                        }
                      />
                    </div>
                    <textarea
                      className={textareaCls}
                      rows={3}
                      placeholder="Description"
                      value={jobForm.description}
                      onChange={(e) =>
                        setJobForm((prev) => ({ ...prev, description: e.target.value }))
                      }
                    />
                    <label className="flex items-center gap-2 text-sm text-main">
                      <input
                        type="checkbox"
                        checked={jobForm.isActive}
                        onChange={(e) =>
                          setJobForm((prev) => ({ ...prev, isActive: e.target.checked }))
                        }
                      />
                      Set active on approval
                    </label>
                  </>
                ) : null}
                <button type="submit" className={btnPrimary} disabled={saving}>
                  {saving ? "Submitting..." : "Submit Job Request"}
                </button>
              </form>
            ) : null}

            {activeEntity === "skills" ? (
              <form onSubmit={submitSkillsRequest} className="mt-5 grid gap-4">
                <div className="grid gap-4 md:grid-cols-2">
                  <select
                    className={inputCls}
                    value={skillForm.targetId}
                    onChange={(e) =>
                      setSkillForm((prev) => ({
                        ...prev,
                        targetId: e.target.value,
                      }))
                    }
                    required
                  >
                    <option value="">Select existing job</option>
                    {jobRefs.map((job) => (
                      <option key={job.id} value={job.id}>
                        #{job.id} - {job.title}
                      </option>
                    ))}
                  </select>
                </div>

                {skillForm.targetId ? (
                  <>
                    <div className="rounded-xl border border-token bg-surface-strong px-4 py-3 text-sm text-main">
                      Editing skills for:{" "}
                      <span className="font-semibold">
                        {skillForm.title || "(Untitled Job)"}
                      </span>
                    </div>

                    {skillForm.skills.map((skill, index) => (
                      <div
                        key={`${skill.name}-${index}`}
                        className="grid gap-3 rounded-xl border border-token bg-surface-strong p-4 md:grid-cols-[1.2fr_1fr_110px_120px_auto]"
                      >
                        <input
                          className={inputCls}
                          placeholder="Skill"
                          value={skill.name}
                          onChange={(e) =>
                            setSkillForm((prev) => ({
                              ...prev,
                              skills: prev.skills.map((item, i) =>
                                i === index ? { ...item, name: e.target.value } : item
                              ),
                            }))
                          }
                        />
                        <input
                          className={inputCls}
                          placeholder="Category"
                          value={skill.category}
                          onChange={(e) =>
                            setSkillForm((prev) => ({
                              ...prev,
                              skills: prev.skills.map((item, i) =>
                                i === index ? { ...item, category: e.target.value } : item
                              ),
                            }))
                          }
                        />
                        <label className="flex items-center gap-2 px-2 text-sm text-main">
                          <input
                            type="checkbox"
                            checked={Boolean(skill.required)}
                            onChange={(e) =>
                              setSkillForm((prev) => ({
                                ...prev,
                                skills: prev.skills.map((item, i) =>
                                  i === index ? { ...item, required: e.target.checked } : item
                                ),
                              }))
                            }
                          />
                          Required
                        </label>
                        <input
                          className={inputCls}
                          type="number"
                          step="0.01"
                          min="0"
                          max="1"
                          placeholder="Weight"
                          value={skill.weight}
                          onChange={(e) =>
                            setSkillForm((prev) => ({
                              ...prev,
                              skills: prev.skills.map((item, i) =>
                                i === index ? { ...item, weight: e.target.value } : item
                              ),
                            }))
                          }
                        />
                        <button
                          type="button"
                          className="h-10 rounded-xl border border-token bg-surface px-4 text-sm text-main hover:bg-surface-strong"
                          onClick={() =>
                            setSkillForm((prev) => ({
                              ...prev,
                              skills:
                                prev.skills.length > 1
                                  ? prev.skills.filter((_, i) => i !== index)
                                  : [emptySkill()],
                            }))
                          }
                        >
                          Remove
                        </button>
                      </div>
                    ))}

                    <button
                      type="button"
                      className="h-10 rounded-xl border border-token bg-surface px-4 text-sm text-main hover:bg-surface-strong"
                      onClick={() =>
                        setSkillForm((prev) => ({
                          ...prev,
                          skills: [...prev.skills, emptySkill()],
                        }))
                      }
                    >
                      Add Skill
                    </button>
                  </>
                ) : null}

                <button
                  type="submit"
                  className={btnPrimary}
                  disabled={saving || !skillForm.targetId}
                >
                  {saving ? "Submitting..." : "Submit Skills Request"}
                </button>
              </form>
            ) : null}

            {activeEntity === "application" ? (
              <form onSubmit={submitApplicationCorrectionRequest} className="mt-5 grid gap-4">
                <div className="grid gap-4 md:grid-cols-2">
                  <select
                    className={inputCls}
                    value={applicationForm.targetId}
                    onChange={(e) =>
                      setApplicationForm((prev) => ({
                        ...prev,
                        targetId: e.target.value,
                      }))
                    }
                    required
                  >
                    <option value="">Select application</option>
                    {applicationRefs.map((item) => (
                      <option key={item.id} value={item.id}>
                        #{item.id} - {item.applicantName || "Unknown"} ({item.jobTitle || "Unknown role"})
                      </option>
                    ))}
                  </select>
                  <select
                    className={inputCls}
                    value={applicationForm.toStatus}
                    onChange={(e) =>
                      setApplicationForm((prev) => ({
                        ...prev,
                        toStatus: e.target.value,
                      }))
                    }
                  >
                    <option value="submitted">Submitted</option>
                    <option value="processing">Processing</option>
                    <option value="completed">Completed</option>
                    <option value="endorsed">Endorsed</option>
                    <option value="rejected">Rejected</option>
                  </select>
                </div>

                {selectedApplication ? (
                  <div className="rounded-xl border border-token bg-surface-strong px-4 py-3 text-sm text-main">
                    <div>
                      Application #{selectedApplication.id}:{" "}
                      <span className="font-semibold">
                        {selectedApplication.applicantName || "Unknown Candidate"}
                      </span>{" "}
                      ({selectedApplication.jobTitle || "Unknown role"})
                    </div>
                    <div className="mt-1 text-muted">
                      Current status: {statusLabel(selectedApplication.status)}
                      {selectedApplication.rejectionReason
                        ? ` | Rejection note: ${selectedApplication.rejectionReason}`
                        : ""}
                    </div>
                  </div>
                ) : null}

                <textarea
                  className={textareaCls}
                  rows={3}
                  placeholder="Reason for correction (optional but recommended)"
                  value={applicationForm.reason}
                  onChange={(e) =>
                    setApplicationForm((prev) => ({
                      ...prev,
                      reason: e.target.value,
                    }))
                  }
                />

                {String(applicationForm.toStatus).toLowerCase() === "rejected" ? (
                  <textarea
                    className={textareaCls}
                    rows={3}
                    placeholder="Rejection reason (required for rejected status)"
                    value={applicationForm.rejectionReason}
                    onChange={(e) =>
                      setApplicationForm((prev) => ({
                        ...prev,
                        rejectionReason: e.target.value,
                      }))
                    }
                    required
                  />
                ) : (
                  <label className="flex items-center gap-2 text-sm text-main">
                    <input
                      type="checkbox"
                      checked={Boolean(applicationForm.clearRejectionReason)}
                      onChange={(e) =>
                        setApplicationForm((prev) => ({
                          ...prev,
                          clearRejectionReason: e.target.checked,
                        }))
                      }
                    />
                    Clear rejection reason on approval
                  </label>
                )}

                <button
                  type="submit"
                  className={btnPrimary}
                  disabled={saving || !applicationForm.targetId}
                >
                  {saving ? "Submitting..." : "Submit Correction Request"}
                </button>
              </form>
            ) : null}
          </section>

          <section className={`${cardCls} p-5`}>
            <h2 className="text-xl font-semibold text-main">My Request History</h2>
            <div className="mt-4 overflow-auto rounded-xl border border-token">
              <table className="min-w-full text-sm">
                <thead className="bg-surface-strong text-muted">
                  <tr>
                    <th className="px-4 py-3 text-left">When</th>
                    <th className="px-4 py-3 text-left">Entity</th>
                    <th className="px-4 py-3 text-left">Action</th>
                    <th className="px-4 py-3 text-left">Summary</th>
                    <th className="px-4 py-3 text-left">Status</th>
                    <th className="px-4 py-3 text-left">Review Note</th>
                  </tr>
                </thead>
                <tbody>
                  {sortedRequests.map((request) => (
                    <tr key={request.id} className="border-t border-token bg-surface">
                      <td className="px-4 py-3 text-main">{request.submittedAt ? new Date(request.submittedAt).toLocaleString() : "--"}</td>
                      <td className="px-4 py-3 text-main">{request.entityType}</td>
                      <td className="px-4 py-3 text-main">{request.actionType}</td>
                      <td className="px-4 py-3 text-main">{request.summary}</td>
                      <td className="px-4 py-3"><span className={`inline-flex rounded-full border px-3 py-1 text-xs font-semibold ${statusBadge(request.status)}`}>{request.status}</span></td>
                      <td className="px-4 py-3 text-muted">{request.reviewNote || "--"}</td>
                    </tr>
                  ))}
                  {!sortedRequests.length ? (
                    <tr><td colSpan={6} className="px-4 py-6 text-center text-muted">No submitted requests yet.</td></tr>
                  ) : null}
                </tbody>
              </table>
            </div>
          </section>
        </div>
      </main>
    </div>
  );
}
