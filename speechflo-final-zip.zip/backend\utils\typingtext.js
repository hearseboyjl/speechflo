import { useEffect, useState } from "react";

export default function TypingText({ text = "", speed = 15, className = "" }) {
  const [displayed, setDisplayed] = useState("");

  useEffect(() => {
    if (!text) return;

    setDisplayed("");
    let index = 0;

    const interval = setInterval(() => {
      index++;
      setDisplayed(text.slice(0, index));

      if (index >= text.length) {
        clearInterval(interval);
      }
    }, speed);

    return () => clearInterval(interval);
  }, [text, speed]);

  return (
    <pre className={`whitespace-pre-wrap text-sm ${className}`}>
      {displayed}
    </pre>
  );
}
