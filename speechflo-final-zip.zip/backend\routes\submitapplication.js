import express from "express";
import { db } from "../db.js";
import { authMiddleware, requireRole } from "../routes/authMiddleware.js";
import {
  appendApplicationStatusEvent,
  loadApplicationTimeline,
} from "../utils/applicationTimeline.js";

const router = express.Router();

/**
 * Applicant submits a job application.
 * Flow:
 * - validate active/published job
 * - ensure applicant has a resume on profile
 * - prevent duplicate application
 * - insert application + initial timeline status in one transaction
 */
router.post("/apply", authMiddleware, requireRole("applicant"), async (req, res) => {
  let connection;
  try {
    const user_id = req.user.id;
    const parsedJobId = Number(req.body?.job_id);

    if (!Number.isFinite(parsedJobId)) {
      return res.status(400).json({ message: "Valid job_id is required" });
    }

    const status = "submitted"; // default status

    // Check if user exists
    const [userRows] = await db.query(
      "SELECT first_name, last_name FROM users WHERE id = ?",
      [user_id]
    );
    if (userRows.length === 0) {
      return res.status(404).json({ message: "User not found" });
    }

    // Resolve job by id only so applications are always tied to an exact posting.
    let jobRows = [];
    try {
      const [rows] = await db.query(
        `
        SELECT
          id,
          title,
          is_active,
          lifecycle_status
        FROM jobs
        WHERE id = ?
        LIMIT 1
        `,
        [parsedJobId]
      );
      jobRows = rows;
    } catch (err) {
      if (err?.code !== "ER_BAD_FIELD_ERROR") throw err;
      const [legacyRows] = await db.query(
        "SELECT id, title, is_active FROM jobs WHERE id = ? LIMIT 1",
        [parsedJobId]
      );
      jobRows = legacyRows.map((row) => ({
        ...row,
        lifecycle_status: Boolean(row.is_active) ? "published" : "closed",
      }));
    }

    if (jobRows.length === 0) {
      return res.status(404).json({ message: "Job not found" });
    }
    const lifecycleStatus = String(jobRows[0].lifecycle_status || "").trim().toLowerCase();
    if (!Boolean(jobRows[0].is_active) || (lifecycleStatus && lifecycleStatus !== "published")) {
      return res.status(409).json({ message: "This job posting is no longer active." });
    }

    // Use the applicant's saved resume from profile.
    const [profileRows] = await db.query(
      "SELECT resume_path FROM profiles WHERE user_id = ? LIMIT 1",
      [user_id]
    );
    const resume_path = profileRows[0]?.resume_path || null;
    if (!resume_path) {
      return res.status(400).json({
        message: "No resume found on your profile. Upload a resume in My Profile first.",
      });
    }

    // Prevent duplicate application
    const [existing] = await db.query(
      "SELECT id FROM job_applications WHERE user_id = ? AND job_id = ?",
      [user_id, parsedJobId]
    );
    if (existing.length > 0) {
      return res.status(409).json({
        message: "You already applied to this job",
      });
    }

    connection = await db.getConnection();
    await connection.beginTransaction();

    // Insert into job_applications
    const [result] = await connection.query(
      `
      INSERT INTO job_applications (user_id, job_id, status, resume_path)
      VALUES (?, ?, ?, ?)
      `,
      [user_id, parsedJobId, status, resume_path]
    );

    await appendApplicationStatusEvent(connection, {
      applicationId: result.insertId,
      status: "submitted",
      note: "Application submitted.",
      changedBy: user_id,
    });

    await connection.commit();

    return res.status(201).json({
      message: "Application submitted successfully",
      application_id: result.insertId,
    });
  } catch (err) {
    if (connection) {
      try {
        await connection.rollback();
      } catch {
        // No-op rollback fallback
      }
    }
    console.error("[applications/apply] SERVER ERROR:", err);
    return res.status(500).json({
      message: "Server error",
      error: err.message,
    });
  } finally {
    if (connection) {
      connection.release();
    }
  }
});

/**
 * Returns all applications for the logged-in applicant,
 * including timeline events for each application row.
 */
router.get("/my", authMiddleware, async (req, res) => {
  try {
    const user_id = req.user.id;
    const [rows] = await db.query(
      `SELECT
         a.id,
         a.status,
         a.rejection_reason,
         a.resume_path,
         a.applied_at,
         j.id AS job_id,
         j.title AS job_title,
         j.company_name
       FROM job_applications a
       JOIN jobs j ON a.job_id = j.id
       WHERE a.user_id = ?
       ORDER BY a.applied_at DESC`,
      [user_id]
    );

    const timelineByApplication = await loadApplicationTimeline(
      db,
      rows.map((row) => row.id)
    );

    res.json(
      rows.map((row) => ({
        ...row,
        timeline: timelineByApplication.get(row.id) || [],
      }))
    );
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Server error" });
  }
});

/**
 * Allows applicant to withdraw their own application record.
 */
router.delete("/:id", authMiddleware, async (req, res) => {
  try {
    const user_id = req.user.id;
    const appId = req.params.id;

    // check if the application exists and belongs to this user
    const [rows] = await db.query(
      "SELECT * FROM job_applications WHERE id = ? AND user_id = ?",
      [appId, user_id]
    );

    if (rows.length === 0) {
      return res.status(404).json({ message: "Application not found" });
    }

    // delete the application
    await db.query("DELETE FROM job_applications WHERE id = ?", [appId]);

    res.json({ message: "Application withdrawn successfully" });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Server error" });
  }
});

export default router;
