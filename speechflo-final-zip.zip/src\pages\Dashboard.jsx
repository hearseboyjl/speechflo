import Menubar from "../components/Menubar";
import { useMemo, useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { apiUrl } from "../api";
import { LineChart, Line, ResponsiveContainer, Tooltip, CartesianGrid, XAxis, YAxis, Legend } from "recharts";

function toDisplayStatus(status = "") {
  if (status === "completed") return "Completed";
  if (status === "endorsed") return "Endorsed";
  if (status === "processing") return "Processing";
  if (status === "submitted") return "Processing";
  if (status === "rejected") return "Rejected";
  return status || "Unknown";
}

function statusChip(status = "") {
  if (status === "completed") return "bg-emerald-600 text-white border-emerald-700 shadow-sm dark:bg-emerald-400 dark:text-[#072236] dark:border-emerald-300";
  if (status === "endorsed") return "bg-violet-500 text-white border-violet-600 shadow-sm dark:bg-violet-400 dark:text-[#072236] dark:border-violet-300";
  if (status === "processing") return "bg-sky-600 text-white border-sky-700 shadow-sm dark:bg-sky-400 dark:text-[#072236] dark:border-sky-300";
  if (status === "submitted") return "bg-[#2f8dcd] text-white border-[#2779b3] shadow-sm dark:bg-[#56abde] dark:text-[#072236] dark:border-[#8ed0f0]";
  if (status === "rejected") return "bg-rose-400 text-black border-rose-500 shadow-sm dark:bg-rose-300 dark:text-black dark:border-rose-200";
  return "bg-slate-100 text-slate-700 border-slate-300 shadow-sm dark:bg-slate-300/18 dark:text-slate-100 dark:border-slate-300/35";
}

function shortDate(dateValue) {
  if (!dateValue) return "--";
  return new Date(dateValue).toLocaleDateString();
}

function daysOpen(dateValue) {
  if (!dateValue) return "--";
  const now = Date.now();
  const then = new Date(dateValue).getTime();
  if (Number.isNaN(then)) return "--";
  const d = Math.max(0, Math.floor((now - then) / (1000 * 60 * 60 * 24)));
  return `${d}d`;
}

function unresolvedStatusLabel(status = "") {
  if (status === "submitted") return "Analyze";
  if (status === "processing") return "Processing";
  if (status === "rejected") return "Rejected";
  return status || "Open";
}

function unresolvedStatusChip(status = "") {
  if (status === "submitted") {
    return "border border-amber-700 bg-amber-500 text-black shadow-sm dark:border-amber-300 dark:bg-amber-300 dark:text-black";
  }
  if (status === "processing") {
    return "border border-sky-700 bg-sky-600 text-white shadow-sm dark:border-sky-300 dark:bg-sky-400 dark:text-[#072236]";
  }
  if (status === "rejected") {
    return "border border-rose-500 bg-rose-400 text-black shadow-sm dark:border-rose-200 dark:bg-rose-300 dark:text-black";
  }
  return "border border-slate-300 bg-slate-100 text-slate-700 shadow-sm dark:border-slate-300/35 dark:bg-slate-300/18 dark:text-slate-100";
}

function TrendBadge({ value }) {
  const isUp = Number(value) >= 0;
  const cls = isUp
    ? "border border-emerald-700 bg-emerald-600 text-white shadow-sm dark:border-emerald-300 dark:bg-emerald-400 dark:text-[#072236]"
    : "border border-rose-700 bg-rose-500 text-white shadow-sm dark:border-rose-300 dark:bg-rose-400 dark:text-[#3b0712]";
  const sign = isUp ? "+" : "";
  return (
    <span className={`inline-flex min-w-[52px] items-center justify-center rounded-full px-2.5 py-1 text-[11px] font-semibold ${cls}`}>
      {sign}{value}%
    </span>
  );
}

export default function Dashboard() {
  const navigate = useNavigate();
  const isDarkTheme =
    typeof document !== "undefined" && document.documentElement.classList.contains("dark");
  const [userName, setUserName] = useState("User");
  const [loading, setLoading] = useState(true);
  const [summary, setSummary] = useState({
    stats: {
      interviewsUploaded: 0,
      pendingReviewCount: 0,
      medianTimeToCompletionDays: 0,
      avgKeywordCoverage: 0,
      topMissingSkill: null,
      roleWithLowestAvgScore: null,
      completionRate: 0,
      lowConfidenceRate: 0,
    },
    workflow: {
      oldestProcessing: [],
      lowConfidenceCompleted: [],
      candidatesNeedingManualReview: [],
      topMissingSkill: null,
      roleWithLowestAvgScore: null,
    },
    recentApplications: [],
    charts: { timeline: [] },
  });

  useEffect(() => {
    const token = localStorage.getItem("token");
    if (!token) {
      navigate("/recruiter/login");
      return;
    }

    const load = async () => {
      try {
        const meRes = await fetch(apiUrl("/auth/me"), {
          headers: { Authorization: `Bearer ${token}` },
        });
        if (!meRes.ok) throw new Error("Unauthorized");
        const me = await meRes.json();
        setUserName(me.firstName || "User");
        localStorage.setItem("user", me.firstName || "User");

        const analyticsRes = await fetch(
          apiUrl("/analytics/summary?role=All%20Roles&date=This%20Month"),
          { headers: { Authorization: `Bearer ${token}` } }
        );
        if (!analyticsRes.ok) {
          const text = await analyticsRes.text();
          throw new Error(text || "Failed to load dashboard analytics");
        }
        const analytics = await analyticsRes.json();
        setSummary({
          stats: analytics.stats || {},
          workflow: analytics.workflow || {},
          recentApplications: analytics.recentApplications || [],
          charts: analytics.charts || { timeline: [] },
        });
      } catch (err) {
        console.error("[Dashboard] load error:", err);
        localStorage.removeItem("token");
        localStorage.removeItem("user");
        navigate("/recruiter/login");
      } finally {
        setLoading(false);
      }
    };

    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [navigate]);

  const kpis = useMemo(() => {
    const topMissing = summary.workflow?.topMissingSkill?.skill || summary.stats?.topMissingSkill?.skill || "N/A";
    const weakestRole =
      summary.workflow?.roleWithLowestAvgScore?.role || summary.stats?.roleWithLowestAvgScore?.role || "N/A";
    const weakestRoleScore =
      summary.workflow?.roleWithLowestAvgScore?.avgScore ?? summary.stats?.roleWithLowestAvgScore?.avgScore ?? 0;

    return [
      {
        title: "Interviews This Month",
        value: loading ? "--" : summary.stats.interviewsUploaded,
        icon: "IN",
        trend: 8,
        lightGradient: "linear-gradient(135deg, #2f8dcd 0%, #5dade2 55%, #2a77ae 100%)",
        glow: "from-[#2F8DCD]/40 via-[#58B1E3]/18 to-transparent dark:from-[#65C4F2]/18 dark:via-[#2F8DCD]/10 dark:to-transparent",
      },
      {
        title: "Pending Review",
        value: loading ? "--" : summary.stats.pendingReviewCount,
        icon: "RV",
        trend: -3,
        lightGradient: "linear-gradient(135deg, #4aa6d9 0%, #6cb6e0 50%, #2f8dcd 100%)",
        glow: "from-[#57A9DA]/36 via-[#2F8DCD]/18 to-transparent dark:from-[#7CCBF1]/16 dark:via-[#3797CC]/10 dark:to-transparent",
      },
      {
        title: "Median Time to Completion",
        value: loading ? "--" : `${Number(summary.stats.medianTimeToCompletionDays || 0).toFixed(1)}d`,
        icon: "TT",
        trend: -5,
        lightGradient: "linear-gradient(135deg, #3c9dd4 0%, #56adda 52%, #2a7fb8 100%)",
        glow: "from-[#3C9DD4]/34 via-[#227CB5]/16 to-transparent dark:from-[#6DBDE8]/16 dark:via-[#2C84B8]/10 dark:to-transparent",
      },
      {
        title: "Top Missing Skill",
        value: loading ? "--" : topMissing,
        icon: "MS",
        trend: 0,
        lightGradient: "linear-gradient(135deg, #5baede 0%, #6fbbe5 52%, #348ac2 100%)",
        glow: "from-[#66B6E2]/34 via-[#2D86C1]/16 to-transparent dark:from-[#86D0F1]/16 dark:via-[#3186B9]/10 dark:to-transparent",
      },
      {
        title: "Role Needing Improvement",
        value: loading ? "--" : `${weakestRole} (${Number(weakestRoleScore).toFixed(2)})`,
        icon: "RS",
        trend: -2,
        lightGradient: "linear-gradient(135deg, #49a4d8 0%, #63b2de 52%, #236fa7 100%)",
        glow: "from-[#4AA6D9]/36 via-[#1E6FA7]/16 to-transparent dark:from-[#74C1EA]/16 dark:via-[#2E7FB1]/10 dark:to-transparent",
      },
      {
        title: "Avg Keyword Coverage",
        value: loading ? "--" : Number(summary.stats.avgKeywordCoverage || 0).toFixed(2),
        icon: "KC",
        trend: 6,
        lightGradient: "linear-gradient(135deg, #63b8e4 0%, #7bc6eb 52%, #3c95cc 100%)",
        glow: "from-[#7AC3EA]/34 via-[#3B95CC]/16 to-transparent dark:from-[#91D6F5]/16 dark:via-[#4A9FCC]/10 dark:to-transparent",
      },
    ];
  }, [loading, summary]);

  const recent = summary.recentApplications || [];
  const priorities = summary.workflow?.candidatesNeedingManualReview || [];
  const oldestProcessing = summary.workflow?.oldestProcessing || [];
  const lowConfidenceCompleted = summary.workflow?.lowConfidenceCompleted || [];
  const timeline = (summary.charts?.timeline || []).map((t) => ({
    date: t.date || "",
    label: t.date || "",
    uploaded: t.uploaded || 0,
  }));
  const hasTrendData = timeline.length > 1 && timeline.some((point) => point.uploaded > 0);

  const completionRate = Number((summary.stats?.completionRate || 0) * 100).toFixed(0);
  const lowConfidenceRate = Number((summary.stats?.lowConfidenceRate || 0) * 100).toFixed(0);

  const cardCls = "rounded-3xl bg-surface backdrop-blur-md border border-token shadow-card";
  const sectionTitleCls = "text-xl font-bold text-main";
  const sectionBodyCls = "text-sm text-muted";
  const panelCls = "rounded-2xl border border-token bg-surface-strong shadow-soft";
  const actionBtnCls =
    "h-10 rounded-xl text-sm font-semibold transition-colors";
  const heroStyle = {
    background: isDarkTheme
      ? "linear-gradient(135deg, rgba(10,22,40,0.97) 0%, rgba(15,41,68,0.94) 56%, rgba(25,78,113,0.88) 100%)"
      : "linear-gradient(135deg, rgba(16,86,136,0.96) 0%, rgba(35,125,176,0.94) 48%, rgba(76,167,214,0.88) 100%)",
    color: "#ffffff",
  };
  const heroOverlayStyle = {
    background: isDarkTheme
      ? "radial-gradient(circle at top right, rgba(125,211,252,0.12), transparent 30%), radial-gradient(circle at bottom left, rgba(59,130,246,0.12), transparent 42%)"
      : "radial-gradient(circle at top right, rgba(255,255,255,0.24), transparent 30%), radial-gradient(circle at bottom left, rgba(186,230,253,0.14), transparent 42%)",
  };
  const heroMetricStyle = {
    borderColor: isDarkTheme ? "rgba(224,242,254,0.10)" : "rgba(255,255,255,0.22)",
    background: isDarkTheme ? "rgba(7,19,33,0.28)" : "rgba(255,255,255,0.12)",
  };
  const trendWrapStyle = {
    background: isDarkTheme
      ? "linear-gradient(180deg, rgba(9,24,42,0.72), rgba(12,33,59,0.55))"
      : "linear-gradient(180deg, rgba(255,255,255,0.92), rgba(237,248,253,0.82))",
  };
  const trendEmptyStyle = {
    borderColor: isDarkTheme ? "var(--border-token)" : "#95c8e7",
    background: isDarkTheme
      ? "rgba(2, 6, 23, 0.18)"
      : "linear-gradient(180deg, rgba(255,255,255,0.98), rgba(242,250,255,0.94))",
  };
  const quickActionStyles = {
    primary: {
      borderColor: isDarkTheme ? "rgba(125,211,252,0.10)" : "#8cc3e3",
      background: isDarkTheme ? "#2A78AD" : "#54b0df",
      color: "#ffffff",
    },
    secondary: {
      borderColor: isDarkTheme ? "rgba(125,211,252,0.10)" : "#9bcae7",
      background: isDarkTheme ? "#214F79" : "#79c4e8",
      color: isDarkTheme ? "#ffffff" : "#083151",
    },
    tertiary: {
      borderColor: isDarkTheme ? "rgba(125,211,252,0.10)" : "#aad1ea",
      background: isDarkTheme ? "#173B5B" : "#d9eef9",
      color: isDarkTheme ? "#ffffff" : "#083151",
    },
  };
  const kpiCardStyle = (lightGradient) => ({
    background: isDarkTheme
      ? "linear-gradient(145deg, rgba(16,36,65,0.74) 0%, rgba(15,48,88,0.67) 54%, rgba(11,31,57,0.72) 100%)"
      : lightGradient,
    color: isDarkTheme ? "var(--text-main)" : "#ffffff",
  });
  const openToCheckList = () => {
    navigate("/recruiter/interviewer-hub", {
      state: {
        focus: "next-candidates",
      },
    });
  };

  return (
    <div className="min-h-screen w-full bg-app-bloom">
      <Menubar userName={userName} />

      <main className="min-h-screen pl-[110px] pr-8 py-8">
        <div className="max-w-[1280px] mx-auto space-y-6">
          <section className="relative rounded-3xl overflow-hidden border border-token shadow-strong p-8" style={heroStyle}>
            <div className="pointer-events-none absolute inset-0" style={heroOverlayStyle} />
            <div className="relative flex flex-col lg:flex-row lg:items-end lg:justify-between gap-6">
              <div>
                <p className="text-sm uppercase tracking-[0.18em]" style={{ color: isDarkTheme ? "rgba(224,242,254,0.75)" : "rgba(224,242,254,0.92)" }}>Project Overview</p>
                <h1 className="mt-2 text-4xl font-black leading-tight" style={{ color: "#ffffff" }}>Welcome back, {userName}</h1>
                <p className="mt-3 max-w-2xl text-sm" style={{ color: isDarkTheme ? "rgba(224,242,254,0.75)" : "rgba(240,249,255,0.92)" }}>
                  This month you processed {loading ? "--" : summary.stats.interviewsUploaded} applications with a {completionRate}% completion rate.
                  Nice progress, keep it going.
                </p>
              </div>
              <div className="grid grid-cols-2 gap-3 min-w-[250px]">
                <button
                  type="button"
                  onClick={openToCheckList}
                  className="rounded-2xl border p-3 text-left backdrop-blur-md transition hover:brightness-110 hover:shadow-md"
                  style={heroMetricStyle}
                  title="Open the recruiter to-check list"
                >
                  <p className="text-xs" style={{ color: isDarkTheme ? "rgba(224,242,254,0.70)" : "rgba(240,249,255,0.92)" }}>To Check</p>
                  <p className="text-2xl font-extrabold" style={{ color: "#ffffff" }}>{loading ? "--" : summary.stats.pendingReviewCount}</p>
                </button>
                <div className="rounded-2xl border p-3 backdrop-blur-md" style={heroMetricStyle}>
                  <p className="text-xs" style={{ color: isDarkTheme ? "rgba(224,242,254,0.70)" : "rgba(240,249,255,0.92)" }}>Low Confidence Rate</p>
                  <p className="text-2xl font-extrabold" style={{ color: "#ffffff" }}>{loading ? "--" : `${lowConfidenceRate}%`}</p>
                </div>
              </div>
            </div>
          </section>

          <section className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
            {kpis.map((kpi) => (
              <article
                key={kpi.title}
                className="relative overflow-hidden rounded-2xl border border-token shadow-card p-4"
                style={kpiCardStyle(kpi.lightGradient)}
              >
                <div
                  className={`pointer-events-none absolute inset-0 ${isDarkTheme ? `bg-gradient-to-br ${kpi.glow}` : ""}`}
                  style={
                    isDarkTheme
                      ? undefined
                      : {
                          background: "linear-gradient(135deg, rgba(62,157,212,0.18) 0%, rgba(37,113,168,0.10) 58%, transparent 100%)",
                        }
                  }
                />
                <div className="relative flex items-start justify-between gap-3">
                  <div className="min-w-0">
                    <span className="text-[11px] font-semibold uppercase tracking-[0.14em]" style={{ color: isDarkTheme ? "var(--text-muted)" : "rgba(240,249,255,0.92)" }}>{kpi.title}</span>
                    <p className="mt-4 pr-2 text-2xl font-extrabold leading-tight break-words" style={{ color: isDarkTheme ? "var(--text-main)" : "#ffffff" }}>{kpi.value}</p>
                  </div>
                  <span
                    className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl border text-[11px] font-bold shadow-sm"
                    style={{
                      borderColor: isDarkTheme ? "rgba(224,242,254,0.10)" : "rgba(255,255,255,0.18)",
                      background: isDarkTheme ? "rgba(2,6,23,0.20)" : "rgba(255,255,255,0.16)",
                      color: isDarkTheme ? "var(--text-main)" : "#ffffff",
                    }}
                  >
                    {kpi.icon}
                  </span>
                </div>
                <div className="relative mt-4 flex items-center justify-between gap-3">
                  <span className="text-xs" style={{ color: isDarkTheme ? "var(--text-muted)" : "rgba(240,249,255,0.82)" }}>vs last review cycle</span>
                  <TrendBadge value={kpi.trend} />
                </div>
              </article>
            ))}
          </section>

          <section className="grid grid-cols-1 xl:grid-cols-3 gap-6">
            <article className={`xl:col-span-2 p-6 ${cardCls}`}>
              <div className="flex items-center justify-between gap-4">
                <div>
                  <h2 className={sectionTitleCls}>Recent Interviews</h2>
                  <p className={sectionBodyCls}>Latest submissions with live application status.</p>
                </div>
                <button
                  onClick={() => navigate("/recruiter/analytics")}
                  className="h-10 px-4 rounded-xl border border-[#7eb8de] bg-[#2F8DCD] text-white text-sm font-semibold hover:bg-[#267eb7] dark:border-sky-300/10 dark:bg-[#2A78AD] dark:hover:bg-[#23658F]"
                >
                  View Full Analytics
                </button>
              </div>
              <div className="mt-4 space-y-3">
                {recent.length ? (
                  recent.map((item) => (
                    <div
                      key={item.applicationId}
                      className="rounded-2xl border border-token bg-surface-strong px-4 py-3 flex flex-col md:flex-row md:items-center md:justify-between gap-3"
                    >
                      <div>
                        <p className="font-semibold text-main">{item.name}</p>
                        <p className="text-sm text-muted">{item.role}</p>
                      </div>
                      <div className="flex items-center gap-3">
                        <span className="text-sm text-muted">{shortDate(item.date)}</span>
                        {item.status === "completed" || item.status === "endorsed" ? (
                          <button
                            onClick={() =>
                              navigate("/recruiter/interview-details", {
                                state: {
                                  interview: {
                                    id: item.applicationId,
                                    candidate: item.name,
                                    role: item.role,
                                    date: item.date,
                                    interviewer: localStorage.getItem("user") || "",
                                  },
                                },
                              })
                            }
                            className={`inline-flex items-center rounded-full px-2.5 py-1 text-xs font-semibold border ${statusChip(item.status)} hover:brightness-95`}
                            title="Open interview details"
                          >
                            {toDisplayStatus(item.status)}
                          </button>
                        ) : (
                          <span className={`inline-flex items-center rounded-full px-2.5 py-1 text-xs font-semibold border ${statusChip(item.status)}`}>
                            {toDisplayStatus(item.status)}
                          </span>
                        )}
                      </div>
                    </div>
                  ))
                ) : (
                  <div className="rounded-xl border border-token bg-surface-strong p-4 text-sm text-muted">No interviews yet.</div>
                )}
              </div>
            </article>

            <article className={`p-6 ${cardCls}`}>
              <h2 className={sectionTitleCls}>Upload Trend</h2>
              <p className={sectionBodyCls}>Mini preview of daily volume this month.</p>
              <div className="mt-4 h-[170px] rounded-2xl border border-token p-3" style={trendWrapStyle}>
                {hasTrendData ? (
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={timeline} margin={{ top: 8, right: 14, bottom: 6, left: -16 }}>
                      <CartesianGrid strokeDasharray="3 3" stroke={isDarkTheme ? "rgba(148,163,184,0.18)" : "rgba(148,163,184,0.35)"} />
                      <XAxis
                        dataKey="date"
                        tick={{ fill: isDarkTheme ? "#c8e3f6" : "#4f6d88", fontSize: 10 }}
                        tickLine={false}
                        axisLine={{ stroke: isDarkTheme ? "rgba(148,163,184,0.22)" : "rgba(148,163,184,0.55)" }}
                      />
                      <YAxis
                        allowDecimals={false}
                        tick={{ fill: isDarkTheme ? "#c8e3f6" : "#4f6d88", fontSize: 10 }}
                        tickLine={false}
                        axisLine={{ stroke: isDarkTheme ? "rgba(148,163,184,0.22)" : "rgba(148,163,184,0.55)" }}
                      />
                      <Tooltip
                        contentStyle={{
                          background: "rgba(8, 20, 36, 0.92)",
                          border: "1px solid rgba(125, 211, 252, 0.18)",
                          borderRadius: "12px",
                          color: "#eaf3ff",
                        }}
                        labelStyle={{ color: "#9cc9eb" }}
                      />
                      <Legend wrapperStyle={{ color: isDarkTheme ? "#d6ebf8" : "#35607d", fontSize: "11px" }} />
                      <Line type="monotone" dataKey="uploaded" name="Uploaded" stroke="#7DD3FC" strokeWidth={3} dot={{ r: 3, strokeWidth: 2, fill: isDarkTheme ? "#061a2b" : "#ffffff" }} activeDot={{ r: 5 }} />
                    </LineChart>
                  </ResponsiveContainer>
                ) : (
                  <div className="flex h-full items-center justify-center rounded-[18px] border border-dashed px-5 text-center" style={trendEmptyStyle}>
                    <div>
                      <p className="text-sm font-semibold text-main">Trend preview will appear here</p>
                      <p className="mt-1 text-xs text-muted">Upload more interviews this month to generate a readable chart.</p>
                    </div>
                  </div>
                )}
              </div>

              <div className={`mt-5 p-4 ${panelCls}`}>
                <h3 className="text-sm font-semibold text-main">Quick Actions</h3>
                <div className="mt-3 grid gap-2">
                  <button onClick={() => navigate("/recruiter/interviewer-hub")} className={`${actionBtnCls} border`} style={quickActionStyles.primary}>Go to Interview Hub</button>
                  <button onClick={openToCheckList} className={`${actionBtnCls} border`} style={quickActionStyles.secondary}>Open To-Check List</button>
                  <button onClick={() => navigate("/recruiter/reports")} className={`${actionBtnCls} border`} style={quickActionStyles.tertiary}>Open Reports</button>
                </div>
              </div>
            </article>
          </section>

          <section className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <article className={`p-6 ${cardCls}`}>
              <h3 className="text-lg font-bold text-main">Today&apos;s Focus</h3>
              <p className="text-sm text-muted">Candidates that need a second look</p>
              <div className="mt-4 space-y-3">
                {priorities.slice(0, 5).map((item) => (
                  <div key={item.applicationId} className="rounded-xl bg-surface-strong border border-token p-3">
                    <p className="font-semibold text-main">{item.name}</p>
                    <p className="text-xs text-muted">{item.role}</p>
                    <p className="text-xs text-muted mt-1">
                      {item.status === "submitted" ? "Waiting in Analyze" : `Confidence ${(Number(item.confidence || 0) * 100).toFixed(0)}%`}
                    </p>
                  </div>
                ))}
                {!priorities.length && <p className="text-sm text-muted">No follow-up items.</p>}
              </div>
            </article>

            <article className={`p-6 ${cardCls}`}>
              <h3 className="text-lg font-bold text-main">Oldest Open Application</h3>
              <p className="text-sm text-muted">Applications waiting longest to be completed</p>
              <div className="mt-4 space-y-3">
                {oldestProcessing.map((item) => (
                  <button
                    key={item.applicationId}
                    type="button"
                    onClick={() =>
                      navigate("/recruiter/upload-interview", {
                        state: {
                          applicationId: item.applicationId,
                          applicantId: item.applicantId,
                          applicantName: item.name,
                          jobTitle: item.role,
                          recruiterName: userName,
                          date: shortDate(item.date),
                        },
                      })
                    }
                    className="w-full text-left rounded-xl bg-surface-strong border border-token p-3 hover:brightness-[0.98] transition"
                    title="Open this application in upload interview"
                  >
                    <p className="font-semibold text-main">{item.name}</p>
                    <p className="text-xs text-muted">{item.role}</p>
                    <div className="mt-2 flex flex-wrap items-center gap-2">
                      <span className="inline-flex items-center rounded-full border border-amber-700 bg-amber-500 px-3 py-1 text-xs font-semibold text-black shadow-sm dark:border-amber-300 dark:bg-amber-300 dark:text-black">
                        Open for {daysOpen(item.date)}
                      </span>
                      <span className={`inline-flex items-center rounded-full px-3 py-1 text-xs font-semibold ${unresolvedStatusChip(item.status)}`}>
                        {unresolvedStatusLabel(item.status)}
                      </span>
                    </div>
                  </button>
                ))}
                {!oldestProcessing.length && <p className="text-sm text-muted">No open applications are pending completion right now.</p>}
              </div>
            </article>

            <article className={`p-6 ${cardCls}`}>
              <h3 className="text-lg font-bold text-main">Low-Confidence Finalized</h3>
              <p className="text-sm text-muted">Completed or endorsed cases that may need a manual check</p>
              <div className="mt-4 space-y-3">
                {lowConfidenceCompleted.map((item) => (
                  <div key={item.applicationId} className="rounded-xl bg-surface-strong border border-token p-3">
                    <p className="font-semibold text-main">{item.name}</p>
                    <p className="text-xs text-muted">{item.role}</p>
                    <p className="mt-1 text-xs text-rose-700 dark:text-rose-200">Confidence {(Number(item.confidence || 0) * 100).toFixed(0)}%</p>
                  </div>
                ))}
                {!lowConfidenceCompleted.length && <p className="text-sm text-muted">No low-confidence finalized interviews.</p>}
              </div>
            </article>
          </section>
        </div>
      </main>
    </div>
  );
}

