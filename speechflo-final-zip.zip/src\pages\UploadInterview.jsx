import Menubar from "../components/Menubar";
import { useMemo, useRef, useState, useEffect } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import { apiUrl } from "../api";

export default function UploadInterview() {

  const navigate = useNavigate();
  const fileRef = useRef(null);
  const location = useLocation();
  
  

  const applicantId = location.state?.applicantId;
  const applicationId = location.state?.applicationId;
  const passedState = location.state || {};
  const applicantNameFromState = passedState.applicantName || "";
  const jobTitleFromState = passedState.jobTitle || "";
  const dateFromState = passedState.date || "";
  const recruiterName = passedState.recruiterName || "";

  const [userName, setUserName] = useState("User");

  //force login if no session detected
  useEffect(() => {
    const token = localStorage.getItem("token");
    if (!token) {
      navigate("/recruiter/login");
      return;
    }

    const verifyUser = async () => {
      try {
        const res = await fetch(apiUrl("/auth/me"), {
          headers: { Authorization: `Bearer ${token}` },
        });

        if (!res.ok) throw new Error("Unauthorized");

        const data = await res.json();
        localStorage.setItem("user", data.firstName || "User");
      } catch (err) {
        localStorage.removeItem("token");
        localStorage.removeItem("user");
        navigate("/recruiter/login");
      }
    };

    verifyUser();
  }, [navigate]);


  //fetch user's first name
  useEffect(() => {
  const token = localStorage.getItem("token");
  if (!token) {
    navigate("/recruiter/login");
    return;
  }

  const verifyUser = async () => {
    try {
      const res = await fetch(apiUrl("/auth/me"), {
        headers: { Authorization: `Bearer ${token}` },
      });

      if (!res.ok) throw new Error("Unauthorized");

      const data = await res.json();
      setUserName(data.firstName || "User"); // <-- set first name for Menubar
      localStorage.setItem("user", data.firstName || "User");
    } catch (err) {
      localStorage.removeItem("token");
      localStorage.removeItem("user");
      navigate("/recruiter/login");
    }
  };

  verifyUser();
}, [navigate]);
  const [form, setForm] = useState({
    jobTitle: passedState.jobTitle || "",
    applicantName: passedState.applicantName || "",
    recruiterName: passedState.recruiterName || "",
  date: passedState.date || "",
  });

  const [loading, setLoading] = useState(false);
  const [file, setFile] = useState(null);
  const [transcriptionLanguage, setTranscriptionLanguage] = useState("taglish");
  const [analysisProgress, setAnalysisProgress] = useState({
    percent: 0,
    stage: "Preparing analysis...",
  });

  const onChange = (e) => {
    const { name, value } = e.target;
    setForm((p) => ({ ...p, [name]: value }));
  };

  const onPickFile = (e) => {
    const f = e.target.files?.[0] || null;
    setFile(f);
  };

  // upload call -----------------------------
const onUpload = async () => {
  if (!form.jobTitle.trim()) return alert("Job Title is required.");
  if (!form.applicantName.trim()) return alert("Applicant Name is required.");
  if (!file) return alert("Please attach an interview recording file.");

  const token = localStorage.getItem("token");
  const setApplicationStatus = async (status) => {
    if (!applicationId || !token) return;
    await fetch(apiUrl(`/job-applications/${applicationId}/status`), {
      method: "PATCH",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
      body: JSON.stringify({ status }),
    });
  };

  setLoading(true);
  setAnalysisProgress({ percent: 10, stage: "Uploading interview audio..." });

  try {
    await setApplicationStatus("processing");

    // 1Ã¯Â¸ÂÃ¢Æ’Â£ Upload audio and get transcript
    const formData = new FormData();
    formData.append("audio", file);
    formData.append("applicationId", applicationId);
    formData.append("applicantId", applicantId);
    formData.append("transcriptionLanguage", transcriptionLanguage);

    const uploadRes = await fetch(apiUrl("/transcribe/upload-audio"), {
      method: "POST",
      headers: {
        Authorization: `Bearer ${token}`,
      },
      body: formData,
    });

    if (!uploadRes.ok) {
      const text = await uploadRes.text();
      console.error("Upload failed:", text);
      alert("Upload failed. The interview was not processed. Please try again. If the issue continues, contact the recruiter/admin.");
      return;
    }

    setAnalysisProgress({ percent: 70, stage: "Validating role compatibility..." });

    await uploadRes.json();

    // 3Ã¯Â¸ÂÃ¢Æ’Â£ Optional: run skill validation (if still needed)
    try {
      const skillValRes = await fetch(
        apiUrl(`/api/validate-skills/${applicationId}?roleNameFront=${encodeURIComponent(form.jobTitle)}`),
        {
          method: "GET",
          headers: { Authorization: `Bearer ${token}` },
        }
      );

      if (skillValRes.ok) {
        await skillValRes.json();
      } else {
        const text = await skillValRes.text();
        console.error("[SkillValidation] Failed:", text);
      }
    } catch (err) {
      console.error("[SkillValidation] Error:", err);
    }

    setAnalysisProgress({ percent: 100, stage: "Finalizing analysis..." });

    // Navigate back to hub after upload
    navigate("/recruiter/interviewer-hub");
  } catch (err) {
    console.error("Upload failed:", err);
    alert("Upload failed. The interview was not processed. Please try again. If the issue continues, contact the recruiter/admin.");
  } finally {
    setLoading(false);
  }
};


  const cardCls = [
    "rounded-2xl",
    "bg-surface backdrop-blur-md",
    "shadow-[0_12px_30px_rgba(15,23,42,0.08)]",
    "hover:shadow-[0_18px_45px_rgba(15,23,42,0.12)]",
    "transition-shadow",
    "border-2 border-token",
    "p-6",
  ].join(" ");

  const inputCls =
    "h-10 w-full rounded-xl bg-surface-strong border border-token px-4 text-sm " +
    "text-main shadow-sm outline-none " +
    "placeholder:text-muted " +
    "focus:ring-2 focus:ring-[#2F8DCD]/30 focus:border-[#2F8DCD]/40";

  const primaryBtn = [
    "h-10 px-6 rounded-xl",
    "bg-btn-primary font-semibold",
    "shadow-[0_8px_20px_rgba(15,23,42,0.15)]",
    "hover:brightness-95 hover:shadow-[0_12px_28px_rgba(15,23,42,0.2)]",
    "active:translate-y-[1px]",
    "transition-all duration-200",
  ].join(" ");

  const secondaryBtn = [
    "h-10 px-6 rounded-xl",
    "bg-surface text-main font-semibold",
    "border border-token",
    "shadow-sm",
    "hover:brightness-[0.98]",
    "active:translate-y-[1px]",
    "transition",
  ].join(" ");

  const linkCls = "text-xs font-semibold text-[#2F8DCD] hover:underline";

  return (
    <div className="min-h-screen w-full bg-app">
      <Menubar userName={userName} />

      <main className="min-h-screen bg-app layout-main">
        <div className="max-w-[1200px] mx-auto px-8 py-8">
          {/* Header */}
          <div className="flex items-start justify-between gap-6">
            <h1 className="text-4xl font-bold text-title">Upload a new interview</h1>

            <button type="button" onClick={() => navigate(-1)} className={secondaryBtn}>
              Back
            </button>
          </div>

          {/* Main grid */}
          <div className="mt-10 grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* LEFT */}
            <section className={`lg:col-span-2 ${cardCls}`}>
              <h2 className="text-xl font-semibold text-main">Interview Details</h2>

              <div className="mt-5 grid grid-cols-1 md:grid-cols-2 gap-4">
                <input
                  name="jobTitle"
                  value={form.jobTitle}
                  onChange={onChange}
                  className={inputCls}
                  placeholder="Job Title (e.g. Front End Developer)"
                />
                <input
                  name="applicantName"
                  value={form.applicantName}
                  onChange={onChange}
                  className={inputCls}
                  placeholder="Applicant Name"
                />
                <input
                  name="recruiterName"
                  value={form.recruiterName}
                  onChange={onChange}
                  className={inputCls}
                  placeholder="Recruiter Name"
                />
                <input
                  name="date"
                  value={form.date}
                  onChange={onChange}
                  className={inputCls}
                  placeholder="mm/dd/yy"
                />
                <select
                  value={transcriptionLanguage}
                  onChange={(e) => setTranscriptionLanguage(e.target.value)}
                  className={inputCls}
                >
                  <option value="taglish">Transcription: Taglish (Recommended)</option>
                  <option value="auto">Transcription: Auto-detect</option>
                  <option value="en">Transcription: English</option>
                  <option value="tl">Transcription: Filipino / Tagalog</option>
                </select>
              </div>

              {/* Upload */}
              <div className="mt-10 flex flex-col sm:flex-row sm:items-center gap-6">
                <button
                  type="button"
                  onClick={onUpload}
                  className={primaryBtn}
                  disabled={loading} // disabled while uploading
                >
                  {loading ? "Uploading..." : "Upload Interview"}
                </button>

                <div className="flex items-center gap-3">
                  <input
                    ref={fileRef}
                    type="file"
                    accept="audio/*,video/*"
                    onChange={onPickFile}
                    className="hidden"
                  />
                  <button
                    type="button"
                    onClick={() => fileRef.current?.click()}
                    className="text-sm text-muted underline hover:text-main transition"
                  >
                    Add Interview Recording File
                  </button>

                  {file && (
                    <span className="text-xs text-main font-semibold truncate max-w-[260px]">
                      ({file.name})
                    </span>
                  )}
                </div>
              </div>
            </section>
          </div>

          {/* Loading modal */}
          {loading && (
            <div className="fixed inset-0 flex items-center justify-center bg-black/40 z-50">
              <div className="bg-white rounded-xl p-6 shadow-lg text-center w-[90%] max-w-md">
                <p className="font-semibold text-lg">Analyzing interview</p>
                <p className="text-sm text-gray-600 mt-2">{analysisProgress.stage}</p>
                <div className="mt-4 w-full bg-gray-200 rounded-full h-3 overflow-hidden">
                  <div
                    className="h-3 bg-blue-600 transition-all duration-300"
                    style={{ width: `${analysisProgress.percent}%` }}
                  />
                </div>
                <p className="text-xs text-gray-600 mt-2">{analysisProgress.percent}%</p>
              </div>
            </div>
          )}
        </div>
      </main>
    </div>
  );
}


