import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { apiUrl } from "./api";

const MAX_RESUME_SIZE_BYTES = 10 * 1024 * 1024;
const MAX_RESUME_SIZE_LABEL = "10 MB";

export default function Submit_Application() {
  const navigate = useNavigate();

  const [formData, setFormData] = useState({
    fullName: "",
    email: "",
    contact: "",
    resume: null,
    resumePath: "",
  });
  const [errors, setErrors] = useState({});
  const [isEditing, setIsEditing] = useState(false);
  const [passwordForm, setPasswordForm] = useState({
    currentPassword: "",
    newPassword: "",
    confirmPassword: "",
  });
  const [passwordSaving, setPasswordSaving] = useState(false);
  const [passwordNotice, setPasswordNotice] = useState("");

  useEffect(() => {
    const fetchProfile = async () => {
      const token = localStorage.getItem("token");
      if (!token) {
        navigate("/login-applicant");
        return;
      }

      try {
        const res = await fetch(apiUrl("/profiles"), {
          headers: { Authorization: `Bearer ${token}` },
        });
        if (!res.ok) return;

        const data = await res.json();
        setFormData({
          fullName: `${data.firstName} ${data.lastName}`.trim(),
          email: data.email || "",
          contact: data.contact || "",
          resume: null,
          resumePath: data.resume_path || "",
        });
      } catch (err) {
        console.error("Failed to fetch profile", err);
      }
    };

    fetchProfile();
  }, [navigate]);

  const handleChange = (e) => {
    const { name, value, files } = e.target;
    const nextFile = files ? files[0] : null;

    if (nextFile && nextFile.size > MAX_RESUME_SIZE_BYTES) {
      setErrors((prev) => ({
        ...prev,
        resume: `Resume must be ${MAX_RESUME_SIZE_LABEL} or smaller`,
      }));
      return;
    }

    setFormData((prev) => ({
      ...prev,
      [name]: files ? nextFile : value,
    }));
    setErrors((prev) => ({ ...prev, [name]: "" }));
  };

  const validate = () => {
    const newErrors = {};

    if (!/^[A-Za-z\s]+$/.test(formData.fullName)) {
      newErrors.fullName = "Full name must contain letters only";
    }

    if (!/^\S+@\S+\.\S+$/.test(formData.email)) {
      newErrors.email = "Enter a valid email address";
    }

    if (formData.contact && !/^\d{11}$/.test(formData.contact)) {
      newErrors.contact = "Contact number must be exactly 11 digits";
    }

    if (!formData.resume && !formData.resumePath) {
      newErrors.resume = "Resume is required";
    } else if (formData.resume) {
      const allowedTypes = [
        "application/pdf",
        "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
      ];
      if (!allowedTypes.includes(formData.resume.type)) {
        newErrors.resume = "Only PDF or DOCX files are allowed";
      } else if (formData.resume.size > MAX_RESUME_SIZE_BYTES) {
        newErrors.resume = `Resume must be ${MAX_RESUME_SIZE_LABEL} or smaller`;
      }
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!isEditing || !validate()) return;

    try {
      const form = new FormData();
      form.append("fullName", formData.fullName);
      form.append("email", formData.email);
      form.append("contact", formData.contact);
      if (formData.resume) form.append("resume", formData.resume);

      const token = localStorage.getItem("token");
      const res = await fetch(apiUrl("/profiles"), {
        method: "POST",
        body: form,
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });

      if (!res.ok) {
        const contentType = res.headers.get("content-type") || "";
        const data = contentType.includes("application/json") ? await res.json() : null;
        alert(data?.message || "Failed to save profile");
        return;
      }

      setIsEditing(false);
      navigate("/my_applications");
    } catch (err) {
      console.error(err);
      alert("Something went wrong. Try again.");
    }
  };

  const handlePasswordChange = async (e) => {
    e.preventDefault();

    const currentPassword = String(passwordForm.currentPassword || "");
    const newPassword = String(passwordForm.newPassword || "");
    const confirmPassword = String(passwordForm.confirmPassword || "");

    if (!currentPassword || !newPassword || !confirmPassword) {
      setPasswordNotice("Please complete all password fields.");
      return;
    }
    if (newPassword.length < 8) {
      setPasswordNotice("New password must be at least 8 characters.");
      return;
    }
    if (newPassword !== confirmPassword) {
      setPasswordNotice("New password and confirmation do not match.");
      return;
    }

    setPasswordSaving(true);
    try {
      const token = localStorage.getItem("token");
      const res = await fetch(apiUrl("/auth/change-password"), {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ currentPassword, newPassword }),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) {
        throw new Error(data?.message || "Failed to change password.");
      }
      setPasswordNotice(data?.message || "Password changed successfully.");
      setPasswordForm({
        currentPassword: "",
        newPassword: "",
        confirmPassword: "",
      });
    } catch (err) {
      setPasswordNotice(err.message || "Failed to change password.");
    } finally {
      setPasswordSaving(false);
    }
  };

  const inputClass = (error, readOnly = false) =>
    `w-full h-11 rounded-xl bg-white px-4 text-sm border
     ${error ? "border-red-500" : "border-[#2475AF]/70"}
     ${readOnly ? "cursor-not-allowed bg-slate-50 text-slate-500" : ""}
     shadow-md outline-none
     focus:ring-2
     ${error ? "focus:ring-red-500" : "focus:ring-[#2475AF]/40"}
     transition`;

  return (
    <div
      className="relative min-h-screen px-4 sm:px-6 lg:px-8 py-10 overflow-hidden"
      style={{
        background:
          "linear-gradient(to bottom right, #abd7f4 0%, #C4D6E3 48%, #4a8fc1 100%)",
      }}
    >
      <div className="relative z-20 max-w-5xl mx-auto">
        <h1 className="mb-6 text-2xl font-bold text-[#0b1440]">My Profile</h1>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="rounded-xl border border-[#2475AF]/80 bg-white/75 p-6 shadow-lg backdrop-blur-md">
            <div className="mb-4 flex items-center justify-between gap-3">
              <h2 className="text-lg font-semibold text-[#0b1440]">Personal Information</h2>
              <div className="flex items-center gap-2">
                {isEditing && (
                  <button
                    type="button"
                    onClick={() => {
                      setIsEditing(false);
                      setErrors({});
                    }}
                    className="rounded-full border border-slate-300 px-4 py-2 text-xs font-semibold text-slate-700 transition hover:bg-white/70"
                  >
                    Cancel
                  </button>
                )}
                <button
                  type="button"
                  onClick={() => setIsEditing((prev) => !prev)}
                  className="inline-flex items-center gap-2 rounded-full bg-[#2F8DCD] px-4 py-2 text-xs font-semibold text-white shadow-[0_6px_18px_rgba(47,141,205,0.35)] transition hover:bg-[#2a7fc0]"
                >
                  <span className="grid h-5 w-5 place-items-center rounded-full bg-white/20 text-[10px] font-bold">
                    E
                  </span>
                  {isEditing ? "Editing" : "Edit Profile"}
                </button>
              </div>
            </div>

            <p className="mb-4 text-xs text-slate-600">
              Click <span className="font-semibold">Edit Profile</span> before changing your details or uploading a new resume.
            </p>

            <div className="space-y-4">
              <input
                name="fullName"
                type="text"
                placeholder="Full name"
                value={formData.fullName}
                onChange={handleChange}
                readOnly={!isEditing}
                className={inputClass(errors.fullName, !isEditing)}
              />
              {errors.fullName && <p className="text-xs text-red-500">{errors.fullName}</p>}

              <input
                name="email"
                type="email"
                placeholder="Email"
                value={formData.email}
                onChange={handleChange}
                readOnly
                className={inputClass(errors.email, true)}
              />
              {errors.email && <p className="text-xs text-red-500">{errors.email}</p>}

              <input
                name="contact"
                type="tel"
                maxLength={11}
                placeholder="Contact Number (11 digits)"
                value={formData.contact}
                onChange={(e) => {
                  const value = e.target.value.replace(/\D/g, "");
                  setFormData((prev) => ({ ...prev, contact: value }));
                  setErrors((prev) => ({ ...prev, contact: "" }));
                }}
                readOnly={!isEditing}
                className={inputClass(errors.contact, !isEditing)}
              />
              {errors.contact && <p className="text-xs text-red-500">{errors.contact}</p>}
            </div>
          </div>

          <div className="rounded-xl border border-[#2475AF]/80 bg-white/75 p-6 shadow-lg backdrop-blur-md">
            <h2 className="mb-2 font-semibold text-[#0b1440]">Uploads</h2>
            <p className="mb-4 text-xs text-gray-600">Resume (PDF / DOCX, max {MAX_RESUME_SIZE_LABEL})</p>

            <label
              className={`inline-flex items-center gap-3 rounded-xl border-2 border-dashed px-6 py-3 text-sm text-[#2475AF] transition
                ${errors.resume ? "border-red-500" : "border-[#2475AF]"}
                ${isEditing ? "cursor-pointer hover:bg-[#2475AF]/10" : "cursor-not-allowed opacity-70"}
              `}
            >
              <span className="font-semibold">
                {formData.resume
                  ? formData.resume.name
                  : formData.resumePath
                  ? formData.resumePath.split("/").pop()
                  : "Choose file"}
              </span>
              <input
                type="file"
                name="resume"
                onChange={handleChange}
                accept=".pdf,.docx,application/pdf,application/vnd.openxmlformats-officedocument.wordprocessingml.document"
                disabled={!isEditing}
                className="hidden"
              />
            </label>

            {errors.resume && <p className="mt-2 text-xs text-red-500">{errors.resume}</p>}
          </div>

          <div className="flex justify-end">
            <button
              type="submit"
              disabled={!isEditing}
              className="
                rounded-full bg-[#2F8DCD] px-8 py-2 text-sm font-semibold text-white
                shadow-[0_6px_18px_rgba(47,141,205,0.45)]
                transition-all hover:bg-[#2a7fc0] active:scale-95
                disabled:cursor-not-allowed disabled:opacity-50 disabled:hover:bg-[#2F8DCD] disabled:active:scale-100
              "
            >
              Save Profile
            </button>
          </div>
        </form>

        <form
          onSubmit={handlePasswordChange}
          className="mt-6 rounded-xl border border-[#2475AF]/80 bg-white/75 p-6 shadow-lg backdrop-blur-md"
        >
          <h2 className="mb-2 font-semibold text-[#0b1440]">Security</h2>
          <p className="mb-4 text-xs text-gray-600">Change your account password.</p>

          <div className="grid gap-4 md:grid-cols-3">
            <input
              type="password"
              placeholder="Current Password"
              value={passwordForm.currentPassword}
              onChange={(e) =>
                setPasswordForm((prev) => ({ ...prev, currentPassword: e.target.value }))
              }
              className={inputClass(false, false)}
            />
            <input
              type="password"
              placeholder="New Password"
              value={passwordForm.newPassword}
              onChange={(e) =>
                setPasswordForm((prev) => ({ ...prev, newPassword: e.target.value }))
              }
              className={inputClass(false, false)}
            />
            <input
              type="password"
              placeholder="Confirm New Password"
              value={passwordForm.confirmPassword}
              onChange={(e) =>
                setPasswordForm((prev) => ({ ...prev, confirmPassword: e.target.value }))
              }
              className={inputClass(false, false)}
            />
          </div>

          {passwordNotice ? (
            <p className="mt-3 text-xs text-[#0b1440]">{passwordNotice}</p>
          ) : null}

          <div className="mt-4 flex justify-end">
            <button
              type="submit"
              disabled={passwordSaving}
              className="rounded-full bg-[#2F8DCD] px-8 py-2 text-sm font-semibold text-white shadow-[0_6px_18px_rgba(47,141,205,0.45)] transition-all hover:bg-[#2a7fc0] active:scale-95 disabled:opacity-60"
            >
              {passwordSaving ? "Updating..." : "Update Password"}
            </button>
          </div>
        </form>

        <div className="mt-10 text-center text-s text-slate-500">(c) 2026 AvantePH</div>
      </div>
    </div>
  );
}
