const KEY = "theme"; // "Light" | "Dark"

/**
 * Returns the saved theme, defaulting to "Light".
 */
export function getSavedTheme() {
  const saved = localStorage.getItem(KEY);
  return saved === "Dark" ? "Dark" : "Light";
}

export function applyTheme(theme) {
  const root = document.documentElement; // <html>
  const body = document.body;
  const appRoot = document.getElementById("root");
  const shouldBeDark = theme === "Dark";

  [root, body, appRoot].forEach((el) => {
    if (!el) return;
    el.classList.toggle("dark", shouldBeDark);
  });

  root.style.colorScheme = shouldBeDark ? "dark" : "light";
}

export function saveTheme(theme) {
  const nextTheme = theme === "Dark" ? "Dark" : "Light";
  localStorage.setItem(KEY, nextTheme);
  applyTheme(nextTheme);
}

export function initTheme() {
  applyTheme(getSavedTheme());
  return () => {};
}
