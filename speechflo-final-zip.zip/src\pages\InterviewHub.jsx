import Menubar from "../components/Menubar";
import { useMemo, useState, useCallback, useEffect, useRef } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { apiUrl } from "../api";
import { authHeaders, clearSession, getToken } from "../session";

export default function InterviewHub() {
  const location = useLocation();
  const nextCandidatesRef = useRef(null);
  const navigate = useNavigate();
  const [userName, setUserName] = useState("User");
  const [rows, setRows] = useState([]);
  const [filters, setFilters] = useState({
    role: "All Roles",
    status: "All Status",
    date: "Date",
    search: "",
  });
  const [showNotesModal, setShowNotesModal] = useState(false);
  const [selectedNotesRow, setSelectedNotesRow] = useState(null);
  const [caseNotes, setCaseNotes] = useState([]);
  const [notesDraft, setNotesDraft] = useState("");
  const [notesLoading, setNotesLoading] = useState(false);
  const [notesSaving, setNotesSaving] = useState(false);

  useEffect(() => {
    const token = getToken();

    if (!token) {
      navigate("/recruiter/login");
      return;
    }

    const verifyUser = async () => {
      try {
        const res = await fetch(apiUrl("/auth/me"), {
          headers: authHeaders(),
        });

        if (!res.ok) throw new Error("Unauthorized");

        const data = await res.json();

        if (data.firstName) {
          setUserName(data.firstName);
        }
      } catch {
        clearSession();
        navigate("/recruiter/login");
      }
    };

    verifyUser();
  }, [navigate]);

  useEffect(() => {
    const fetchApplications = async () => {
      try {
        const res = await fetch(apiUrl("/job-applications"), {
          headers: authHeaders(),
        });
        if (!res.ok) throw new Error(`HTTP error ${res.status}`);
        const data = await res.json();
        const formatted = data.map((r) => ({
          ...r,
          rejectionReason: r.rejection_reason || "",
          noteCount: Number(r.note_count || 0),
          lastNoteAt: r.last_note_at || null,
          displayStatus:
            r.status === "submitted"
              ? "Analyze"
              : r.status === "processing"
              ? "Processing"
              : r.status === "completed"
              ? "Completed"
              : r.status === "endorsed"
              ? "Endorsed"
              : r.status === "rejected"
              ? "Rejected"
              : r.status,
          appliedAt: r.applied_at ? new Date(r.applied_at) : null,
        }));

        setRows(formatted);
      } catch (err) {
        console.error("Failed to fetch job applications:", err);
      }
    };

    fetchApplications();
  }, []);

  useEffect(() => {
    if (location.state?.focus === "next-candidates" && nextCandidatesRef.current) {
      nextCandidatesRef.current.scrollIntoView({ behavior: "smooth", block: "start" });
    }
  }, [location.state]);

  const onChange = useCallback((e) => {
    const { name, value } = e.target;
    setFilters((p) => ({ ...p, [name]: value }));
  }, []);

  const markRowProcessing = useCallback(async (row) => {
    if (!row?.id || row.status !== "submitted") return true;

    const res = await fetch(apiUrl(`/job-applications/${row.id}/status`), {
      method: "PATCH",
      headers: {
        "Content-Type": "application/json",
        ...authHeaders(),
      },
      body: JSON.stringify({ status: "processing" }),
    });

    if (!res.ok) {
      const text = await res.text();
      throw new Error(text || "Failed to set application to processing");
    }

    setRows((current) =>
      current.map((item) =>
        item.id === row.id
          ? {
              ...item,
              status: "processing",
              displayStatus: "Processing",
            }
          : item
      )
    );

    return true;
  }, []);

  const goToDetails = useCallback(
    (row) => {
      navigate("/recruiter/interview-details", { state: { interview: row } });
    },
    [navigate]
  );

  const goToUpload = useCallback(
    async (row) => {
      try {
        await markRowProcessing(row);
        navigate("/recruiter/upload-interview", {
          state: {
            applicationId: row.id,
            applicantId: row.applicantId,
            applicantName: row.candidate,
            jobTitle: row.role,
            recruiterName: userName,
            date: new Date().toLocaleDateString(),
          },
        });
      } catch (err) {
        console.error("Failed to open upload flow:", err);
        alert("Failed to open the upload flow. Please try again.");
      }
    },
    [markRowProcessing, navigate, userName]
  );

  const downloadResume = async (row) => {
    try {
      if (!row?.id || !row?.file || row.file === "No file") return;
      const token = getToken();
      if (!token) {
        navigate("/recruiter/login");
        return;
      }

      const res = await fetch(apiUrl(`/job-applications/${row.id}/resume`), {
        headers: authHeaders(),
      });
      if (!res.ok) {
        const text = await res.text();
        throw new Error(text || "Failed to download resume");
      }

      const blob = await res.blob();
      const cd = res.headers.get("content-disposition") || "";
      const m = cd.match(/filename="?([^"]+)"?/i);
      const filename = m?.[1] || row.file || `resume-${row.id}`;

      const url = window.URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = filename;
      document.body.appendChild(a);
      a.click();
      a.remove();
      window.URL.revokeObjectURL(url);
    } catch (err) {
      console.error("Resume download failed:", err);
      alert("Failed to download resume.");
    }
  };

  const openCaseNotes = useCallback(async (row) => {
    if (!row?.id) return;

    setSelectedNotesRow(row);
    setShowNotesModal(true);
    setNotesDraft("");
    setNotesLoading(true);
    try {
      const res = await fetch(apiUrl(`/job-applications/${row.id}/notes`), {
        headers: authHeaders(),
      });
      if (!res.ok) {
        const text = await res.text();
        throw new Error(text || "Failed to fetch case notes");
      }
      const data = await res.json();
      setCaseNotes(Array.isArray(data) ? data : []);
    } catch (err) {
      console.error("Failed to fetch case notes:", err);
      alert("Failed to load case notes.");
      setCaseNotes([]);
    } finally {
      setNotesLoading(false);
    }
  }, []);

  const saveCaseNote = useCallback(async () => {
    if (!selectedNotesRow?.id) return;
    const note = String(notesDraft || "").trim();
    if (!note) {
      alert("Note is required.");
      return;
    }

    setNotesSaving(true);
    try {
      const res = await fetch(apiUrl(`/job-applications/${selectedNotesRow.id}/notes`), {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          ...authHeaders(),
        },
        body: JSON.stringify({ note }),
      });
      if (!res.ok) {
        const text = await res.text();
        throw new Error(text || "Failed to save note");
      }

      const notesRes = await fetch(apiUrl(`/job-applications/${selectedNotesRow.id}/notes`), {
        headers: authHeaders(),
      });
      const nextNotes = notesRes.ok ? await notesRes.json() : [];
      setCaseNotes(Array.isArray(nextNotes) ? nextNotes : []);
      setNotesDraft("");

      setRows((current) =>
        current.map((item) =>
          item.id === selectedNotesRow.id
            ? {
                ...item,
                noteCount: (Number(item.noteCount || 0) + 1),
                lastNoteAt: new Date().toISOString(),
              }
            : item
        )
      );
    } catch (err) {
      console.error("Failed to save note:", err);
      alert("Failed to save note.");
    } finally {
      setNotesSaving(false);
    }
  }, [notesDraft, selectedNotesRow]);

  const filteredRows = useMemo(() => {
    const now = new Date();
    return rows
      .filter((r) => {
        const roleMatch = filters.role === "All Roles" || r.role === filters.role;
        const statusMatch = filters.status === "All Status" || r.displayStatus === filters.status;
        const searchMatch =
          !filters.search ||
          r.candidate.toLowerCase().includes(filters.search.toLowerCase()) ||
          r.role.toLowerCase().includes(filters.search.toLowerCase());
        const dateMatch = (() => {
          if (!r.appliedAt || filters.date === "Date") return true;
          const diff = now - r.appliedAt;
          if (filters.date === "This Week") return diff <= 7 * 24 * 60 * 60 * 1000;
          if (filters.date === "This Month") return diff <= 30 * 24 * 60 * 60 * 1000;
          if (filters.date === "This Year") return diff <= 365 * 24 * 60 * 60 * 1000;
          return true;
        })();
        return roleMatch && statusMatch && searchMatch && dateMatch;
      })
      .sort((a, b) => b.appliedAt - a.appliedAt);
  }, [rows, filters]);

  const roleOptions = ["All Roles", ...Array.from(new Set(rows.map((r) => r.role)))];

  const submittedCount = rows.filter((r) => r.status === "submitted").length;
  const processingCount = rows.filter((r) => r.status === "processing").length;
  const completedCount = rows.filter((r) => r.status === "completed").length;
  const endorsedCount = rows.filter((r) => r.status === "endorsed").length;
  const rejectedCount = rows.filter((r) => r.status === "rejected").length;
  const completionRate = rows.length ? Math.round(((completedCount + endorsedCount) / rows.length) * 100) : 0;
  const backlog = submittedCount + processingCount;
  const priorityList = rows
    .filter((r) => r.status === "submitted" || r.status === "processing")
    .sort((a, b) => (a.appliedAt?.getTime() || 0) - (b.appliedAt?.getTime() || 0))
    .slice(0, 5);

  const cardCls = "rounded-2xl bg-surface backdrop-blur-md shadow-[0_12px_30px_rgba(15,23,42,0.08)] hover:shadow-[0_18px_45px_rgba(15,23,42,0.12)] transition-shadow border-2 border-token";
  const tableWrapCls = "mt-5 overflow-hidden rounded-xl bg-surface-strong/70 backdrop-blur-md border border-token";
  const tableGridCls = "grid w-full grid-cols-[126px_minmax(0,1.2fr)_minmax(0,1fr)_112px_96px]";
  const tableHeadCls = `${tableGridCls} text-xs font-semibold text-muted bg-surface-strong/80 border-b border-token`;
  const tableRowCls = `${tableGridCls} text-sm text-main border-b border-token`;
  const searchCls = "h-10 rounded-xl px-4 bg-surface-strong border border-token shadow-sm text-main placeholder:text-muted outline-none focus:ring-2 focus:ring-[#2F8DCD]/30 focus:border-[#2F8DCD]/40";
  const selectPillCls = "h-10 w-full rounded-xl px-4 pr-10 bg-surface-strong border border-token bg-kpi text-main font-semibold appearance-none outline-none shadow-sm focus:ring-2 focus:ring-[#2F8DCD]/30 focus:border-[#2F8DCD]/40";
  const statusBtnCls = "inline-flex items-center px-3 py-1 rounded-full text-xs font-semibold border hover:brightness-95 active:translate-y-[1px] transition";
  const statusChipCls = (status) => {
    if (status === "completed") {
      return "bg-emerald-600 text-white border-emerald-700 shadow-sm dark:bg-emerald-400 dark:text-[#072236] dark:border-emerald-300";
    }
    if (status === "processing") {
      return "bg-[#2f8dcd] text-white border-[#2779b3] shadow-sm dark:bg-[#56abde] dark:text-[#072236] dark:border-[#8ed0f0]";
    }
    if (status === "submitted") {
      return "bg-yellow-400 text-black border-yellow-500 shadow-sm dark:bg-amber-300 dark:text-black dark:border-amber-200";
    }
    if (status === "rejected") {
      return "bg-rose-400 text-black border-rose-500 shadow-sm dark:bg-rose-300 dark:text-black dark:border-rose-200";
    }
    if (status === "endorsed") {
      return "bg-violet-500 text-white border-violet-600 shadow-sm dark:bg-violet-400 dark:text-[#072236] dark:border-violet-300";
    }
    return "bg-slate-100 text-slate-700 border-slate-300 shadow-sm dark:bg-slate-300/18 dark:text-slate-100 dark:border-slate-300/35";
  };

  return (
    <div className="min-h-screen w-full bg-app">
      <Menubar userName={userName} />

      <main className="min-h-screen bg-app layout-main">
        <div className="max-w-[1200px] mx-auto px-8 py-8">
          <div className="flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">
            <div>
              <h1 className="text-4xl font-bold text-title">Interviewer Hub</h1>
              <p className="mt-2 text-sm text-muted">Upload interviews, review transcripts, and continue the process</p>
            </div>
            <div className="sm:pt-1 flex items-start justify-between sm:justify-end gap-3">
              <div className="flex flex-col">
                <span className="text-lg font-semibold text-main leading-none">Click Analyze</span>
                <span className="mt-1 text-xs text-muted">to upload and analyze an interview</span>
              </div>
            </div>
          </div>

          <div className="mt-10 flex flex-wrap items-center gap-4">
            <SelectPill name="role" value={filters.role} onChange={onChange} options={roleOptions} className="w-[170px]" selectCls={selectPillCls} />
            <SelectPill
              name="status"
              value={filters.status}
              onChange={onChange}
              options={["All Status", "Processing", "Completed", "Endorsed", "Rejected"]}
              className="w-[170px]"
              selectCls={selectPillCls}
            />
            <SelectPill name="date" value={filters.date} onChange={onChange} options={["Date", "This Week", "This Month", "This Year"]} className="w-[150px]" selectCls={selectPillCls} />
            <input name="search" value={filters.search} onChange={onChange} placeholder="Search candidate or job..." className={`${searchCls} w-full sm:w-[320px]`} />
          </div>

          <div className="mt-10 grid grid-cols-1 lg:grid-cols-3 gap-6">
            <section className={`lg:col-span-2 p-6 ${cardCls}`}>
              <h3 className="text-xl font-semibold text-main">Interview Queue</h3>
              <div className={tableWrapCls}>
                <div className={tableHeadCls}>
                  <div className="px-4 py-3 text-left">File</div>
                  <div className="px-4 py-3 text-left">Candidate</div>
                  <div className="px-4 py-3 text-left">Role</div>
                  <div className="px-3 py-3 text-center">Status</div>
                  <div className="px-3 py-3 text-center">Date</div>
                </div>

                {filteredRows.map((r) => (
                  <div key={r.id} className={tableRowCls}>
                    <div className="px-4 py-5 min-w-0">
                      {r.file && r.file !== "No file" ? (
                        <button
                          type="button"
                          onClick={() => downloadResume(r)}
                          className="inline-flex min-h-8 w-full max-w-[104px] items-center justify-center rounded-full border border-[#3f91c4] bg-[#4ca6d9] px-2 py-1 text-center text-[11px] font-semibold leading-4 text-white shadow-sm transition hover:bg-[#3e97cb] dark:border-sky-300/20 dark:bg-[#214f79] dark:text-sky-100 dark:hover:bg-[#1c4368]"
                          title="Download resume"
                        >
                          Download resume
                        </button>
                      ) : (
                        <span className="text-muted">No file</span>
                      )}
                    </div>
                    <div className="px-4 py-5 min-w-0 break-words text-left font-medium leading-6">
                      {r.candidate}
                      {r.displayStatus === "Rejected" && r.rejectionReason && (
                        <div className="mt-2 rounded-md border border-rose-300 bg-rose-100/85 px-2.5 py-1.5 text-xs font-medium leading-5 text-rose-800 dark:border-rose-300/45 dark:bg-rose-900/35 dark:text-rose-100">
                          <span className="font-semibold">Rejection note:</span> {r.rejectionReason}
                        </div>
                      )}
                      <div className="mt-2 flex flex-wrap items-center gap-2">
                        <button
                          type="button"
                          onClick={() => openCaseNotes(r)}
                          className="inline-flex items-center rounded-full border border-[#7db8db] bg-[#e9f5fd] px-2.5 py-1 text-[11px] font-semibold text-[#1d5f87] transition hover:bg-[#d8edf9]"
                        >
                          Case Notes ({Number(r.noteCount || 0)})
                        </button>
                        {r.lastNoteAt ? (
                          <span className="text-[11px] text-slate-500">
                            Updated {new Date(r.lastNoteAt).toLocaleDateString()}
                          </span>
                        ) : null}
                      </div>
                    </div>
                    <div className="px-4 py-5 min-w-0 break-words text-left text-muted leading-6">{r.role}</div>
                    <div className="px-3 py-5 text-center">
                      {r.displayStatus === "Completed" && (
                        <button
                          type="button"
                          onClick={() => goToDetails(r)}
                          className={`${statusBtnCls} min-w-[96px] justify-center ${statusChipCls("completed")}`}
                        >
                          Completed
                        </button>
                      )}
                      {r.displayStatus === "Endorsed" && (
                        <button
                          type="button"
                          onClick={() => goToDetails(r)}
                          className={`${statusBtnCls} min-w-[96px] justify-center ${statusChipCls("endorsed")}`}
                        >
                          Endorsed
                        </button>
                      )}

                      {r.displayStatus === "Analyze" && (
                        <button
                          type="button"
                          className={`${statusBtnCls} min-w-[96px] justify-center ${statusChipCls("submitted")}`}
                          onClick={() => goToUpload(r)}
                        >
                          Analyze
                        </button>
                      )}

                      {r.displayStatus === "Processing" && (
                        <button
                          type="button"
                          className={`${statusBtnCls} min-w-[96px] justify-center ${statusChipCls("processing")}`}
                          onClick={() => goToUpload(r)}
                          title="Return to upload screen"
                        >
                          Processing
                        </button>
                      )}

                      {r.displayStatus === "Rejected" && (
                        <span className={`inline-flex min-w-[96px] items-center justify-center rounded-full px-3 py-1 text-xs font-semibold ${statusChipCls("rejected")}`}>Rejected</span>
                      )}
                    </div>

                    <div className="px-3 py-5 text-center text-xs font-medium text-main sm:text-sm">{r.appliedAt ? r.appliedAt.toLocaleDateString() : "--"}</div>
                  </div>
                ))}
              </div>
            </section>

            <div className="space-y-6">
              <section className={`p-6 ${cardCls}`}>
                <h3 className="text-lg font-semibold text-main">Progress Snapshot</h3>
                <p className="mt-1 text-xs text-muted">Quick look at interview progress.</p>

                <div className="mt-4 grid grid-cols-2 gap-3">
                  <MetricTile label="Analyze" value={submittedCount} color="text-amber-600" />
                  <MetricTile label="Processing" value={processingCount} color="text-sky-600" />
                  <MetricTile label="Completed" value={completedCount} color="text-emerald-600" />
                  <MetricTile label="Endorsed" value={endorsedCount} color="text-violet-700" />
                  <MetricTile label="Rejected" value={rejectedCount} color="text-rose-600" />
                </div>

                <div className="mt-4 flex flex-wrap gap-2">
                  <span className="rounded-full bg-sky-100 text-sky-800 px-3 py-1 text-xs font-semibold border border-sky-200">
                    Completion Rate: {completionRate}%
                  </span>
                  <span className="rounded-full bg-amber-100 text-amber-800 px-3 py-1 text-xs font-semibold border border-amber-200">
                    Backlog: {backlog}
                  </span>
                </div>
              </section>

              <section ref={nextCandidatesRef} className={`p-6 ${cardCls}`}>
                <h3 className="text-lg font-semibold text-main">Next Candidates</h3>
                <p className="mt-1 text-xs text-muted">Oldest pending items to handle next.</p>

                <div className="mt-4 space-y-3">
                  {priorityList.length ? (
                    priorityList.map((r) => (
                      <button
                        key={r.id}
                        type="button"
                        onClick={() => goToUpload(r)}
                        className="w-full text-left rounded-xl bg-surface-strong border border-token px-3 py-2 hover:brightness-[0.98]"
                      >
                        <p className="text-sm font-semibold text-main">{r.candidate}</p>
                        <p className="text-xs text-muted">{r.role}</p>
                      </button>
                    ))
                  ) : (
                    <p className="text-sm text-muted">No pending candidates right now.</p>
                  )}
                </div>
              </section>

              <section className={`p-6 ${cardCls}`}>
                <h3 className="text-lg font-semibold text-main">Team Notes</h3>
                <p className="mt-1 text-xs text-muted">Simple reminders for smoother review flow.</p>
                <ul className="mt-4 space-y-2 text-sm text-muted">
                  <li>Start with candidates marked <span className="font-medium text-main">Analyze</span>.</li>
                  <li>Open completed interviews and finalize recommendations quickly.</li>
                  <li>Download resume files directly from the queue for cross-checking.</li>
                </ul>
              </section>
            </div>
          </div>
        </div>

        {showNotesModal && selectedNotesRow ? (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 px-4 backdrop-blur-sm">
            <div className="w-full max-w-2xl rounded-2xl border border-token bg-surface p-6 shadow-[0_18px_45px_rgba(15,23,42,0.2)]">
              <div className="flex items-start justify-between gap-4">
                <div>
                  <h3 className="text-xl font-semibold text-main">Case Notes</h3>
                  <p className="mt-1 text-sm text-muted">
                    {selectedNotesRow.candidate} • {selectedNotesRow.role}
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    setShowNotesModal(false);
                    setSelectedNotesRow(null);
                    setCaseNotes([]);
                    setNotesDraft("");
                  }}
                  className="rounded-lg border border-token bg-surface-strong px-3 py-1.5 text-sm text-main hover:brightness-95"
                >
                  Close
                </button>
              </div>

              <div className="mt-4 rounded-xl border border-token bg-surface-strong p-4">
                <label className="mb-2 block text-xs font-semibold uppercase tracking-[0.12em] text-muted">
                  Add Internal Note
                </label>
                <textarea
                  value={notesDraft}
                  onChange={(e) => setNotesDraft(e.target.value)}
                  rows={3}
                  placeholder="Add context, concerns, or follow-up actions..."
                  className="w-full rounded-xl border border-token bg-surface px-3 py-2 text-sm text-main outline-none focus:ring-2 focus:ring-[#2F8DCD]/30"
                />
                <div className="mt-3 flex justify-end">
                  <button
                    type="button"
                    onClick={saveCaseNote}
                    disabled={notesSaving}
                    className="rounded-xl border border-[#2f8dcd] bg-[#2f8dcd] px-4 py-2 text-sm font-semibold text-white hover:brightness-95 disabled:opacity-60"
                  >
                    {notesSaving ? "Saving..." : "Save Note"}
                  </button>
                </div>
              </div>

              <div className="mt-4 max-h-[45vh] space-y-3 overflow-auto pr-1">
                {notesLoading ? (
                  <p className="text-sm text-muted">Loading notes...</p>
                ) : caseNotes.length ? (
                  caseNotes.map((note) => (
                    <div key={note.id} className="rounded-xl border border-token bg-surface-strong p-3">
                      <div className="flex flex-wrap items-center justify-between gap-2 text-xs text-muted">
                        <span>
                          {[note.authorName || "Unknown", note.authorRole || ""].filter(Boolean).join(" • ")}
                        </span>
                        <span>{note.createdAt ? new Date(note.createdAt).toLocaleString() : "--"}</span>
                      </div>
                      <p className="mt-2 whitespace-pre-wrap text-sm text-main">{note.note}</p>
                    </div>
                  ))
                ) : (
                  <p className="text-sm text-muted">No notes yet.</p>
                )}
              </div>
            </div>
          </div>
        ) : null}

      </main>
    </div>
  );
}

function SelectPill({ name, value, onChange, options, className = "", selectCls }) {
  return (
    <div className={`relative ${className}`}>
      <select name={name} value={value} onChange={onChange} className={selectCls}>
        {options.map((o) => (
          <option key={o} value={o}>
            {o}
          </option>
        ))}
      </select>
      <span className="pointer-events-none absolute right-4 top-1/2 -translate-y-1/2 text-main">v</span>
    </div>
  );
}

function MetricTile({ label, value, color }) {
  return (
    <div className="rounded-xl bg-surface-strong border border-token px-3 py-3">
      <p className="text-[11px] uppercase tracking-[0.12em] text-muted">{label}</p>
      <p className={`mt-1 text-xl font-bold ${color}`}>{value}</p>
    </div>
  );
}

