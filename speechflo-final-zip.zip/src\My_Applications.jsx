﻿import { useNavigate } from "react-router-dom";
import { apiUrl } from "./api";
import { useState, useEffect } from "react";

export default function My_Applications() {
  const navigate = useNavigate();

  const [applications, setApplications] = useState([]);
  const [showConfirm, setShowConfirm] = useState(false);
  const [selectedAppId, setSelectedAppId] = useState(null);
  const [userName, setUserName] = useState("");
  const [showRejectNoteModal, setShowRejectNoteModal] = useState(false);
  const [selectedRejectNote, setSelectedRejectNote] = useState("");
  const [showTimelineModal, setShowTimelineModal] = useState(false);
  const [selectedTimelineApp, setSelectedTimelineApp] = useState(null);

  const getJobDetailRoute = (jobId) => {
    const numericId = Number(jobId);
    if (!Number.isFinite(numericId)) return "/jobs";
    return `/jobs/${numericId}`;
  };

  const displayStatus = (status) => {
    if (status === "submitted") return "Submitted";
    if (status === "processing") return "Processing";
    if (status === "completed") return "Completed";
    if (status === "endorsed") return "Endorsed";
    if (status === "rejected") return "Rejected";
    return status;
  };

  const statusChipClass = (status) => {
    if (status === "completed") {
      return "bg-emerald-600 text-white border-emerald-700";
    }
    if (status === "processing") {
      return "bg-sky-600 text-white border-sky-700";
    }
    if (status === "submitted") {
      return "bg-amber-400 text-black border-amber-500";
    }
    if (status === "rejected") {
      return "bg-rose-300 text-black border-rose-400";
    }
    if (status === "endorsed") {
      return "bg-violet-200 text-violet-900 border-violet-300";
    }
    return "bg-slate-100 text-slate-700 border-slate-300";
  };

  const statusProgress = (status) => {
    const key = String(status || "").toLowerCase();
    if (key === "submitted") return 20;
    if (key === "processing") return 50;
    if (key === "completed") return 80;
    if (key === "endorsed") return 100;
    if (key === "rejected") return 100;
    return 0;
  };

  // check if user is logged in, if not force to log in
  useEffect(() => {
    const token = localStorage.getItem("token");
    if (!token) {
      navigate("/login-applicant");
      return;
    }

    // validate token by fetching user info
    fetch(apiUrl("/auth/me"), {
      method: "GET",
      headers: { Authorization: `Bearer ${token}` },
    })
      .then((res) => {
        if (!res.ok) throw new Error("Not authenticated");
        return res.json();
      })
      .then((data) => setUserName(data.firstName))
      .catch(() => {
        localStorage.removeItem("token");
        navigate("/login-applicant");
      });
  }, [navigate]);

  // Fetch user's job applications
  useEffect(() => {
    const token = localStorage.getItem("token");
    if (!token) return;

    fetch(apiUrl("/applications/my"), {
      method: "GET",
      headers: { Authorization: `Bearer ${token}` },
    })
      .then((res) => res.json())
      .then((data) => {
        const mapped = data.map((app) => ({
          id: app.id,
          jobTitle: app.job_title,
          companyName: app.company_name || "N/A",
          dateSubmitted: new Date(app.applied_at).toLocaleDateString(),
          statusRaw: app.status,
          statusLabel: displayStatus(app.status),
          jobRoute: getJobDetailRoute(app.job_id),
          rejectionReason: app.rejection_reason || "",
          timeline: Array.isArray(app.timeline)
            ? app.timeline.map((event) => ({
                id: event.id,
                statusRaw: event.status,
                statusLabel: displayStatus(event.status),
                note: event.note || "",
                actorName: event.actorName || "",
                actorRole: event.actorRole || "",
                createdAt: event.createdAt,
              }))
            : [],
        }));
        setApplications(mapped);
      })
      .catch((err) => {
        console.error("Failed to fetch applications:", err);
      });
  }, []);

  const IconBox = ({ src, alt }) => (
    <div className="w-10 h-10 flex items-center justify-center flex-shrink-0">
      <img src={src} alt={alt} className="w-6 h-6 object-contain" />
    </div>
  );

  const handleWithdrawClick = (id) => {
    setSelectedAppId(id);
    setShowConfirm(true);
  };

 const handleConfirmWithdraw = () => {
  const token = localStorage.getItem("token");
  if (!token) return;

  fetch(apiUrl(`/applications/${selectedAppId}`), {
    method: "DELETE",
    headers: { Authorization: `Bearer ${token}` },
  })
    .then((res) => {
      if (!res.ok) throw new Error("Failed to withdraw application");
      // Remove withdrawn app from state
      setApplications((prev) => prev.filter((app) => app.id !== selectedAppId));
      setShowConfirm(false);
      setSelectedAppId(null);
    })
    .catch((err) => {
      console.error(err);
      alert("Failed to withdraw application. Try again.");
    });
};


  const handleCancelWithdraw = () => {
    setShowConfirm(false);
    setSelectedAppId(null);
  };

  const handleRowClick = (app) => {
    if (!app?.jobRoute) return;
    navigate(app.jobRoute);
  };

  const handleViewRejectNote = (app) => {
    setSelectedRejectNote(app?.rejectionReason || "No rejection note provided.");
    setShowRejectNoteModal(true);
  };

  const handleViewTimeline = (app) => {
    if (!app) return;

    const timeline = Array.isArray(app.timeline) && app.timeline.length
      ? app.timeline
      : [
          {
            id: `fallback-${app.id}`,
            statusRaw: app.statusRaw,
            statusLabel: app.statusLabel,
            note: "Timeline event history is not available for this record yet.",
            actorName: "",
            actorRole: "",
            createdAt: app.dateSubmitted,
          },
        ];

    setSelectedTimelineApp({
      id: app.id,
      jobTitle: app.jobTitle,
      timeline,
    });
    setShowTimelineModal(true);
  };

  //  LOGOUT FUNCTION
  const handleLogout = () => {
    localStorage.removeItem("token");
    navigate("/login-applicant");
  };

  return (
    <div className="min-h-screen flex bg-[#f3f4f6]">
      {/* SIDEBAR */}
      <div className="
          group fixed top-0 left-0 h-full z-30
          transition-all duration-300
          w-16 hover:w-56
          shadow-xl bg-[#77bce1]
        ">
        <div className="flex flex-col h-full py-6">
          <div className="px-3 mb-10 flex justify-center group-hover:justify-start">
            <img
              src="/AvantePH_logo.png"
              alt="AvantePH"
              className="hidden group-hover:block h-16 w-auto"
            />
          </div>

          <div className="flex flex-col gap-3 px-3">
            <button
              onClick={() => navigate("/My_Profile")}
              className="flex items-center gap-3 text-[#0b1440] text-sm hover:bg-white/40 rounded-lg transition"
            >
              <IconBox src="/profile_icon.png" alt="My Profile" />
              <span className="hidden group-hover:block whitespace-nowrap">My Profile</span>
            </button>

            <button
              onClick={() => navigate("/my_applications")}
              className="flex items-center gap-3 text-[#0b1440] text-sm hover:bg-white/40 rounded-lg transition"
            >
              <IconBox src="/my_applications_icon.png" alt="My Applications" />
              <span className="hidden group-hover:block whitespace-nowrap">My Applications</span>
            </button>

            <button
              onClick={() => navigate("/jobs")}
              className="flex items-center gap-3 text-[#0b1440] text-sm hover:bg-white/40 rounded-lg transition"
            >
              <IconBox src="/briefcase.png" alt="Browse Jobs" />
              <span className="hidden group-hover:block whitespace-nowrap">Browse Jobs</span>
            </button>
          </div>

          {/* USER GREETING + LOGOUT */}
          <div className="mt-auto px-4 flex flex-col gap-2">
            <div className="text-[#0b1440] text-xl text-center group-hover:text-left hidden group-hover:block">
              Hello, <span className="font-semibold">{userName || "User"}</span>
            </div>

            <button
              onClick={handleLogout}
              className="w-full flex items-center gap-3 text-[#0b1440] text-sm hover:bg-white/40 rounded-lg transition"
            >
              <IconBox src="/logout_icon.png" alt="Logout" />
              <span className="hidden group-hover:block whitespace-nowrap">Log Out</span>
            </button>
          </div>
        </div>
      </div>

      {/* MAIN CONTENT */}
      <div className="flex-1 ml-16 group-hover:ml-56 transition-all duration-300 px-4 sm:px-6 lg:px-8 py-8">
        <div className="max-w-5xl mx-auto min-h-[calc(100vh-4rem)] flex flex-col">
          <h1 className="text-xl sm:text-2xl font-semibold mb-6 text-[#0b1440]">My Applications</h1>

          <div className="bg-white rounded-xl border border-[#2475AF]/60 p-6 shadow mb-6">
            <h2 className="font-semibold mb-4 text-[#0b1440]">Submissions</h2>

            {applications.length === 0 ? (
              <p className="text-sm text-gray-600">You have not submitted any applications yet.</p>
            ) : (
              <div className="overflow-x-auto rounded-lg border border-[#2475AF]/50">
                <table className="min-w-full text-sm">
                  <thead className="bg-[#e9f4fb] text-[#0b1440]">
                    <tr>
                      <th className="px-4 py-3 text-left font-semibold">Role</th>
                      <th className="px-4 py-3 text-left font-semibold">Company Name</th>
                      <th className="px-4 py-3 text-left font-semibold">Date Submitted</th>
                      <th className="px-4 py-3 text-left font-semibold">Status</th>
                      <th className="px-4 py-3 text-left font-semibold">Action</th>
                    </tr>
                  </thead>
                  <tbody>
                    {applications.map((app) => (
                      <tr
                        key={app.id}
                        onClick={() => handleRowClick(app)}
                        onKeyDown={(e) => {
                          if (e.key === "Enter" || e.key === " ") {
                            e.preventDefault();
                            handleRowClick(app);
                          }
                        }}
                        tabIndex={0}
                        className="border-t border-[#d2e8f6] bg-white hover:bg-[#f5fbff] focus:outline-none focus:bg-[#f5fbff] cursor-pointer"
                        title="Open related job posting"
                      >
                        <td className="px-4 py-3 font-medium text-[#0b1440]">{app.jobTitle}</td>
                        <td className="px-4 py-3 text-[#334155]">{app.companyName}</td>
                        <td className="px-4 py-3 text-[#334155]">{app.dateSubmitted}</td>
                        <td className="px-4 py-3">
                          <span className={`inline-flex items-center rounded-full border px-3 py-1 text-xs font-semibold ${statusChipClass(app.statusRaw)}`}>
                            {app.statusLabel}
                          </span>
                          <div className="mt-2 h-1.5 w-28 rounded-full bg-slate-200">
                            <div
                              className={`h-1.5 rounded-full ${app.statusRaw === "rejected" ? "bg-rose-500" : "bg-sky-500"}`}
                              style={{ width: `${statusProgress(app.statusRaw)}%` }}
                            />
                          </div>
                          <div className="mt-1 text-[10px] text-slate-500">
                            Progress {statusProgress(app.statusRaw)}%
                          </div>
                        </td>
                        <td className="px-4 py-3">
                          <div className="flex flex-wrap items-center gap-2">
                            {app.statusRaw === "rejected" && (
                              <button
                                type="button"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  handleViewRejectNote(app);
                                }}
                                className="
                                  px-3 py-1.5 rounded-md
                                  bg-rose-100 border border-rose-300 text-rose-800 text-xs font-semibold
                                  hover:bg-rose-200 active:scale-95
                                  transition
                                "
                              >
                                View Note
                              </button>
                            )}
                            <button
                              type="button"
                              onClick={(e) => {
                                e.stopPropagation();
                                handleViewTimeline(app);
                              }}
                              className="
                                px-3 py-1.5 rounded-md
                                bg-sky-100 border border-sky-300 text-sky-800 text-xs font-semibold
                                hover:bg-sky-200 active:scale-95
                                transition
                              "
                            >
                              View Timeline
                            </button>
                            <button
                              type="button"
                              onClick={(e) => {
                                e.stopPropagation();
                                handleWithdrawClick(app.id);
                              }}
                              className="
                                px-3 py-1.5 rounded-md
                                bg-red-600 text-white text-xs font-semibold
                                hover:bg-red-700 active:scale-95
                                transition
                              "
                            >
                              Withdraw
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>

          <div className="bg-white rounded-xl border border-[#2475AF]/60 p-6 shadow mb-8">
            <h2 className="font-semibold mb-2 text-[#0b1440]">Help</h2>
            <p className="text-sm text-gray-700">
              If you have questions about your application, contact{" "}
              <span className="font-medium text-[#2475AF]">speechflo@gmail.com</span>
            </p>
          </div>

          <div className="mt-auto text-center text-xs text-[#0b1440]/70">(c) 2026 AvantePH</div>
        </div>
      </div>

      {/* CONFIRMATION MODAL */}
      {showConfirm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-sm">
          <div className="bg-white rounded-xl w-full max-w-sm p-6 shadow-xl">
            <h3 className="text-lg font-semibold text-[#0b1440] mb-3">Withdraw Application</h3>
            <p className="text-sm text-gray-600 mb-6">
              Are you sure you want to withdraw this application? This action cannot be undone.
            </p>

            <div className="flex justify-end gap-3">
              <button
                onClick={handleCancelWithdraw}
                className="px-4 py-2 rounded-lg text-sm border border-gray-300 hover:bg-gray-100 transition"
              >
                Cancel
              </button>
              <button
                onClick={handleConfirmWithdraw}
                className="px-4 py-2 rounded-lg text-sm bg-red-600 text-white font-semibold hover:bg-red-700 transition"
              >
                Yes, Withdraw
              </button>
            </div>
          </div>
        </div>
      )}

      {/* REJECTION NOTE MODAL */}
      {showRejectNoteModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-sm">
          <div className="bg-white rounded-xl w-full max-w-md p-6 shadow-xl">
            <h3 className="text-lg font-semibold text-[#0b1440] mb-3">Rejection Note</h3>
            <p className="text-sm text-gray-700 whitespace-pre-wrap leading-relaxed">{selectedRejectNote}</p>
            <div className="flex justify-end mt-6">
              <button
                onClick={() => setShowRejectNoteModal(false)}
                className="px-4 py-2 rounded-lg text-sm border border-gray-300 hover:bg-gray-100 transition"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* TIMELINE MODAL */}
      {showTimelineModal && selectedTimelineApp && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-sm p-4">
          <div className="bg-white rounded-xl w-full max-w-2xl p-6 shadow-xl max-h-[80vh] overflow-auto">
            <h3 className="text-lg font-semibold text-[#0b1440] mb-1">
              Application Timeline
            </h3>
            <p className="text-sm text-slate-600 mb-4">
              {selectedTimelineApp.jobTitle}
            </p>

            <div className="space-y-3">
              {selectedTimelineApp.timeline.map((event) => (
                <div
                  key={`${event.id}-${event.createdAt}`}
                  className="rounded-lg border border-[#d2e8f6] bg-[#f8fcff] p-4"
                >
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <span className={`inline-flex items-center rounded-full border px-3 py-1 text-xs font-semibold ${statusChipClass(event.statusRaw)}`}>
                      {event.statusLabel}
                    </span>
                    <span className="text-xs text-slate-500">
                      {event.createdAt ? new Date(event.createdAt).toLocaleString() : "--"}
                    </span>
                  </div>
                  <p className="mt-2 text-sm text-slate-700">
                    {event.note || "No details provided."}
                  </p>
                  {(event.actorName || event.actorRole) && (
                    <p className="mt-1 text-xs text-slate-500">
                      By: {[event.actorName, event.actorRole].filter(Boolean).join(" • ")}
                    </p>
                  )}
                </div>
              ))}
            </div>

            <div className="flex justify-end mt-6">
              <button
                onClick={() => {
                  setShowTimelineModal(false);
                  setSelectedTimelineApp(null);
                }}
                className="px-4 py-2 rounded-lg text-sm border border-gray-300 hover:bg-gray-100 transition"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}


