import { useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { apiUrl } from "./api";
import { authHeaders, clearSession, getToken } from "./session";

const tabs = [
  ["overview", "Overview"],
  ["accounts", "Accounts"],
  ["jobs", "Jobs"],
  ["reports", "Reports"],
  ["knowledge", "Knowledge Base"],
  ["requests", "Requests"],
  ["prompts", "Prompts"],
  ["audit", "Audit Logs"],
];

function emptyAccount() {
  return {
    id: null,
    firstName: "",
    lastName: "",
    email: "",
    role: "recruiter",
    department: "",
    password: "",
    isActive: true,
    passwordResetRequired: true,
  };
}

function emptyJob() {
  return {
    id: null,
    title: "",
    description: "",
    companyName: "",
    employmentType: "",
    workSetup: "",
    city: "",
    region: "",
    isActive: true,
    lifecycleStatus: "published",
    publishedAt: null,
    closedAt: null,
    skills: [{ name: "", category: "", required: true, weight: 1 }],
  };
}

function emptyKbRole() {
  return {
    id: null,
    kbRoleKey: "",
    name: "",
    industry: "",
    level: "",
    policy: {
      highThreshold: 80,
      moderateThreshold: 60,
      lowConfidenceThreshold: 0.7,
      criticalSkillPenalty: 15,
    },
    skills: [{ name: "", aliasesText: "", category: "", required: true, weight: 0.2, isCritical: false }],
  };
}

function promptDraft(prompt = null) {
  return {
    id: prompt?.id || null,
    versionLabel: prompt?.versionLabel || `draft-${Date.now()}`,
    notes: prompt?.notes || "",
    status: prompt?.status || "draft",
    master_prompt: prompt?.master_prompt || "",
    tasks: { ...(prompt?.tasks || {}) },
  };
}

function accountToForm(account) {
  return {
    id: account.id,
    firstName: account.firstName || "",
    lastName: account.lastName || "",
    email: account.email || "",
    role: account.role || "recruiter",
    department: account.department || "",
    password: "",
    isActive: Boolean(account.isActive),
    passwordResetRequired: Boolean(account.passwordResetRequired),
  };
}

function jobToForm(job) {
  return {
    id: job?.id || null,
    title: job?.title || "",
    description: job?.description || "",
    companyName: job?.companyName || "",
    employmentType: job?.employmentType || "",
    workSetup: job?.workSetup || "",
    city: job?.city || "",
    region: job?.region || "",
    isActive: Boolean(job?.isActive),
    lifecycleStatus: job?.lifecycleStatus || (job?.isActive ? "published" : "closed"),
    publishedAt: job?.publishedAt || null,
    closedAt: job?.closedAt || null,
    skills: (job?.skills || []).length
      ? job.skills.map((skill) => ({
          name: skill.name || "",
          category: skill.category || "",
          required: Boolean(skill.required),
          weight: Number(skill.weight ?? 0),
        }))
      : [{ name: "", category: "", required: true, weight: 1 }],
  };
}

function kbRoleToForm(role) {
  return {
    id: role?.id || null,
    kbRoleKey: role?.kbRoleKey || "",
    name: role?.name || "",
    industry: role?.industry || "",
    level: role?.level || "",
    policy: {
      highThreshold: Number(role?.policy?.highThreshold ?? 80),
      moderateThreshold: Number(role?.policy?.moderateThreshold ?? 60),
      lowConfidenceThreshold: Number(role?.policy?.lowConfidenceThreshold ?? 0.7),
      criticalSkillPenalty: Number(role?.policy?.criticalSkillPenalty ?? 15),
    },
    skills: (role?.skills || []).length
      ? role.skills.map((skill) => ({
          name: skill.name || "",
          aliasesText: Array.isArray(skill.aliases) ? skill.aliases.join(", ") : "",
          category: skill.category || "",
          required: Boolean(skill.required),
          weight: Number(skill.weight ?? 0),
          isCritical: Boolean(skill.isCritical),
        }))
      : [{ name: "", aliasesText: "", category: "", required: true, weight: 0.2, isCritical: false }],
  };
}

function formatDateTime(value) {
  if (!value) return "--";
  return new Date(value).toLocaleString();
}

function shortDay(value) {
  return new Date(value).toLocaleDateString(undefined, { month: "short", day: "numeric" });
}

function requestStatusClass(status = "") {
  if (status === "approved") return "bg-emerald-100 text-emerald-800 border-emerald-200";
  if (status === "rejected") return "bg-rose-100 text-rose-800 border-rose-200";
  return "bg-amber-100 text-amber-800 border-amber-200";
}

export default function AdminDashboard() {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState("overview");
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [notice, setNotice] = useState("");
  const [secretNotice, setSecretNotice] = useState("");
  const [adminName, setAdminName] = useState("Admin");

  const [overview, setOverview] = useState(null);
  const [accounts, setAccounts] = useState([]);
  const [accountQuery, setAccountQuery] = useState("");
  const [accountForm, setAccountForm] = useState(emptyAccount());

  const [jobs, setJobs] = useState([]);
  const [jobForm, setJobForm] = useState(emptyJob());
  const [adminReports, setAdminReports] = useState(null);

  const [kbRoles, setKbRoles] = useState([]);
  const [kbForm, setKbForm] = useState(emptyKbRole());

  const [prompts, setPrompts] = useState([]);
  const [promptForm, setPromptForm] = useState(promptDraft());

  const [changeRequests, setChangeRequests] = useState([]);
  const [requestStatusFilter, setRequestStatusFilter] = useState("pending");
  const [selectedRequestId, setSelectedRequestId] = useState(null);
  const [reviewNotes, setReviewNotes] = useState({});
  const [requestActionId, setRequestActionId] = useState(null);

  const [auditLogs, setAuditLogs] = useState([]);

  const accountResults = useMemo(() => {
    const q = accountQuery.trim().toLowerCase();
    if (!q) return accounts;
    return accounts.filter((account) =>
      [account.firstName, account.lastName, account.email, account.role, account.department]
        .join(" ")
        .toLowerCase()
        .includes(q)
    );
  }, [accounts, accountQuery]);

  const sortedRequests = useMemo(
    () =>
      [...changeRequests].sort(
        (a, b) => new Date(b.submittedAt || 0).getTime() - new Date(a.submittedAt || 0).getTime()
      ),
    [changeRequests]
  );
  const selectedRequest = useMemo(
    () => sortedRequests.find((request) => request.id === selectedRequestId) || null,
    [sortedRequests, selectedRequestId]
  );

  async function readApiResponse(res) {
    const text = await res.text();
    if (!text) return null;

    try {
      return JSON.parse(text);
    } catch {
      return { message: text };
    }
  }

  async function fetchJson(path, options = {}) {
    const res = await fetch(apiUrl(path), {
      ...options,
      headers: authHeaders(options.headers || {}),
    });
    const data = await readApiResponse(res);
    if (!res.ok) {
      throw new Error(data?.message || data?.error || `Request failed: ${res.status}`);
    }
    return data;
  }

  async function refreshAll() {
    const labels = [
      "overview",
      "accounts",
      "jobs",
      "reports",
      "knowledge base",
      "change requests",
      "prompts",
      "audit logs",
    ];
    const results = await Promise.allSettled([
      fetchJson("/admin/overview"),
      fetchJson("/admin/accounts"),
      fetchJson("/admin/jobs"),
      fetchJson("/admin/reports"),
      fetchJson("/admin/knowledgebase/roles"),
      fetchJson(`/change-requests?status=${encodeURIComponent(requestStatusFilter)}&limit=200`),
      fetchJson("/admin/prompts"),
      fetchJson("/admin/audit-logs?limit=100"),
    ]);

    const failures = [];

    if (results[0].status === "fulfilled") setOverview(results[0].value);
    else failures.push(labels[0]);

    if (results[1].status === "fulfilled") setAccounts(results[1].value);
    else failures.push(labels[1]);

    if (results[2].status === "fulfilled") {
      const nextJobs = results[2].value;
      setJobs(nextJobs);
      if (!jobForm.id && nextJobs[0]) setJobForm(jobToForm(nextJobs[0]));
    } else {
      failures.push(labels[2]);
    }

    if (results[3].status === "fulfilled") {
      setAdminReports(results[3].value);
    } else {
      failures.push(labels[3]);
    }

    if (results[4].status === "fulfilled") {
      const nextKbRoles = results[4].value;
      setKbRoles(nextKbRoles);
      if (!kbForm.id && nextKbRoles[0]) setKbForm(kbRoleToForm(nextKbRoles[0]));
    } else {
      failures.push(labels[4]);
    }

    if (results[5].status === "fulfilled") {
      setChangeRequests(results[5].value);
    } else {
      failures.push(labels[5]);
    }

    if (results[6].status === "fulfilled") {
      const nextPrompts = results[6].value;
      setPrompts(nextPrompts);
      if ((!promptForm.id && nextPrompts[0]) || (promptForm.id && !nextPrompts.find((item) => item.id === promptForm.id))) {
        setPromptForm(promptDraft(nextPrompts[0] || null));
      }
    } else {
      failures.push(labels[6]);
    }

    if (results[7].status === "fulfilled") {
      setAuditLogs(results[7].value);
    } else {
      failures.push(labels[7]);
    }

    if (failures.length) {
      throw new Error(`Some admin data failed to load: ${failures.join(", ")}.`);
    }
  }

  useEffect(() => {
    const token = getToken();
    if (!token) {
      navigate("/admin-login", { replace: true });
      return;
    }

    let alive = true;

    async function boot() {
      try {
        const me = await fetchJson("/auth/me");
        if (me.role !== "admin") {
          clearSession();
          navigate("/admin-login", { replace: true });
          return;
        }
        if (!alive) return;
        setAdminName(me.firstName || "Admin");
        try {
          await refreshAll();
        } catch (refreshErr) {
          console.error("[AdminDashboard] refresh error:", refreshErr);
          if (alive) {
            setNotice(refreshErr.message || "Some admin data failed to load.");
          }
        }
      } catch (err) {
        console.error("[AdminDashboard] boot error:", err);
        clearSession();
        navigate("/admin-login", { replace: true });
      } finally {
        if (alive) setLoading(false);
      }
    }

    boot();
    return () => {
      alive = false;
    };
  }, [navigate]);

  useEffect(() => {
    if (!notice) return undefined;
    const timer = window.setTimeout(() => setNotice(""), 3500);
    return () => window.clearTimeout(timer);
  }, [notice]);

  useEffect(() => {
    if (loading) return;
    let alive = true;
    (async () => {
      try {
        await refreshAll();
      } catch (err) {
        if (alive) setNotice(err.message || "Failed to refresh admin data.");
      }
    })();
    return () => {
      alive = false;
    };
  }, [requestStatusFilter]);

  useEffect(() => {
    if (!sortedRequests.length) {
      if (selectedRequestId !== null) setSelectedRequestId(null);
      return;
    }

    const selectedStillVisible = sortedRequests.some((request) => request.id === selectedRequestId);
    if (selectedStillVisible) return;

    const firstPending = sortedRequests.find((request) => request.status === "pending");
    setSelectedRequestId(firstPending?.id || sortedRequests[0].id);
  }, [sortedRequests, selectedRequestId]);

  function logout() {
    clearSession();
    navigate("/admin-login", { replace: true });
  }

  async function saveAccount(e) {
    e.preventDefault();
    setSaving(true);
    setSecretNotice("");
    try {
      const payload = {
        firstName: accountForm.firstName,
        lastName: accountForm.lastName,
        email: accountForm.email,
        role: accountForm.role,
        department: accountForm.department,
        isActive: accountForm.isActive,
        passwordResetRequired: accountForm.passwordResetRequired,
      };
      const data = await fetchJson(accountForm.id ? `/admin/accounts/${accountForm.id}` : "/admin/accounts", {
        method: accountForm.id ? "PATCH" : "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(accountForm.id ? payload : { ...payload, password: accountForm.password }),
      });
      await refreshAll();
      setAccountForm(emptyAccount());
      setNotice(data.message || "Account saved.");
      if (data.temporaryPassword) setSecretNotice(`Temporary password: ${data.temporaryPassword}`);
    } catch (err) {
      setNotice(err.message);
    } finally {
      setSaving(false);
    }
  }

  async function resetAccountPassword(id) {
    setSaving(true);
    try {
      const data = await fetchJson(`/admin/accounts/${id}/reset-password`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({}),
      });
      await refreshAll();
      setNotice(data.message || "Password reset.");
      setSecretNotice(`Temporary password: ${data.temporaryPassword}`);
    } catch (err) {
      setNotice(err.message);
    } finally {
      setSaving(false);
    }
  }

  async function saveJob(e) {
    e.preventDefault();
    setSaving(true);
    try {
      const payload = {
        title: jobForm.title,
        description: jobForm.description,
        companyName: jobForm.companyName,
        employmentType: jobForm.employmentType,
        workSetup: jobForm.workSetup,
        city: jobForm.city,
        region: jobForm.region,
        lifecycleStatus: jobForm.lifecycleStatus,
        isActive: jobForm.lifecycleStatus === "published",
        skills: jobForm.skills
          .filter((skill) => String(skill.name || "").trim())
          .map((skill) => ({
            name: skill.name,
            category: skill.category,
            required: Boolean(skill.required),
            weight: Number(skill.weight ?? 0),
          })),
      };
      const data = await fetchJson(jobForm.id ? `/admin/jobs/${jobForm.id}` : "/admin/jobs", {
        method: jobForm.id ? "PATCH" : "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      await refreshAll();
      setNotice(data.message || "Job saved.");
    } catch (err) {
      setNotice(err.message);
    } finally {
      setSaving(false);
    }
  }

  async function saveKbRole(e) {
    e.preventDefault();
    setSaving(true);
    try {
      const payload = {
        kbRoleKey: kbForm.kbRoleKey,
        name: kbForm.name,
        industry: kbForm.industry,
        level: kbForm.level,
        policy: {
          highThreshold: Number(kbForm.policy.highThreshold),
          moderateThreshold: Number(kbForm.policy.moderateThreshold),
          lowConfidenceThreshold: Number(kbForm.policy.lowConfidenceThreshold),
          criticalSkillPenalty: Number(kbForm.policy.criticalSkillPenalty),
        },
        skills: kbForm.skills
          .filter((skill) => String(skill.name || "").trim())
          .map((skill) => ({
            name: skill.name,
            aliases: String(skill.aliasesText || "")
              .split(",")
              .map((item) => item.trim())
              .filter(Boolean),
            category: skill.category,
            required: Boolean(skill.required),
            weight: Number(skill.weight ?? 0),
            isCritical: Boolean(skill.isCritical),
          })),
      };
      const data = await fetchJson(kbForm.id ? `/admin/knowledgebase/roles/${kbForm.id}` : "/admin/knowledgebase/roles", {
        method: kbForm.id ? "PATCH" : "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      await refreshAll();
      setNotice(data.message || "Knowledge base saved.");
    } catch (err) {
      setNotice(err.message);
    } finally {
      setSaving(false);
    }
  }

  async function savePrompt(e) {
    e.preventDefault();
    setSaving(true);
    try {
      const payload = {
        versionLabel: promptForm.versionLabel,
        notes: promptForm.notes,
        master_prompt: promptForm.master_prompt,
        tasks: promptForm.tasks,
      };
      const data = await fetchJson(promptForm.id ? `/admin/prompts/${promptForm.id}` : "/admin/prompts", {
        method: promptForm.id ? "PATCH" : "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      await refreshAll();
      setNotice(data.message || "Prompt draft saved.");
    } catch (err) {
      setNotice(err.message);
    } finally {
      setSaving(false);
    }
  }

  async function publishPrompt() {
    if (!promptForm.id) {
      setNotice("Save the draft before publishing.");
      return;
    }
    setSaving(true);
    try {
      const data = await fetchJson(`/admin/prompts/${promptForm.id}/publish`, {
        method: "POST",
      });
      await refreshAll();
      setNotice(data.message || "Prompt published.");
    } catch (err) {
      setNotice(err.message);
    } finally {
      setSaving(false);
    }
  }

  async function approveChangeRequest(requestId = selectedRequestId) {
    if (!requestId) {
      setNotice("Select a request first.");
      return;
    }

    setSaving(true);
    setRequestActionId(`approve-${requestId}`);
    try {
      const reviewNote = String(reviewNotes[requestId] || "").trim();
      const data = await fetchJson(`/change-requests/${requestId}/approve`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ reviewNote }),
      });
      await refreshAll();
      setNotice(data.message || "Change request approved.");
      setReviewNotes((prev) => ({ ...prev, [requestId]: "" }));
    } catch (err) {
      setNotice(err.message);
    } finally {
      setSaving(false);
      setRequestActionId(null);
    }
  }

  async function rejectChangeRequest(requestId = selectedRequestId) {
    if (!requestId) {
      setNotice("Select a request first.");
      return;
    }

    const reviewNote = String(reviewNotes[requestId] || "").trim();
    if (!reviewNote) {
      setNotice("Rejection note is required.");
      return;
    }

    setSaving(true);
    setRequestActionId(`reject-${requestId}`);
    try {
      const data = await fetchJson(`/change-requests/${requestId}/reject`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ reviewNote }),
      });
      await refreshAll();
      setNotice(data.message || "Change request rejected.");
      setReviewNotes((prev) => ({ ...prev, [requestId]: "" }));
    } catch (err) {
      setNotice(err.message);
    } finally {
      setSaving(false);
      setRequestActionId(null);
    }
  }

  if (loading) {
    return (
      <div className="grid min-h-screen place-items-center bg-[#eef7fb] text-[#0b1f3b]">
        <div className="rounded-3xl border border-[#bfd8e7] bg-white px-8 py-6 shadow-[0_20px_60px_rgba(11,31,59,0.12)]">
          Loading admin panel...
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[linear-gradient(180deg,#eef7fb_0%,#dcecf5_45%,#f7fbff_100%)] text-[#0b1f3b]">
      <header className="sticky top-0 z-30 border-b border-[#bfd8e7] bg-white/90 backdrop-blur-xl">
        <div className="mx-auto flex max-w-[1480px] items-center justify-between px-6 py-4">
          <div>
            <div className="text-xs uppercase tracking-[0.18em] text-[#5e8fab]">SpeechFlo Control Panel</div>
            <h1 className="mt-1 text-2xl font-black">Admin Dashboard</h1>
          </div>
          <div className="flex items-center gap-3">
            <div className="rounded-2xl border border-[#d4e6f0] bg-[#f6fbff] px-4 py-2 text-sm">
              Signed in as <span className="font-semibold">{adminName}</span>
            </div>
            <button
              type="button"
              onClick={logout}
              className="rounded-2xl bg-[#0b1f3b] px-5 py-3 text-sm font-semibold text-white hover:bg-[#14375d]"
            >
              Log out
            </button>
          </div>
        </div>
      </header>

      <main className="mx-auto grid max-w-[1480px] gap-6 px-6 py-6 lg:grid-cols-[250px_minmax(0,1fr)]">
        <aside className="rounded-[28px] border border-[#bfd8e7] bg-white p-4 shadow-[0_18px_45px_rgba(11,31,59,0.08)]">
          <div className="px-3 pb-3 text-xs font-semibold uppercase tracking-[0.18em] text-[#5e8fab]">Sections</div>
          <div className="space-y-2">
            {tabs.map(([id, label]) => (
              <button
                key={id}
                type="button"
                onClick={() => setActiveTab(id)}
                className={[
                  "w-full rounded-2xl px-4 py-3 text-left text-sm font-semibold transition",
                  activeTab === id ? "bg-[#0b1f3b] text-white" : "bg-[#f4fbff] text-[#123452] hover:bg-[#eaf6fd]",
                ].join(" ")}
              >
                {label}
              </button>
            ))}
          </div>
        </aside>

        <section className="space-y-6">
          {notice ? <Notice>{notice}</Notice> : null}
          {secretNotice ? <SecretNotice>{secretNotice}</SecretNotice> : null}
          {activeTab === "overview" && (
            <>
              <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
                <Stat label="Admins" value={overview?.usage?.usersByRole?.admin ?? 0} />
                <Stat label="Recruiters" value={overview?.usage?.usersByRole?.recruiter ?? 0} />
                <Stat label="Active Jobs" value={overview?.usage?.activeJobs ?? 0} />
                <Stat label="Reports" value={overview?.usage?.generatedReports ?? 0} />
              </div>
              <div className="grid gap-6 xl:grid-cols-[1.2fr_0.8fr]">
                <Panel title="System Health" subtitle="Runtime readiness and service configuration.">
                  <div className="grid gap-3 sm:grid-cols-2">
                    <Health label="API" ok={overview?.health?.api} />
                    <Health label="Database" ok={overview?.health?.database} />
                    <Health label="OpenAI" ok={overview?.health?.openAiConfigured} />
                    <Health label="Mailer" ok={overview?.health?.mailConfigured} />
                    <Health label="JWT" ok={overview?.health?.jwtConfigured} />
                    <Health label="Node" ok={Boolean(overview?.health?.nodeVersion)} detail={overview?.health?.nodeVersion} />
                  </div>
                </Panel>
                <Panel title="Queue Snapshot" subtitle="Application states and current prompt version.">
                  <RowMetric label="Submitted" value={overview?.usage?.applicationsByStatus?.submitted ?? 0} />
                  <RowMetric label="Processing" value={overview?.usage?.applicationsByStatus?.processing ?? 0} />
                  <RowMetric label="Completed" value={overview?.usage?.applicationsByStatus?.completed ?? 0} />
                  <RowMetric label="Endorsed" value={overview?.usage?.applicationsByStatus?.endorsed ?? 0} />
                  <RowMetric label="Rejected" value={overview?.usage?.applicationsByStatus?.rejected ?? 0} />
                  <div className="mt-4 rounded-2xl border border-[#d4e6f0] bg-[#f8fcff] px-4 py-3 text-sm">
                    Active prompt: <span className="font-semibold">{overview?.usage?.activePromptVersion || "N/A"}</span>
                  </div>
                </Panel>
              </div>
              <Panel title="Recent Usage" subtitle="Applications and completions over the last 14 days.">
                <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-4">
                  {(overview?.recentUsage || []).map((item) => (
                    <div key={String(item.day)} className="rounded-2xl border border-[#d4e6f0] bg-[#fbfeff] p-4">
                      <div className="text-xs uppercase tracking-[0.14em] text-[#6794ae]">{shortDay(item.day)}</div>
                      <div className="mt-3 text-lg font-black">{item.applications}</div>
                      <div className="text-sm text-slate-600">Completed: {item.completed}</div>
                      <div className="text-sm text-slate-600">Endorsed: {item.endorsed ?? 0}</div>
                    </div>
                  ))}
                </div>
              </Panel>
            </>
          )}

          {activeTab === "accounts" && (
            <div className="grid gap-6 xl:grid-cols-[0.9fr_1.1fr]">
              <Panel title="Accounts" subtitle="Inspect users and reset recruiter/admin credentials.">
                <input
                  value={accountQuery}
                  onChange={(e) => setAccountQuery(e.target.value)}
                  placeholder="Search by name, email, role, department"
                  className="mb-4 h-11 w-full rounded-2xl border border-[#c9dfec] bg-[#f9fdff] px-4 text-sm outline-none focus:border-[#7fbce0] focus:ring-2 focus:ring-[#7fbce0]/20"
                />
                <div className="space-y-2">
                  {accountResults.map((account) => (
                    <button
                      key={account.id}
                      type="button"
                      onClick={() => setAccountForm(accountToForm(account))}
                      className="w-full rounded-2xl border border-[#d4e6f0] bg-[#fbfeff] p-4 text-left hover:bg-[#f4fbff]"
                    >
                      <div className="flex items-start justify-between gap-3">
                        <div>
                          <div className="font-semibold">{account.firstName} {account.lastName}</div>
                          <div className="text-sm text-slate-600">{account.email}</div>
                        </div>
                        <Badge>{account.role}</Badge>
                      </div>
                      <div className="mt-2 text-xs text-slate-500">
                        {account.department || "No department"} | {account.lastLoginAt ? formatDateTime(account.lastLoginAt) : "No login yet"}
                      </div>
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          resetAccountPassword(account.id);
                        }}
                        className="mt-3 rounded-xl border border-[#b7d6e8] px-3 py-1.5 text-xs font-semibold text-[#0b4f76] hover:bg-[#edf8ff]"
                      >
                        Reset password
                      </button>
                    </button>
                  ))}
                </div>
              </Panel>

              <Panel title={accountForm.id ? "Edit Account" : "Create Account"} subtitle="Controlled provisioning aligned with admin-only access.">
                <form onSubmit={saveAccount} className="grid gap-4">
                  <div className="grid gap-4 md:grid-cols-2">
                    <TextField label="First Name" value={accountForm.firstName} onChange={(value) => setAccountForm((p) => ({ ...p, firstName: value }))} />
                    <TextField label="Last Name" value={accountForm.lastName} onChange={(value) => setAccountForm((p) => ({ ...p, lastName: value }))} />
                    <TextField label="Email" type="email" value={accountForm.email} onChange={(value) => setAccountForm((p) => ({ ...p, email: value }))} />
                    <SelectField label="Role" value={accountForm.role} onChange={(value) => setAccountForm((p) => ({ ...p, role: value }))} options={["recruiter", "admin", "applicant"]} />
                    <TextField label="Department" value={accountForm.department} onChange={(value) => setAccountForm((p) => ({ ...p, department: value }))} />
                    {!accountForm.id ? (
                      <TextField label="Initial Password" value={accountForm.password} onChange={(value) => setAccountForm((p) => ({ ...p, password: value }))} placeholder="Leave blank to auto-generate" />
                    ) : (
                      <div className="rounded-2xl border border-[#d4e6f0] bg-[#f8fcff] px-4 py-3 text-sm text-slate-600">
                        Use the reset button on the left to issue a temporary password.
                      </div>
                    )}
                  </div>
                  <div className="grid gap-3 md:grid-cols-2">
                    <Toggle label="Account active" checked={accountForm.isActive} onChange={(checked) => setAccountForm((p) => ({ ...p, isActive: checked }))} />
                    <Toggle label="Require password reset" checked={accountForm.passwordResetRequired} onChange={(checked) => setAccountForm((p) => ({ ...p, passwordResetRequired: checked }))} />
                  </div>
                  <div className="flex gap-3">
                    <PrimaryButton disabled={saving}>{saving ? "Saving..." : accountForm.id ? "Save Account" : "Create Account"}</PrimaryButton>
                    <SecondaryButton type="button" onClick={() => setAccountForm(emptyAccount())}>New Form</SecondaryButton>
                  </div>
                </form>
              </Panel>
            </div>
          )}

          {activeTab === "jobs" && (
            <EditorSection
              items={jobs}
              title="Job Postings"
              subtitle="Create and maintain internal job postings plus weighted skill criteria."
              onNew={() => setJobForm(emptyJob())}
              renderItem={(job) => (
                <button key={job.id} type="button" onClick={() => setJobForm(jobToForm(job))} className="w-full rounded-2xl border border-[#d4e6f0] bg-[#fbfeff] p-4 text-left hover:bg-[#f4fbff]">
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <div className="font-semibold">{job.title}</div>
                      <div className="text-sm text-slate-600">{job.companyName || "No company"}</div>
                    </div>
                    <Badge>{job.lifecycleStatus || (job.isActive ? "published" : "closed")}</Badge>
                  </div>
                </button>
              )}
              formTitle={jobForm.id ? "Edit Job" : "Create Job"}
              formBody={
                <form onSubmit={saveJob} className="grid gap-4">
                  <div className="grid gap-4 md:grid-cols-2">
                    <TextField label="Title" value={jobForm.title} onChange={(value) => setJobForm((p) => ({ ...p, title: value }))} />
                    <TextField label="Company" value={jobForm.companyName} onChange={(value) => setJobForm((p) => ({ ...p, companyName: value }))} />
                    <TextField label="Employment Type" value={jobForm.employmentType} onChange={(value) => setJobForm((p) => ({ ...p, employmentType: value }))} />
                    <TextField label="Work Setup" value={jobForm.workSetup} onChange={(value) => setJobForm((p) => ({ ...p, workSetup: value }))} />
                    <TextField label="City" value={jobForm.city} onChange={(value) => setJobForm((p) => ({ ...p, city: value }))} />
                    <TextField label="Region" value={jobForm.region} onChange={(value) => setJobForm((p) => ({ ...p, region: value }))} />
                  </div>
                  <TextAreaField label="Description" value={jobForm.description} onChange={(value) => setJobForm((p) => ({ ...p, description: value }))} />
                  <SelectField
                    label="Lifecycle Status"
                    value={jobForm.lifecycleStatus || "published"}
                    onChange={(value) =>
                      setJobForm((p) => ({
                        ...p,
                        lifecycleStatus: value,
                        isActive: value === "published",
                      }))
                    }
                    options={["draft", "published", "closed"]}
                  />
                  <div className="rounded-2xl border border-[#d4e6f0] bg-[#f8fcff] px-4 py-3 text-xs text-slate-600">
                    Applicant listing visibility: only <span className="font-semibold">published</span> jobs appear in public browsing/apply pages.
                  </div>
                  <SubTitle>Skills</SubTitle>
                  {jobForm.skills.map((skill, index) => (
                    <SkillEditor
                      key={`${skill.name}-${index}`}
                      skill={skill}
                      onChange={(nextSkill) => setJobForm((prev) => ({ ...prev, skills: prev.skills.map((item, i) => (i === index ? nextSkill : item)) }))}
                      onRemove={() => setJobForm((prev) => ({ ...prev, skills: prev.skills.filter((_, i) => i !== index) }))}
                    />
                  ))}
                  <SecondaryButton type="button" onClick={() => setJobForm((prev) => ({ ...prev, skills: [...prev.skills, { name: "", category: "", required: true, weight: 1 }] }))}>
                    Add Skill
                  </SecondaryButton>
                  <PrimaryButton disabled={saving}>{saving ? "Saving..." : jobForm.id ? "Save Job" : "Create Job"}</PrimaryButton>
                </form>
              }
            />
          )}
          {activeTab === "reports" && (
            <Panel title="Reports" subtitle="Admin-tailored reporting across roles, recruiters, and current hiring pipeline.">
              <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
                <Stat label="Generated" value={adminReports?.summary?.generatedReports ?? 0} />
                <Stat label="Completed" value={adminReports?.summary?.completedReports ?? 0} />
                <Stat label="Endorsed" value={adminReports?.summary?.endorsedReports ?? 0} />
                <Stat label="Pipeline" value={(adminReports?.summary?.pipeline?.submitted ?? 0) + (adminReports?.summary?.pipeline?.processing ?? 0)} />
              </div>

              <div className="mt-5 grid gap-4 xl:grid-cols-2">
                <div className="rounded-2xl border border-[#d4e6f0] bg-white p-4">
                  <h3 className="text-base font-semibold">By Recruiter</h3>
                  <div className="mt-3 space-y-2">
                    {(adminReports?.byRecruiter || []).map((item) => (
                      <div key={`${item.recruiterId}-${item.recruiterEmail}`} className="rounded-xl border border-[#e2eef5] bg-[#f9fdff] px-3 py-2 text-sm">
                        <div className="font-medium">{item.recruiterName}</div>
                        <div className="text-xs text-slate-500">{item.recruiterEmail || "--"}</div>
                        <div className="mt-1 text-xs text-slate-600">
                          Reports: <span className="font-semibold">{item.reportsGenerated}</span>
                          {item.lastGeneratedAt ? ` | Last: ${formatDateTime(item.lastGeneratedAt)}` : ""}
                        </div>
                      </div>
                    ))}
                    {!(adminReports?.byRecruiter || []).length ? (
                      <div className="text-sm text-slate-500">No recruiter report activity yet.</div>
                    ) : null}
                  </div>
                </div>

                <div className="rounded-2xl border border-[#d4e6f0] bg-white p-4">
                  <h3 className="text-base font-semibold">By Role</h3>
                  <div className="mt-3 space-y-2">
                    {(adminReports?.byRole || []).map((item) => (
                      <div key={item.roleTitle} className="rounded-xl border border-[#e2eef5] bg-[#f9fdff] px-3 py-2 text-sm">
                        <div className="font-medium">{item.roleTitle}</div>
                        <div className="mt-1 text-xs text-slate-600">
                          Applications: <span className="font-semibold">{item.totalApplications}</span>
                          {" | "}
                          Finalized: <span className="font-semibold">{item.finalizedApplications}</span>
                        </div>
                      </div>
                    ))}
                    {!(adminReports?.byRole || []).length ? (
                      <div className="text-sm text-slate-500">No role data yet.</div>
                    ) : null}
                  </div>
                </div>
              </div>

              <div className="mt-5 rounded-2xl border border-[#d4e6f0] bg-white p-4">
                <h3 className="text-base font-semibold">Recent Reports</h3>
                <div className="mt-3 overflow-auto rounded-xl border border-[#d4e6f0]">
                  <table className="min-w-full text-sm">
                    <thead className="bg-[#f2f9fd] text-[#5e8fab]">
                      <tr>
                        <th className="px-3 py-2 text-left">Applicant</th>
                        <th className="px-3 py-2 text-left">Role</th>
                        <th className="px-3 py-2 text-left">Status</th>
                        <th className="px-3 py-2 text-left">Summary</th>
                        <th className="px-3 py-2 text-left">Updated</th>
                      </tr>
                    </thead>
                    <tbody>
                      {(adminReports?.recent || []).map((item) => (
                        <tr key={item.applicationId} className="border-t border-[#e2eef5]">
                          <td className="px-3 py-2">
                            <div className="font-medium">{item.applicantName}</div>
                            <div className="text-xs text-slate-500">{item.applicantEmail || "--"}</div>
                          </td>
                          <td className="px-3 py-2">{item.roleTitle || "--"}</td>
                          <td className="px-3 py-2">{item.status || "--"}</td>
                          <td className="px-3 py-2 text-slate-600">{item.summary || item.recommendation || "--"}</td>
                          <td className="px-3 py-2 text-slate-500">{formatDateTime(item.reportUpdatedAt)}</td>
                        </tr>
                      ))}
                      {!(adminReports?.recent || []).length ? (
                        <tr>
                          <td colSpan={5} className="px-3 py-4 text-center text-slate-500">
                            No recent reports available.
                          </td>
                        </tr>
                      ) : null}
                    </tbody>
                  </table>
                </div>
              </div>
            </Panel>
          )}
          {activeTab === "knowledge" && (
            <EditorSection
              items={kbRoles}
              title="Knowledge Base"
              subtitle="Role templates, aliases, critical skills, and policy thresholds."
              onNew={() => setKbForm(emptyKbRole())}
              renderItem={(role) => (
                <button key={role.id} type="button" onClick={() => setKbForm(kbRoleToForm(role))} className="w-full rounded-2xl border border-[#d4e6f0] bg-[#fbfeff] p-4 text-left hover:bg-[#f4fbff]">
                  <div className="font-semibold">{role.name}</div>
                  <div className="text-sm text-slate-600">{role.kbRoleKey}</div>
                </button>
              )}
              formTitle={kbForm.id ? "Edit KB Role" : "Create KB Role"}
              formBody={
                <form onSubmit={saveKbRole} className="grid gap-4">
                  <div className="grid gap-4 md:grid-cols-2">
                    <TextField label="Role Name" value={kbForm.name} onChange={(value) => setKbForm((p) => ({ ...p, name: value }))} />
                    <TextField label="Role Key" value={kbForm.kbRoleKey} onChange={(value) => setKbForm((p) => ({ ...p, kbRoleKey: value }))} />
                    <TextField label="Industry" value={kbForm.industry} onChange={(value) => setKbForm((p) => ({ ...p, industry: value }))} />
                    <TextField label="Level" value={kbForm.level} onChange={(value) => setKbForm((p) => ({ ...p, level: value }))} />
                  </div>
                  <div className="grid gap-4 md:grid-cols-2">
                    <NumberField label="High Threshold" value={kbForm.policy.highThreshold} onChange={(value) => setKbForm((p) => ({ ...p, policy: { ...p.policy, highThreshold: value } }))} />
                    <NumberField label="Moderate Threshold" value={kbForm.policy.moderateThreshold} onChange={(value) => setKbForm((p) => ({ ...p, policy: { ...p.policy, moderateThreshold: value } }))} />
                    <NumberField label="Low Confidence Threshold" value={kbForm.policy.lowConfidenceThreshold} step="0.01" onChange={(value) => setKbForm((p) => ({ ...p, policy: { ...p.policy, lowConfidenceThreshold: value } }))} />
                    <NumberField label="Critical Skill Penalty" value={kbForm.policy.criticalSkillPenalty} onChange={(value) => setKbForm((p) => ({ ...p, policy: { ...p.policy, criticalSkillPenalty: value } }))} />
                  </div>
                  <SubTitle>Role Skills</SubTitle>
                  {kbForm.skills.map((skill, index) => (
                    <KbSkillEditor
                      key={`${skill.name}-${index}`}
                      skill={skill}
                      onChange={(nextSkill) => setKbForm((prev) => ({ ...prev, skills: prev.skills.map((item, i) => (i === index ? nextSkill : item)) }))}
                      onRemove={() => setKbForm((prev) => ({ ...prev, skills: prev.skills.filter((_, i) => i !== index) }))}
                    />
                  ))}
                  <SecondaryButton type="button" onClick={() => setKbForm((prev) => ({ ...prev, skills: [...prev.skills, { name: "", aliasesText: "", category: "", required: true, weight: 0.2, isCritical: false }] }))}>
                    Add KB Skill
                  </SecondaryButton>
                  <PrimaryButton disabled={saving}>{saving ? "Saving..." : kbForm.id ? "Save Role" : "Create Role"}</PrimaryButton>
                </form>
              }
            />
          )}
          {activeTab === "requests" && (
            <Panel title="Change Requests" subtitle="Recruiter requests waiting for admin approval before live changes.">
              <div className="mb-4 flex flex-wrap items-center gap-3">
                <SelectField
                  label="Status Filter"
                  value={requestStatusFilter}
                  onChange={(value) => setRequestStatusFilter(value)}
                  options={["pending", "all", "approved", "rejected"]}
                />
              </div>
              <div className="overflow-hidden rounded-3xl border border-[#d4e6f0]">
                <div className="grid grid-cols-[160px_220px_220px_1fr_120px] bg-[#f2f9fd] px-4 py-3 text-xs font-semibold uppercase tracking-[0.14em] text-[#5e8fab]">
                  <div>When</div>
                  <div>Requester</div>
                  <div>Entity / Action</div>
                  <div>Summary</div>
                  <div>Status</div>
                </div>
                <div className="divide-y divide-[#e2eef5] bg-white">
                  {sortedRequests.map((request) => {
                    const statusClass = requestStatusClass(request.status);
                    const isSelected = request.id === selectedRequestId;

                    return (
                      <button
                        key={request.id}
                        type="button"
                        onClick={() => setSelectedRequestId(request.id)}
                        className={[
                          "w-full px-4 py-4 text-left transition",
                          isSelected ? "bg-[#eef7ff]" : "hover:bg-[#f8fcff]",
                        ].join(" ")}
                      >
                        <div className="grid grid-cols-[160px_220px_220px_1fr_120px] gap-3 text-sm">
                          <div className="text-slate-600">{formatDateTime(request.submittedAt)}</div>
                          <div>
                            <div className="font-medium">{request.requesterName || "Unknown"}</div>
                            <div className="text-xs text-slate-500">{request.requesterEmail || "--"}</div>
                          </div>
                          <div className="font-medium">
                            {request.entityType}
                            {request.targetId ? ` #${request.targetId}` : ""} / {request.actionType}
                          </div>
                          <div className="text-slate-600">{request.summary}</div>
                          <div>
                            <span className={`inline-flex rounded-full border px-3 py-1 text-xs font-semibold ${statusClass}`}>
                              {request.status}
                            </span>
                          </div>
                        </div>
                        <div className="mt-2 text-xs text-slate-500">
                          {isSelected ? "Selected for review" : "Click to select"}
                        </div>
                      </button>
                    );
                  })}
                  {!sortedRequests.length ? (
                    <div className="px-4 py-6 text-center text-sm text-slate-500">
                      No requests found for the selected filter.
                    </div>
                  ) : null}
                </div>
              </div>

              {selectedRequest ? (
                <div className="mt-4 rounded-2xl border border-[#d4e6f0] bg-[#f8fcff] p-4">
                  <div className="flex flex-wrap items-center gap-3">
                    <h3 className="text-lg font-black">Selected Request #{selectedRequest.id}</h3>
                    <span className={`inline-flex rounded-full border px-3 py-1 text-xs font-semibold ${requestStatusClass(selectedRequest.status)}`}>
                      {selectedRequest.status}
                    </span>
                  </div>
                  <div className="mt-3 grid gap-2 text-sm text-slate-700 md:grid-cols-2">
                    <div>
                      <span className="font-semibold">Requester:</span> {selectedRequest.requesterName || "Unknown"} ({selectedRequest.requesterEmail || "--"})
                    </div>
                    <div>
                      <span className="font-semibold">Submitted:</span> {formatDateTime(selectedRequest.submittedAt)}
                    </div>
                    <div>
                      <span className="font-semibold">Entity / Action:</span>{" "}
                      {selectedRequest.entityType}
                      {selectedRequest.targetId ? ` #${selectedRequest.targetId}` : ""} / {selectedRequest.actionType}
                    </div>
                  </div>
                  <div className="mt-3 rounded-2xl border border-[#d4e6f0] bg-white p-3 text-sm text-slate-700">
                    {selectedRequest.summary}
                  </div>

                  {selectedRequest.status === "pending" ? (
                    <div className="mt-4">
                      <TextAreaField
                        label="Review Note (required for reject, optional for approve)"
                        rows={2}
                        value={reviewNotes[selectedRequest.id] || ""}
                        onChange={(value) =>
                          setReviewNotes((prev) => ({ ...prev, [selectedRequest.id]: value }))
                        }
                      />
                      <div className="mt-3 flex gap-3">
                        <PrimaryButton
                          type="button"
                          disabled={saving}
                          onClick={() => approveChangeRequest(selectedRequest.id)}
                        >
                          {requestActionId === `approve-${selectedRequest.id}` ? "Approving..." : "Approve"}
                        </PrimaryButton>
                        <SecondaryButton
                          type="button"
                          disabled={saving}
                          onClick={() => rejectChangeRequest(selectedRequest.id)}
                        >
                          {requestActionId === `reject-${selectedRequest.id}` ? "Rejecting..." : "Reject"}
                        </SecondaryButton>
                      </div>
                    </div>
                  ) : (
                    <div className="mt-4 rounded-2xl border border-[#d4e6f0] bg-white p-3 text-xs text-slate-600">
                      Reviewed by: {selectedRequest.reviewerName || "--"} | {formatDateTime(selectedRequest.reviewedAt)} | Note: {selectedRequest.reviewNote || "--"}
                    </div>
                  )}
                </div>
              ) : null}
            </Panel>
          )}
          {activeTab === "prompts" && (
            <EditorSection
              items={prompts}
              title="Prompt Versions"
              subtitle="File-backed seed plus admin-managed drafts and published versions."
              onNew={() => setPromptForm(promptDraft(prompts.find((item) => item.status === "published") || null))}
              renderItem={(prompt) => (
                <button key={prompt.id} type="button" onClick={() => setPromptForm(promptDraft(prompt))} className="w-full rounded-2xl border border-[#d4e6f0] bg-[#fbfeff] p-4 text-left hover:bg-[#f4fbff]">
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <div className="font-semibold">{prompt.versionLabel}</div>
                      <div className="text-sm text-slate-600">{prompt.notes || "No notes"}</div>
                    </div>
                    <Badge>{prompt.status}</Badge>
                  </div>
                </button>
              )}
              formTitle="Prompt Editor"
              formBody={
                <form onSubmit={savePrompt} className="grid gap-4">
                  <div className="grid gap-4 md:grid-cols-2">
                    <TextField label="Version Label" value={promptForm.versionLabel} disabled={promptForm.status !== "draft"} onChange={(value) => setPromptForm((p) => ({ ...p, versionLabel: value }))} />
                    <TextField label="Status" value={promptForm.status} disabled onChange={() => {}} />
                  </div>
                  <TextAreaField label="Notes" value={promptForm.notes} disabled={promptForm.status !== "draft"} onChange={(value) => setPromptForm((p) => ({ ...p, notes: value }))} rows={2} />
                  <TextAreaField label="Master Prompt" value={promptForm.master_prompt} disabled={promptForm.status !== "draft"} onChange={(value) => setPromptForm((p) => ({ ...p, master_prompt: value }))} rows={6} />
                  {Object.keys(promptForm.tasks || {}).map((taskKey) => (
                    <TextAreaField
                      key={taskKey}
                      label={taskKey}
                      value={promptForm.tasks[taskKey]}
                      disabled={promptForm.status !== "draft"}
                      onChange={(value) => setPromptForm((prev) => ({ ...prev, tasks: { ...prev.tasks, [taskKey]: value } }))}
                      rows={6}
                    />
                  ))}
                  <div className="flex gap-3">
                    <PrimaryButton disabled={saving || promptForm.status !== "draft"}>{saving ? "Saving..." : "Save Draft"}</PrimaryButton>
                    <SecondaryButton type="button" disabled={saving || promptForm.status !== "draft"} onClick={publishPrompt}>
                      Publish
                    </SecondaryButton>
                    <SecondaryButton
                      type="button"
                      onClick={() => setPromptForm(promptDraft({ ...promptForm, id: null, status: "draft", versionLabel: `draft-${Date.now()}` }))}
                    >
                      Duplicate
                    </SecondaryButton>
                  </div>
                </form>
              }
            />
          )}
          {activeTab === "audit" && (
            <Panel title="Audit Logs" subtitle="Administrative changes and sensitive artifact access.">
              <div className="overflow-hidden rounded-3xl border border-[#d4e6f0]">
                <div className="grid grid-cols-[180px_180px_160px_1fr_180px] bg-[#f2f9fd] px-4 py-3 text-xs font-semibold uppercase tracking-[0.14em] text-[#5e8fab]">
                  <div>Actor</div>
                  <div>Action</div>
                  <div>Entity</div>
                  <div>Summary</div>
                  <div>When</div>
                </div>
                <div className="divide-y divide-[#e2eef5] bg-white">
                  {auditLogs.map((log) => (
                    <div key={log.id} className="grid grid-cols-[180px_180px_160px_1fr_180px] px-4 py-4 text-sm">
                      <div className="font-medium">{log.actor}</div>
                      <div>{log.action}</div>
                      <div>{log.entityType}{log.entityId ? ` #${log.entityId}` : ""}</div>
                      <div className="text-slate-600">{log.summary}</div>
                      <div className="text-slate-500">{formatDateTime(log.createdAt)}</div>
                    </div>
                  ))}
                </div>
              </div>
            </Panel>
          )}
        </section>
      </main>
    </div>
  );
}

function Panel({ title, subtitle, children }) {
  return (
    <section className="rounded-[30px] border border-[#bfd8e7] bg-white p-6 shadow-[0_18px_45px_rgba(11,31,59,0.08)]">
      <div className="mb-5">
        <h2 className="text-2xl font-black">{title}</h2>
        <p className="mt-1 text-sm text-slate-600">{subtitle}</p>
      </div>
      {children}
    </section>
  );
}

function EditorSection({ items, title, subtitle, onNew, renderItem, formTitle, formBody }) {
  return (
    <div className="grid gap-6 xl:grid-cols-[0.8fr_1.2fr]">
      <Panel title={title} subtitle={subtitle}>
        <div className="mb-4">
          <SecondaryButton type="button" onClick={onNew}>New</SecondaryButton>
        </div>
        <div className="space-y-2">{items.map(renderItem)}</div>
      </Panel>
      <Panel title={formTitle} subtitle="Changes are written to the live admin API.">
        {formBody}
      </Panel>
    </div>
  );
}

function Stat({ label, value }) {
  return (
    <div className="rounded-[28px] bg-[linear-gradient(135deg,#0b1f3b_0%,#1a4d79_100%)] p-5 text-white shadow-[0_18px_45px_rgba(11,31,59,0.18)]">
      <div className="text-xs uppercase tracking-[0.16em] text-sky-100/70">{label}</div>
      <div className="mt-4 text-4xl font-black">{value}</div>
    </div>
  );
}

function Health({ label, ok, detail = "" }) {
  return (
    <div className="rounded-2xl border border-[#d4e6f0] bg-[#f8fcff] p-4">
      <div className="text-xs uppercase tracking-[0.14em] text-[#6794ae]">{label}</div>
      <div className={`mt-2 text-lg font-bold ${ok ? "text-emerald-700" : "text-rose-700"}`}>{ok ? "Ready" : "Missing"}</div>
      {detail ? <div className="mt-1 text-xs text-slate-500">{detail}</div> : null}
    </div>
  );
}

function RowMetric({ label, value }) {
  return (
    <div className="mb-3 flex items-center justify-between rounded-2xl border border-[#d4e6f0] bg-[#f8fcff] px-4 py-3 text-sm">
      <span className="text-slate-600">{label}</span>
      <span className="text-lg font-black">{value}</span>
    </div>
  );
}

function Notice({ children }) {
  return <div className="rounded-2xl border border-[#a9d0e6] bg-[#f1fbff] px-4 py-3 text-sm font-medium">{children}</div>;
}

function SecretNotice({ children }) {
  return <div className="rounded-2xl border border-amber-200 bg-amber-50 px-4 py-3 text-sm">{children}</div>;
}

function TextField({ label, value, onChange, type = "text", placeholder = "", disabled = false, step }) {
  return (
    <label className="block">
      <span className="mb-2 block text-sm font-semibold text-[#173752]">{label}</span>
      <input
        type={type}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        disabled={disabled}
        step={step}
        className="h-11 w-full rounded-2xl border border-[#c9dfec] bg-[#f9fdff] px-4 text-sm outline-none disabled:bg-slate-100 focus:border-[#7fbce0] focus:ring-2 focus:ring-[#7fbce0]/20"
      />
    </label>
  );
}

function TextAreaField({ label, value, onChange, rows = 4, disabled = false }) {
  return (
    <label className="block">
      <span className="mb-2 block text-sm font-semibold text-[#173752]">{label}</span>
      <textarea
        rows={rows}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        disabled={disabled}
        className="w-full rounded-2xl border border-[#c9dfec] bg-[#f9fdff] px-4 py-3 text-sm outline-none disabled:bg-slate-100 focus:border-[#7fbce0] focus:ring-2 focus:ring-[#7fbce0]/20"
      />
    </label>
  );
}

function NumberField({ label, value, onChange, step = "1" }) {
  return <TextField label={label} value={value} onChange={onChange} type="number" placeholder="" step={step} />;
}

function SelectField({ label, value, onChange, options }) {
  return (
    <label className="block">
      <span className="mb-2 block text-sm font-semibold text-[#173752]">{label}</span>
      <select
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="h-11 w-full rounded-2xl border border-[#c9dfec] bg-[#f9fdff] px-4 text-sm outline-none focus:border-[#7fbce0] focus:ring-2 focus:ring-[#7fbce0]/20"
      >
        {options.map((option) => (
          <option key={option} value={option}>{option}</option>
        ))}
      </select>
    </label>
  );
}

function Toggle({ label, checked, onChange }) {
  return (
    <label className="flex items-center justify-between rounded-2xl border border-[#d4e6f0] bg-[#f8fcff] px-4 py-3 text-sm font-medium">
      <span>{label}</span>
      <input type="checkbox" checked={checked} onChange={(e) => onChange(e.target.checked)} />
    </label>
  );
}

function PrimaryButton({ children, type = "submit", onClick, disabled = false }) {
  return <button type={type} onClick={onClick} disabled={disabled} className="rounded-2xl bg-[#0b1f3b] px-5 py-3 text-sm font-semibold text-white hover:bg-[#14375d] disabled:opacity-60">{children}</button>;
}

function SecondaryButton({ children, type = "button", onClick, disabled = false }) {
  return <button type={type} onClick={onClick} disabled={disabled} className="rounded-2xl border border-[#b7d6e8] bg-[#f4fbff] px-5 py-3 text-sm font-semibold text-[#0b4f76] hover:bg-[#eaf6fd] disabled:opacity-60">{children}</button>;
}

function Badge({ children }) {
  return <span className="rounded-full border border-[#b9d8e9] bg-[#f3fbff] px-3 py-1 text-xs font-semibold text-[#0b4f76]">{children}</span>;
}

function SubTitle({ children }) {
  return <div className="text-xs font-black uppercase tracking-[0.16em] text-[#6794ae]">{children}</div>;
}

function SkillEditor({ skill, onChange, onRemove }) {
  return (
    <div className="grid gap-3 rounded-2xl border border-[#d4e6f0] bg-[#f8fcff] p-4 md:grid-cols-[1.2fr_0.9fr_110px_90px_auto]">
      <TextField label="Skill" value={skill.name} onChange={(value) => onChange({ ...skill, name: value })} />
      <TextField label="Category" value={skill.category} onChange={(value) => onChange({ ...skill, category: value })} />
      <Toggle label="Required" checked={skill.required} onChange={(checked) => onChange({ ...skill, required: checked })} />
      <TextField label="Weight" type="number" value={skill.weight} onChange={(value) => onChange({ ...skill, weight: value })} />
      <div className="flex items-end"><SecondaryButton type="button" onClick={onRemove}>Remove</SecondaryButton></div>
    </div>
  );
}

function KbSkillEditor({ skill, onChange, onRemove }) {
  return (
    <div className="grid gap-3 rounded-2xl border border-[#d4e6f0] bg-[#f8fcff] p-4 md:grid-cols-2">
      <TextField label="Skill" value={skill.name} onChange={(value) => onChange({ ...skill, name: value })} />
      <TextField label="Category" value={skill.category} onChange={(value) => onChange({ ...skill, category: value })} />
      <TextAreaField label="Aliases (comma-separated)" rows={2} value={skill.aliasesText} onChange={(value) => onChange({ ...skill, aliasesText: value })} />
      <TextField label="Weight" type="number" value={skill.weight} onChange={(value) => onChange({ ...skill, weight: value })} />
      <Toggle label="Required" checked={skill.required} onChange={(checked) => onChange({ ...skill, required: checked })} />
      <Toggle label="Critical" checked={skill.isCritical} onChange={(checked) => onChange({ ...skill, isCritical: checked })} />
      <div className="md:col-span-2"><SecondaryButton type="button" onClick={onRemove}>Remove Skill</SecondaryButton></div>
    </div>
  );
}
