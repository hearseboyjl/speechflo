import { db } from "../db.js";

let initialized = false;

export async function ensureInterviewArtifactsTable() {
  if (initialized) return;

  await db.query(`
    CREATE TABLE IF NOT EXISTS interview_artifacts (
      id INT AUTO_INCREMENT PRIMARY KEY,
      application_id INT NOT NULL,
      transcript LONGTEXT NULL,
      analysis_raw LONGTEXT NULL,
      skills_json LONGTEXT NULL,
      summary TEXT NULL,
      areas_for_improvement TEXT NULL,
      recommendation TEXT NULL,
      sentiment VARCHAR(32) NULL,
      confidence DECIMAL(6,4) NULL,
      skill_validation_raw LONGTEXT NULL,
      matched_skills_json LONGTEXT NULL,
      missing_skills_json LONGTEXT NULL,
      weighted_score DECIMAL(6,4) NULL,
      report_raw LONGTEXT NULL,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      UNIQUE KEY uniq_application_id (application_id)
    )
  `);

  initialized = true;
}

export function parseAnalysisSections(content = "") {
  const getSection = (label) => {
    const regex = new RegExp(
      `^${label}:\\s*([\\s\\S]*?)(?=^[A-Z][a-z ]+:|$)`,
      "im"
    );
    const match = content.match(regex);
    return match ? match[1].trim() : "";
  };

  const skillsRaw = getSection("Skills Extracted");
  const skills = skillsRaw
    ? skillsRaw.split(",").map((s) => s.trim()).filter(Boolean)
    : [];

  const summary = getSection("Summary");
  const areasForImprovement = getSection("Areas for Improvement");
  const recommendation = getSection("Recommended Next Step");
  const sentimentRaw = getSection("Sentiment");
  const sentiment = sentimentRaw
    ? sentimentRaw.replace(/^Sentiment:\s*/i, "").trim()
    : "";

  const confidenceRaw = getSection("Confidence");
  let confidence = null;
  if (confidenceRaw) {
    const match = confidenceRaw.match(/0(\.\d+)?|1(\.0+)?/);
    if (match) confidence = parseFloat(match[0]);
  }

  return {
    skills,
    summary,
    areasForImprovement,
    recommendation,
    sentiment,
    confidence,
  };
}

export function parseSkillValidation(content = "") {
  const lines = content.split("\n").map((l) => l.trim());
  const parsed = {
    matched_skills: [],
    missing_skills: [],
    weighted_score: 0,
  };

  lines.forEach((line) => {
    if (line.startsWith("matched_skills:")) {
      parsed.matched_skills = line
        .replace("matched_skills:", "")
        .split(",")
        .map((s) => s.trim())
        .filter(Boolean);
    }

    if (line.startsWith("missing_skills:")) {
      parsed.missing_skills = line
        .replace("missing_skills:", "")
        .split(",")
        .map((s) => s.trim())
        .filter(Boolean);
    }

    if (line.startsWith("weighted_score:")) {
      const score = parseFloat(line.replace("weighted_score:", "").trim());
      parsed.weighted_score = Number.isNaN(score) ? 0 : score;
    }
  });

  return parsed;
}
