import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { apiUrl } from "./api";
import { clearSession, getToken, storeSession } from "./session";

export default function AdminLog() {
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    const token = getToken();
    if (token) {
      navigate("/admin/dashboard", { replace: true });
    }
  }, [navigate]);

  async function readApiResponse(res) {
    const text = await res.text();
    if (!text) return null;

    try {
      return JSON.parse(text);
    } catch {
      return { message: text };
    }
  }

  const handleLogin = async (e) => {
    e.preventDefault();
    setError("");
    setLoading(true);

    try {
      const res = await fetch(apiUrl("/auth/admin/login"), {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ email, password }),
      });

      const data = await readApiResponse(res);
      if (!res.ok) {
        setError(data.message || "Admin login failed.");
        return;
      }

      clearSession();
      storeSession(data);
      navigate("/admin/dashboard", { replace: true });
    } catch (err) {
      console.error("[AdminLogin] error:", err);
      setError("Unable to sign in right now.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#07111e] text-white">
      <div className="relative overflow-hidden min-h-screen">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_top_left,rgba(95,167,218,0.28),transparent_30%),radial-gradient(circle_at_bottom_right,rgba(61,107,158,0.22),transparent_35%),linear-gradient(135deg,#07111e_0%,#0b1f3b_48%,#11345d_100%)]" />
        <div className="absolute inset-0 opacity-20 [background-image:linear-gradient(rgba(255,255,255,0.08)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.08)_1px,transparent_1px)] [background-size:48px_48px]" />

        <div className="relative z-10 mx-auto flex min-h-screen max-w-[1280px] items-center px-6 py-12">
          <div className="grid w-full gap-10 lg:grid-cols-[1.15fr_0.85fr]">
            <section className="self-center">
              <div className="inline-flex items-center rounded-full border border-white/15 bg-white/5 px-4 py-2 text-xs uppercase tracking-[0.24em] text-sky-100/80">
                SpeechFlo Admin
              </div>
              <h1 className="mt-8 max-w-[640px] text-5xl font-black leading-[1.05] text-white">
                Govern access, prompts, jobs, and system operations from one place.
              </h1>
              <p className="mt-5 max-w-[560px] text-base leading-7 text-slate-200/80">
                This panel is for internal administration only. Use it to manage recruiter access, maintain the
                knowledge base, publish prompt versions, and monitor usage on the VPS.
              </p>

            </section>

            <section className="rounded-[32px] border border-white/12 bg-white/8 p-8 shadow-[0_25px_80px_rgba(0,0,0,0.35)] backdrop-blur-xl">
              <div className="border-b border-white/10 pb-6">
                <h2 className="text-3xl font-bold text-white">Admin sign in</h2>
                <p className="mt-2 text-sm text-slate-200/70">Restricted to users with the `admin` role.</p>
              </div>

              <form onSubmit={handleLogin} className="mt-8 space-y-5">
                <Field
                  label="Email"
                  value={email}
                  onChange={setEmail}
                  type="email"
                  placeholder="admin@speechflo.site"
                />
                <Field
                  label="Password"
                  value={password}
                  onChange={setPassword}
                  type="password"
                  placeholder="Enter password"
                />

                {error ? (
                  <div className="rounded-2xl border border-rose-300/20 bg-rose-500/10 px-4 py-3 text-sm text-rose-100">
                    {error}
                  </div>
                ) : null}

                <button
                  type="submit"
                  disabled={loading}
                  className="inline-flex h-12 w-full items-center justify-center rounded-2xl bg-[#5eacd8] text-base font-semibold text-[#06203a] transition hover:brightness-95 disabled:opacity-60"
                >
                  {loading ? "Signing in..." : "Enter Admin Panel"}
                </button>
              </form>
            </section>
          </div>
        </div>
      </div>
    </div>
  );
}

function Field({ label, value, onChange, type = "text", placeholder = "" }) {
  return (
    <label className="block">
      <span className="mb-2 block text-sm font-medium text-slate-100">{label}</span>
      <input
        type={type}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        className="h-12 w-full rounded-2xl border border-white/12 bg-[#091a2f] px-4 text-white outline-none transition placeholder:text-slate-400 focus:border-[#7bc2ea] focus:ring-2 focus:ring-[#7bc2ea]/20"
      />
    </label>
  );
}
