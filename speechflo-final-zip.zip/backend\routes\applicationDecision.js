import express from "express";
import { db } from "../db.js";
import { authMiddleware, requireRole } from "./authMiddleware.js"; 
import { transporter } from "../utils/mailer.js";
import multer from "multer";
import dotenv from "dotenv";
import { appendApplicationStatusEvent } from "../utils/applicationTimeline.js";
import { writeAuditLog } from "../utils/auditLog.js";

dotenv.config();

const router = express.Router();

// Keep uploaded PDF in memory (no filesystem writes).
const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 20 * 1024 * 1024 },
});

/**
 * Marks an application as endorsed and writes status timeline + audit log.
 * Shared by both endorse and save-pdf endpoints to keep behavior consistent.
 */
async function markApplicationEndorsed(applicationId, actorUserId) {
  const parsedId = Number(applicationId);
  if (!Number.isFinite(parsedId)) {
    return { ok: false, code: 400, message: "Invalid application ID" };
  }

  const [rows] = await db.query(
    "SELECT status FROM job_applications WHERE id = ? LIMIT 1",
    [parsedId]
  );

  if (!rows.length) {
    return { ok: false, code: 404, message: "Application not found" };
  }

  const currentStatus = String(rows[0].status || "").trim().toLowerCase();
  if (currentStatus === "rejected") {
    return { ok: false, code: 400, message: "Rejected applications cannot be endorsed." };
  }

  if (currentStatus !== "endorsed") {
    await db.query(
      "UPDATE job_applications SET status = 'endorsed' WHERE id = ?",
      [parsedId]
    );

    await appendApplicationStatusEvent(db, {
      applicationId: parsedId,
      status: "endorsed",
      note: "Applicant endorsed to leadership.",
      changedBy: actorUserId || null,
    });
  }

  await writeAuditLog({
    actorUserId: actorUserId || null,
    action: "application.endorse",
    entityType: "application",
    entityId: parsedId,
    summary: `Application ${parsedId} endorsed.`,
  });

  return { ok: true };
}

/**
 * Sets application status to rejected and records a required rejection reason.
 */
router.post("/reject/:id", authMiddleware, requireRole("recruiter", "admin"), async (req, res) => {
  const applicationId = Number(req.params.id); 
  if (isNaN(applicationId)) return res.status(400).json({ error: "Invalid application ID" });
  const rejectionReason = String(req.body?.rejectionReason || "").trim();

  if (!rejectionReason) {
    return res.status(400).json({ error: "Rejection reason is required" });
  }

  try {
    const [result] = await db.query(
      "UPDATE job_applications SET status = 'rejected', rejection_reason = ? WHERE id = ?",
      [rejectionReason, applicationId] 
    );

    if (!result || result.affectedRows === 0) {
      return res.status(404).json({ error: "Applicant not found" });
    }

    await appendApplicationStatusEvent(db, {
      applicationId,
      status: "rejected",
      note: `Rejected by recruiter/admin. Reason: ${rejectionReason}`,
      changedBy: req.user.id,
    });

    res.json({ message: `Application ${applicationId} has been rejected.` });
  } catch (err) {
    console.error("Error rejecting applicant:", err);
    res.status(500).json({ error: "Internal server error" });
  }
});

/**
 * Sends recruiter-generated report HTML to leadership and endorses the application.
 */
router.post("/endorse/:id", authMiddleware, requireRole("recruiter", "admin"), async (req, res) => {
  const applicationId = Number(req.params.id);
  const { reportHtml, applicantName } = req.body; 
  if (!Number.isFinite(applicationId)) {
    return res.status(400).json({ error: "Invalid application ID" });
  }

  try {

    const recipientEmail = process.env.CEO_EMAIL;
    if (!recipientEmail) {
      console.error("[ENDORSE ERROR] CEO_EMAIL not set in .env");
      return res.status(500).json({ error: "CEO email not configured" });
    }


    await transporter.sendMail({
      from: `"Recruiter Team" <${process.env.MAIL_USER}>`,
      to: recipientEmail,
      subject: `Application Recommendation - "${applicantName}"`,
      html: reportHtml,
    });

    const endorseResult = await markApplicationEndorsed(applicationId, req.user?.id);
    if (!endorseResult.ok) {
      return res.status(endorseResult.code).json({ error: endorseResult.message });
    }

    res.json({ message: `Report sent to CEO at ${recipientEmail}. Application marked as endorsed.` });
  } catch (err) {
    console.error("[ENDORSE ERROR]", err);
    res.status(500).json({ error: "Failed to send report" });
  }
});

/**
 * Emails exported report PDF to leadership and optionally endorses the application.
 * PDF is processed in memory only (no filesystem persistence).
 */
router.post("/save-pdf", authMiddleware, requireRole("recruiter", "admin"), upload.single("pdf"), async (req, res) => {
  try {
    if (!req.file || !req.file.buffer) {
      return res.status(400).json({ error: "No PDF uploaded" });
    }

    const applicantName = req.body.applicantName || "report";
    const applicationId = Number(req.body.applicationId);
    const recipientEmail = process.env.CEO_EMAIL;
    if (!recipientEmail) {
      console.error("[SAVE PDF ERROR] CEO_EMAIL not set in .env");
      return res.status(500).json({ error: "CEO email not configured" });
    }

    const fileName = req.file.originalname || `${applicantName || "report"}.pdf`;


    // Send email with PDF attachment
    await transporter.sendMail({
      from: `"Recruiter Team" <${process.env.MAIL_USER}>`,
      to: recipientEmail,
      subject: `Application Recommendation - "${applicantName}"`,
      html: `<p>Please find attached the application report for <strong>${applicantName}</strong>.</p>`,
      attachments: [
        {
          filename: fileName,
          content: req.file.buffer,
          contentType: req.file.mimetype || "application/pdf",
        },
      ],
    });

    if (Number.isFinite(applicationId)) {
      const endorseResult = await markApplicationEndorsed(applicationId, req.user?.id);
      if (!endorseResult.ok) {
        return res.status(endorseResult.code).json({ error: endorseResult.message });
      }
    }

    res.json({
      message: "PDF emailed to CEO successfully",
    });
  } catch (err) {
    console.error("[SAVE PDF ERROR]", err);
    res.status(500).json({ error: "Failed to save and send PDF" });
  }
});

export default router;
