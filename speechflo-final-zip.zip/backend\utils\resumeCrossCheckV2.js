const TOOL_LEXICON = {
  quickbooks: ["quick books", "qb"],
  xero: [],
  excel: ["microsoft excel", "ms excel", "spreadsheets"],
  "google sheets": ["sheets"],
  sap: [],
  oracle: ["oracle erp"],
  photoshop: ["adobe photoshop"],
  "premiere pro": ["adobe premiere", "premiere"],
  illustrator: ["adobe illustrator"],
  figma: [],
  canva: [],
  sql: ["mysql", "postgresql", "mssql", "sql server"],
  "power bi": ["powerbi", "microsoft power bi"],
  tableau: [],
  git: ["github", "gitlab"],
  react: ["reactjs", "react.js"],
  "node.js": ["nodejs", "node"],
};

const SKILL_KEYWORD_ALIASES = {
  "accounting operations": [
    "accounting work",
    "accounting process",
    "general accounting",
    "office based accounting",
    "bookkeeping",
  ],
  "accounting software": [
    "accounting system",
    "accounting tools",
    "quickbooks",
    "xero",
    "odoo",
    "sap",
    "excel",
  ],
  "accounts payable receivable": [
    "accounts payable",
    "accounts receivable",
    "ap ar",
    "vendor payments",
    "customer invoices",
  ],
  "excel analytics": [
    "excel",
    "pivot tables",
    "formulas",
    "spreadsheets",
    "data analysis",
    "reporting",
  ],
  "financial statements": [
    "financial reporting",
    "financial reports",
    "income statement",
    "balance sheet",
    "cash flow statement",
    "reports",
  ],
  bookkeeping: [
    "bookkeeper",
    "general ledger",
    "accounts payable",
    "accounts receivable",
    "bank reconciliation",
    "financial records",
  ],
  accounting: [
    "general accounting",
    "financial accounting",
    "accountant",
    "ledger",
    "journal entries",
  ],
  payroll: ["payroll processing", "salary processing"],
  taxation: ["tax preparation", "tax filing", "tax compliance"],
  "financial reporting": ["reports", "financial statements"],
  communication: ["verbal communication", "written communication"],
  "customer service": ["client support", "customer support"],
  "data entry": ["data encoding"],
  "video editing": ["video post production", "editing"],
  "graphic design": ["visual design", "layout design"],
};

const WEAK_ALIAS_TERMS = new Set([
  "accounting",
  "work",
  "reports",
  "reporting",
  "experience",
  "operations",
]);

function clamp01(value) {
  const n = Number(value ?? 0);
  if (!Number.isFinite(n)) return 0;
  if (n < 0) return 0;
  if (n > 1) return 1;
  return n;
}

function normalizeText(text = "") {
  return String(text || "")
    .replace(/\r/g, "\n")
    .replace(/\u00a0/g, " ")
    .replace(/[ \t]+/g, " ")
    .replace(/\n{3,}/g, "\n\n")
    .trim();
}

function normalizeKey(value = "") {
  return String(value || "")
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, " ")
    .trim();
}

function tokenize(text = "") {
  return normalizeKey(text)
    .split(" ")
    .filter(Boolean);
}

function escapeRegex(value = "") {
  return String(value || "").replace(/[-/\\^$*+?.()|[\]{}]/g, "\\$&");
}

function uniqueNormalized(values = []) {
  const out = [];
  const seen = new Set();
  (Array.isArray(values) ? values : []).forEach((value) => {
    const raw = String(value || "").trim();
    const key = normalizeKey(raw);
    if (!key || seen.has(key)) return;
    seen.add(key);
    out.push(raw);
  });
  return out;
}

function parseAliases(rawValue) {
  if (!rawValue) return [];
  if (Array.isArray(rawValue)) {
    return rawValue.map((v) => String(v || "").trim()).filter(Boolean);
  }
  try {
    const parsed = JSON.parse(rawValue);
    if (!Array.isArray(parsed)) return [];
    return parsed.map((v) => String(v || "").trim()).filter(Boolean);
  } catch {
    return [];
  }
}

function getAliasTerms(term = "") {
  const key = normalizeKey(term);
  const direct = SKILL_KEYWORD_ALIASES[key] || [];
  return Array.isArray(direct) ? direct : [];
}

function buildClaimTerms(base = "", explicitAliases = []) {
  return uniqueNormalized([base, ...explicitAliases, ...getAliasTerms(base)]);
}

function findEvidenceLine(text = "", phrase = "") {
  const source = normalizeText(text);
  const target = String(phrase || "").trim();
  if (!source || !target) return "";

  const lines = source
    .split(/\r?\n/)
    .map((line) => line.trim())
    .filter(Boolean);

  const lowerTarget = target.toLowerCase();
  for (const line of lines) {
    if (line.toLowerCase().includes(lowerTarget)) return line.slice(0, 280);
  }

  const targetTokens = tokenize(target).filter((t) => t.length >= 4);
  if (!targetTokens.length) return "";
  for (const line of lines) {
    const lineTokens = tokenize(line);
    const shared = targetTokens.filter((t) => lineTokens.includes(t)).length;
    if (
      (targetTokens.length === 1 && shared === 1) ||
      (targetTokens.length === 2 && shared === 2) ||
      (targetTokens.length >= 3 && shared / targetTokens.length >= 0.67)
    ) {
      return line.slice(0, 280);
    }
  }
  return "";
}

function findEvidenceLineByTerms(text = "", terms = []) {
  for (const term of uniqueNormalized(terms)) {
    const line = findEvidenceLine(text, term);
    if (line) return line;
  }
  return "";
}

function hasMention(text = "", phrase = "") {
  const source = normalizeKey(text);
  const target = normalizeKey(phrase);
  if (!source || !target) return false;

  const exactRegex = new RegExp(
    `\\b${escapeRegex(target).replace(/\s+/g, "\\s+")}\\b`,
    "i"
  );
  if (exactRegex.test(source)) return true;

  const targetTokens = tokenize(target).filter((t) => t.length >= 4);
  if (!targetTokens.length) return false;
  const sourceTokens = tokenize(source);
  const shared = targetTokens.filter((t) => sourceTokens.includes(t)).length;
  if (targetTokens.length === 1) return shared === 1;
  if (targetTokens.length === 2) return shared === 2;
  return shared / targetTokens.length >= 0.67;
}

function hasAnyMention(text = "", terms = []) {
  return uniqueNormalized(terms).some((term) => hasMention(text, term));
}

function getApplicantOnlyText(transcript = "") {
  const source = normalizeText(transcript);
  if (!source) return "";
  const applicantLines = source
    .split(/\r?\n/)
    .map((line) => line.trim())
    .filter((line) => /^Applicant:/i.test(line))
    .map((line) => line.replace(/^Applicant:\s*/i, "").trim())
    .filter(Boolean);
  return applicantLines.length ? applicantLines.join("\n") : source;
}

function tokenOverlapRatio(a = "", b = "") {
  const aTokens = tokenize(a).filter((t) => t.length >= 4);
  const bTokens = tokenize(b).filter((t) => t.length >= 4);
  if (!aTokens.length || !bTokens.length) return 0;
  const aSet = new Set(aTokens);
  const bSet = new Set(bTokens);
  let shared = 0;
  aSet.forEach((tok) => {
    if (bSet.has(tok)) shared += 1;
  });
  return shared / Math.max(Math.min(aSet.size, bSet.size), 1);
}

function findExtractedSkillEvidence(claimTerms = [], extractedSkills = []) {
  const terms = uniqueNormalized(claimTerms);
  const candidates = (Array.isArray(extractedSkills) ? extractedSkills : [])
    .map((s) => String(s || "").trim())
    .filter(Boolean);
  for (const candidate of candidates) {
    const candidateTokens = tokenize(candidate).filter((t) => t.length >= 4);
    if (candidateTokens.length < 2) continue;
    if (hasAnyMention(candidate, terms)) return candidate;
    const strongOverlap = terms.some((term) => tokenOverlapRatio(candidate, term) >= 0.67);
    if (strongOverlap) return candidate;
  }
  return "";
}

function findMentionedTerm(text = "", terms = []) {
  const cleaned = uniqueNormalized(terms);
  for (const term of cleaned) {
    if (hasMention(text, term)) return term;
  }
  return "";
}

function isWeakEvidenceTerm(term = "") {
  const key = normalizeKey(term);
  if (!key) return true;
  if (WEAK_ALIAS_TERMS.has(key)) return true;
  const toks = tokenize(key).filter((t) => t.length >= 4);
  return toks.length <= 1;
}

function splitClaimVariants(claim = "") {
  const src = String(claim || "").trim();
  if (!src) return [];
  const out = [src];
  const paren = src.match(/\(([^)]+)\)/);
  if (paren && paren[1]) {
    paren[1]
      .split(/[,/]/)
      .map((p) => p.trim())
      .filter(Boolean)
      .forEach((p) => out.push(p));
  }
  if (/\bpayable\b/i.test(src) && /\breceivable\b/i.test(src)) {
    out.push("accounts payable");
    out.push("accounts receivable");
    out.push("ap ar");
  }
  return uniqueNormalized(out);
}

function isLikelySkillHeading(line = "") {
  const k = normalizeKey(line);
  return (
    k === "skills" ||
    k === "core skills" ||
    k === "technical skills" ||
    k === "key skills"
  );
}

function isSectionBoundary(line = "") {
  const k = normalizeKey(line);
  if (!k) return true;
  return (
    k.includes("work experience") ||
    k === "experience" ||
    k.includes("education") ||
    k.includes("summary") ||
    k.includes("certification") ||
    k.includes("projects")
  );
}

function extractResumeSkillClaims(resumeText = "") {
  const source = normalizeText(resumeText);
  if (!source) return [];
  const lines = source
    .split(/\r?\n/)
    .map((l) => l.trim())
    .filter(Boolean);
  const claims = [];

  let inSkillsSection = false;
  for (const line of lines) {
    if (isLikelySkillHeading(line)) {
      inSkillsSection = true;
      continue;
    }
    if (inSkillsSection && isSectionBoundary(line)) {
      inSkillsSection = false;
    }

    if (inSkillsSection) {
      const cleaned = line.replace(/^[-*•]\s*/, "").trim();
      if (!cleaned) continue;
      claims.push(cleaned);
    }
  }

  return uniqueNormalized(claims);
}

function buildResumeSkillTerms(resumeText = "") {
  const claimLines = extractResumeSkillClaims(resumeText);
  const byKey = new Map();
  const displayByKey = new Map();

  claimLines.forEach((claim) => {
    const variants = splitClaimVariants(claim);
    const baseClaim = String(claim).replace(/\s*\([^)]*\)\s*/g, " ").trim();
    const canonical = normalizeKey(baseClaim);
    if (!canonical) return;
    const aliasTerms = variants
      .flatMap((v) => getAliasTerms(v))
      .filter(Boolean);
    const terms = buildClaimTerms(claim, [...variants, ...aliasTerms]);
    byKey.set(canonical, uniqueNormalized([...(byKey.get(canonical) || []), ...terms]));
    if (!displayByKey.has(canonical)) displayByKey.set(canonical, baseClaim || claim);
  });

  const resumeSkills = Array.from(displayByKey.values());
  const termsBySkillKey = {};
  byKey.forEach((terms, key) => {
    termsBySkillKey[key] = terms;
  });
  return { resumeSkills, termsBySkillKey };
}

function extractTools(text = "") {
  const source = normalizeText(text);
  const found = [];
  Object.entries(TOOL_LEXICON).forEach(([tool, aliases]) => {
    const terms = buildClaimTerms(tool, aliases);
    if (hasAnyMention(source, terms)) found.push(tool);
  });
  return uniqueNormalized(found).map((v) => normalizeKey(v));
}

function getToolTerms(tool = "") {
  const canonical = normalizeKey(tool);
  if (TOOL_LEXICON[canonical]) {
    return buildClaimTerms(canonical, TOOL_LEXICON[canonical]);
  }
  return buildClaimTerms(canonical, []);
}

function extractCredentials(text = "") {
  const source = normalizeText(text);
  const matches = source.match(
    /\b(cpa|cma|cia|certified public accountant|certificate in [a-z0-9 ()+.-]+|certification in [a-z0-9 ()+.-]+|tesda [a-z0-9 ()+.-]+|nc ii|civil service eligible)\b/gi
  );
  if (!matches) return [];
  return uniqueNormalized(
    matches.map((m) => normalizeKey(m)).filter(Boolean)
  );
}

function parseYearMatch(match = []) {
  const first = Number(match[1]);
  const second = Number(match[2]);
  if (!Number.isFinite(first)) return null;
  if (Number.isFinite(second)) return Math.max(first, second);
  return first;
}

function extractYearsBySkill(text = "", skills = [], termsBySkillKey = {}) {
  const source = normalizeText(text);
  const map = {};
  if (!source) return map;

  const segments = source
    .split(/\r?\n|(?<=[.!?])\s+/)
    .map((line) => line.trim())
    .filter(Boolean);

  const yearRegex =
    /(?:over|more than|at least|around|about|nearly|almost)?\s*(\d{1,2})(?:\s*-\s*(\d{1,2}))?\s*(?:\+|plus)?\s*years?(?:\s+of\s+experience)?/gi;

  segments.forEach((segment) => {
    const yearMatches = Array.from(segment.matchAll(yearRegex));
    if (!yearMatches.length) return;
    skills.forEach((skill) => {
      const key = normalizeKey(skill);
      if (!key) return;
      const terms = termsBySkillKey[key] || buildClaimTerms(skill, []);
      if (!hasAnyMention(segment, terms)) return;
      yearMatches.forEach((m) => {
        const years = parseYearMatch(m);
        if (!Number.isFinite(years)) return;
        map[key] = Math.max(map[key] || 0, years);
      });
    });
  });

  // Fallback for formats like "5+ years in bookkeeping" or "bookkeeping ... 5 years".
  skills.forEach((skill) => {
    const key = normalizeKey(skill);
    if (!key) return;
    const terms = termsBySkillKey[key] || buildClaimTerms(skill, []);

    terms.forEach((term) => {
      const normTerm = normalizeKey(term);
      if (!normTerm) return;

      const termThenYears = new RegExp(
        `${escapeRegex(normTerm).replace(/\s+/g, "\\s+")}.{0,100}?(\\d{1,2})(?:\\s*-\\s*(\\d{1,2}))?\\s*(?:\\+|plus)?\\s*years?`,
        "i"
      );
      const yearsThenTerm = new RegExp(
        `(\\d{1,2})(?:\\s*-\\s*(\\d{1,2}))?\\s*(?:\\+|plus)?\\s*years?.{0,100}?${escapeRegex(normTerm).replace(/\s+/g, "\\s+")}`,
        "i"
      );

      const mt = source.match(termThenYears);
      if (mt) {
        const years = parseYearMatch(mt);
        if (Number.isFinite(years)) {
          map[key] = Math.max(map[key] || 0, years);
        }
      }
      const my = source.match(yearsThenTerm);
      if (my) {
        const years = parseYearMatch(my);
        if (Number.isFinite(years)) {
          map[key] = Math.max(map[key] || 0, years);
        }
      }
    });
  });

  return map;
}

function buildSkillChecks({
  roleSkills = [],
  termsBySkillKey = {},
  extractedSkills = [],
  resumeText = "",
  transcriptText = "",
}) {
  const checks = [];
  let supportPoints = 0;
  let softGapCount = 0;

  roleSkills.forEach((skill) => {
    const key = normalizeKey(skill);
    const terms = termsBySkillKey[key] || buildClaimTerms(skill, []);
    const inResume = hasAnyMention(resumeText, terms);
    const transcriptMatchedTerm = findMentionedTerm(transcriptText, terms);
    const inTranscriptFromText = Boolean(transcriptMatchedTerm);
    const transcriptEvidenceFromText = inTranscriptFromText
      ? findEvidenceLine(transcriptText, transcriptMatchedTerm)
      : "";
    const transcriptWeakFromText = inTranscriptFromText
      ? isWeakEvidenceTerm(transcriptMatchedTerm)
      : false;
    const extractedEvidence = findExtractedSkillEvidence(terms, extractedSkills);
    const inTranscript = inTranscriptFromText || Boolean(extractedEvidence);
    const resumeEvidence = inResume ? findEvidenceLineByTerms(resumeText, terms) : "";
    const transcriptEvidence = inTranscriptFromText
      ? transcriptEvidenceFromText
      : extractedEvidence
        ? `Extracted skill: ${extractedEvidence}`
        : "";

    let status = "unknown";
    if (inTranscript && inResume && inTranscriptFromText && !transcriptWeakFromText) {
      status = "match";
    } else if (inTranscript && inResume) {
      // Weak transcript terms or extracted-only support are treated as partial.
      status = "partial";
      softGapCount += 1;
    } else if (inTranscript && !inResume) {
      status = "partial";
      softGapCount += 1;
    } else if (!inTranscript && inResume) {
      status = "unknown";
    }

    if (status === "match") supportPoints += 1;
    else if (status === "partial") supportPoints += 0.5;

    checks.push({
      type: "skill",
      claim_key: key,
      claim_terms: terms,
      status,
      resume_evidence_text: resumeEvidence,
      transcript_evidence_text: transcriptEvidence,
      impact_weight: 0.6,
    });
  });

  const score =
    roleSkills.length > 0
      ? supportPoints / roleSkills.length
      : null;

  return {
    checks,
    score,
    softGapCount,
  };
}

function buildToolChecks({ resumeText = "", transcriptText = "" }) {
  const resumeTools = extractTools(resumeText);
  const transcriptTools = extractTools(transcriptText);
  const checks = [];
  let matchedCount = 0;
  let softGapCount = 0;

  resumeTools.forEach((toolKey) => {
    const inTranscript = transcriptTools.includes(toolKey);
    const terms = getToolTerms(toolKey);
    if (inTranscript) matchedCount += 1;
    checks.push({
      type: "tool",
      claim_key: toolKey,
      claim_terms: terms,
      status: inTranscript ? "match" : "unknown",
      resume_evidence_text: findEvidenceLineByTerms(resumeText, terms),
      transcript_evidence_text: inTranscript
        ? findEvidenceLineByTerms(transcriptText, terms)
        : "",
      impact_weight: 0.35,
    });
  });

  const score =
    resumeTools.length > 0 ? matchedCount / resumeTools.length : null;

  return {
    checks,
    score,
    softGapCount,
    resumeTools,
    transcriptTools,
  };
}

function buildExperienceChecks({
  roleSkills = [],
  termsBySkillKey = {},
  resumeText = "",
  transcriptText = "",
}) {
  const resumeYears = extractYearsBySkill(resumeText, roleSkills, termsBySkillKey);
  const transcriptYears = extractYearsBySkill(transcriptText, roleSkills, termsBySkillKey);
  const checks = [];
  const comparableKeys = Object.keys(resumeYears);
  let scored = 0;
  let points = 0;
  let hardContradictions = 0;
  let softGaps = 0;
  let insufficientEvidence = 0;

  comparableKeys.forEach((skillKey) => {
    const displaySkill =
      roleSkills.find((s) => normalizeKey(s) === skillKey) || skillKey;
    const terms = termsBySkillKey[skillKey] || buildClaimTerms(displaySkill, []);
    const resumeMention = hasAnyMention(resumeText, terms);
    const transcriptMention = hasAnyMention(transcriptText, terms);
    const r = resumeYears[skillKey];
    const t = transcriptYears[skillKey];

    let status = "unknown";
    let resumeEvidence = "";
    let transcriptEvidence = "";

    if (Number.isFinite(r)) {
      resumeEvidence =
        findEvidenceLine(resumeText, `${r} years`) || findEvidenceLineByTerms(resumeText, terms);
    } else if (resumeMention) {
      resumeEvidence = findEvidenceLineByTerms(resumeText, terms);
    }

    if (Number.isFinite(t)) {
      transcriptEvidence =
        findEvidenceLine(transcriptText, `${t} years`) ||
        findEvidenceLineByTerms(transcriptText, terms);
    } else if (transcriptMention) {
      transcriptEvidence = findEvidenceLineByTerms(transcriptText, terms);
    }

    if (Number.isFinite(r) && Number.isFinite(t)) {
      scored += 1;
      const gap = Math.abs(r - t);
      if (gap <= 1) {
        status = "match";
        points += 1;
      } else if (gap <= 2) {
        status = "partial";
        points += 0.5;
        softGaps += 1;
      } else {
        status = "conflict";
        hardContradictions += 1;
      }
    } else if (transcriptMention) {
      // Resume claims years but transcript only gives non-quantified mention.
      status = "partial";
      scored += 1;
      points += 0.5;
      softGaps += 1;
    } else {
      status = "unknown";
      insufficientEvidence += 1;
    }

    checks.push({
      type: "experience",
      claim_key: normalizeKey(displaySkill),
      claim_terms: terms,
      status,
      resume_evidence_text: resumeEvidence,
      transcript_evidence_text: transcriptEvidence,
      impact_weight: 0.5,
    });
  });

  const score = scored > 0 ? points / scored : null;

  return {
    checks,
    score,
    hardContradictions,
    softGaps,
    insufficientEvidence,
    resumeYears,
    transcriptYears,
  };
}

function safeTypeScore(checks = [], type = "") {
  const relevant = checks.filter((c) => c.type === type);
  if (!relevant.length) return null;
  const scored = relevant.filter((c) => c.status !== "unknown");
  if (!scored.length) return null;
  const points = scored.reduce((sum, c) => {
    if (c.status === "match") return sum + 1;
    if (c.status === "partial") return sum + 0.5;
    if (c.status === "conflict") return sum + 0;
    return sum;
  }, 0);
  return points / scored.length;
}

export function recomputeResumeCrossCheckMetrics(crossCheck = {}) {
  const checks = Array.isArray(crossCheck.claim_checks) ? crossCheck.claim_checks : [];

  const skillScore = safeTypeScore(checks, "skill");
  const expScore = safeTypeScore(checks, "experience");
  const toolScore = safeTypeScore(checks, "tool");
  const credScore = safeTypeScore(checks, "credential");

  const hardContradictionCount = checks.filter(
    (c) => c.type === "experience" && c.status === "conflict"
  ).length;
  const softGapCount = checks.filter((c) => c.status === "partial").length;
  const insufficientEvidenceCount = checks.filter((c) => c.status === "unknown").length;

  const weighted =
    0.45 * (skillScore ?? 0.5) +
    0.25 * (expScore ?? 0.5) +
    0.15 * (toolScore ?? 0.5) +
    0.15 * (credScore ?? 0.5);
  const hardPenalty = hardContradictionCount * 0.12;
  const softPenalty = softGapCount * 0.04;
  const overall = clamp01(weighted - hardPenalty - softPenalty);

  const hasResumeText =
    crossCheck.has_resume_text === undefined
      ? true
      : Boolean(crossCheck.has_resume_text);
  const hasTranscriptText =
    crossCheck.has_transcript_text === undefined
      ? true
      : Boolean(crossCheck.has_transcript_text);

  return {
    ...crossCheck,
    skill_alignment_score: skillScore === null ? null : Number(skillScore.toFixed(4)),
    experience_consistency_score: expScore === null ? null : Number(expScore.toFixed(4)),
    tooling_consistency_score: toolScore === null ? null : Number(toolScore.toFixed(4)),
    credential_consistency_score: credScore === null ? null : Number(credScore.toFixed(4)),
    overall_resume_consistency_score: Number(overall.toFixed(4)),
    hard_contradiction_count: hardContradictionCount,
    soft_gap_count: softGapCount,
    insufficient_evidence_count: insufficientEvidenceCount,
    resume_consistency_flag: toFlag(overall, hasResumeText, hasTranscriptText),
  };
}

function buildCredentialChecks({ resumeText = "", transcriptText = "" }) {
  const resumeCred = extractCredentials(resumeText);
  const transcriptCred = extractCredentials(transcriptText);
  const checks = [];
  let matched = 0;
  let softGaps = 0;
  let insufficientEvidence = 0;

  resumeCred.forEach((cred) => {
    const terms = buildClaimTerms(cred, []);
    const inTranscript = transcriptCred.includes(cred) || hasAnyMention(transcriptText, terms);
    if (inTranscript) matched += 1;
    checks.push({
      type: "credential",
      claim_key: cred,
      claim_terms: terms,
      status: inTranscript ? "match" : "unknown",
      resume_evidence_text: findEvidenceLineByTerms(resumeText, terms),
      transcript_evidence_text: inTranscript
        ? findEvidenceLineByTerms(transcriptText, terms)
        : "",
      impact_weight: 0.3,
    });
  });

  if (!resumeCred.length) {
    insufficientEvidence += 1;
  }

  const score = resumeCred.length > 0 ? matched / resumeCred.length : null;

  return {
    checks,
    score,
    softGaps,
    insufficientEvidence,
    resumeCredentials: resumeCred,
    transcriptCredentials: transcriptCred,
  };
}

function toFlag(score, hasResumeText, hasTranscriptText) {
  if (!hasResumeText || !hasTranscriptText || score === null || score === undefined) {
    return "Insufficient Data";
  }
  if (score >= 0.75) return "High";
  if (score >= 0.45) return "Moderate";
  return "Low";
}

export function buildResumeCrossCheckV2({
  resumeText = "",
  transcript = "",
  extractedSkills = [],
  // kept for backward compatibility; intentionally not used in resume-only validation
  roleSkillsRows = [],
}) {
  const normalizedResume = normalizeText(resumeText);
  const applicantTranscript = getApplicantOnlyText(transcript);
  const { resumeSkills, termsBySkillKey } = buildResumeSkillTerms(normalizedResume);

  const hasResumeText = Boolean(normalizedResume);
  const hasTranscriptText = Boolean(applicantTranscript);
  const base = {
    version: "resume_consistency_v2_2_resume_only",
    has_resume_text: hasResumeText,
    has_transcript_text: hasTranscriptText,
    resume_claims: {
      skills: [],
      tools: [],
      years_by_skill: {},
      credentials: [],
    },
    transcript_claims: {
      skills: [],
      tools: [],
      years_by_skill: {},
      credentials: [],
    },
    claim_checks: [],
    skill_alignment_score: null,
    experience_consistency_score: null,
    tooling_consistency_score: null,
    credential_consistency_score: null,
    overall_resume_consistency_score: null,
    hard_contradiction_count: 0,
    soft_gap_count: 0,
    insufficient_evidence_count: 0,
    resume_consistency_flag: "Insufficient Data",
    notes: "Insufficient resume or transcript data for resume-only cross-check.",
  };

  if (!hasResumeText || !hasTranscriptText) {
    return base;
  }

  const skillResult = buildSkillChecks({
    roleSkills: resumeSkills,
    termsBySkillKey,
    extractedSkills,
    resumeText: normalizedResume,
    transcriptText: applicantTranscript,
  });
  const toolResult = buildToolChecks({
    resumeText: normalizedResume,
    transcriptText: applicantTranscript,
  });
  const expResult = buildExperienceChecks({
    roleSkills: resumeSkills,
    termsBySkillKey,
    resumeText: normalizedResume,
    transcriptText: applicantTranscript,
  });
  const credResult = buildCredentialChecks({
    resumeText: normalizedResume,
    transcriptText: applicantTranscript,
  });

  const skillScore = skillResult.score;
  const expScore = expResult.score;
  const toolScore = toolResult.score;
  const credScore = credResult.score;

  const weighted =
    0.45 * (skillScore ?? 0.5) +
    0.25 * (expScore ?? 0.5) +
    0.15 * (toolScore ?? 0.5) +
    0.15 * (credScore ?? 0.5);
  const hardPenalty = expResult.hardContradictions * 0.12;
  const softPenalty =
    (skillResult.softGapCount +
      toolResult.softGapCount +
      expResult.softGaps +
      credResult.softGaps) *
    0.04;
  const overall = clamp01(weighted - hardPenalty - softPenalty);

  const insufficientEvidenceCount =
    expResult.insufficientEvidence + credResult.insufficientEvidence;
  const softGapCount =
    skillResult.softGapCount +
    toolResult.softGapCount +
    expResult.softGaps +
    credResult.softGaps;
  const hardContradictionCount = expResult.hardContradictions;

  const claimChecks = [
    ...skillResult.checks,
    ...toolResult.checks,
    ...expResult.checks,
    ...credResult.checks,
  ];

  return {
    version: "resume_consistency_v2_2_resume_only",
    has_resume_text: hasResumeText,
    has_transcript_text: hasTranscriptText,
    resume_claims: {
      skills: resumeSkills,
      tools: toolResult.resumeTools,
      years_by_skill: expResult.resumeYears,
      credentials: credResult.resumeCredentials,
    },
    transcript_claims: {
      skills: resumeSkills.filter((s) =>
        hasAnyMention(applicantTranscript, termsBySkillKey[normalizeKey(s)] || [s])
      ),
      tools: toolResult.transcriptTools,
      years_by_skill: expResult.transcriptYears,
      credentials: credResult.transcriptCredentials,
    },
    claim_checks: claimChecks,
    skill_alignment_score: skillScore === null ? null : Number(skillScore.toFixed(4)),
    experience_consistency_score: expScore === null ? null : Number(expScore.toFixed(4)),
    tooling_consistency_score: toolScore === null ? null : Number(toolScore.toFixed(4)),
    credential_consistency_score: credScore === null ? null : Number(credScore.toFixed(4)),
    overall_resume_consistency_score: Number(overall.toFixed(4)),
    hard_contradiction_count: hardContradictionCount,
    soft_gap_count: softGapCount,
    insufficient_evidence_count: insufficientEvidenceCount,
    resume_consistency_flag: toFlag(overall, hasResumeText, hasTranscriptText),
    notes:
      hardContradictionCount > 0
        ? "Hard contradictions detected between resume claims and interview statements."
        : softGapCount > 0
          ? "Some resume claims are only partially supported by interview statements."
          : "Resume claims are largely supported by interview statements.",
  };
}

function buildSemanticChunks(text = "", maxChunks = 90) {
  const source = normalizeText(text);
  if (!source) return [];
  const chunks = [];
  const seen = new Set();

  const rawLines = source
    .split(/\r?\n/)
    .map((line) => line.trim())
    .filter(Boolean);

  rawLines.forEach((line) => {
    const key = normalizeKey(line);
    if (!key || key.length < 8 || seen.has(key)) return;
    seen.add(key);
    chunks.push(line.slice(0, 320));
  });

  if (chunks.length < maxChunks) {
    source
      .split(/(?<=[.!?])\s+/)
      .map((s) => s.trim())
      .filter((s) => s.length >= 20)
      .forEach((sentence) => {
        const key = normalizeKey(sentence);
        if (!key || seen.has(key)) return;
        seen.add(key);
        chunks.push(sentence.slice(0, 320));
      });
  }

  return chunks.slice(0, maxChunks);
}

function cosineSimilarity(a = [], b = []) {
  if (!Array.isArray(a) || !Array.isArray(b) || !a.length || a.length !== b.length) return 0;
  let dot = 0;
  let magA = 0;
  let magB = 0;
  for (let i = 0; i < a.length; i += 1) {
    dot += a[i] * b[i];
    magA += a[i] * a[i];
    magB += b[i] * b[i];
  }
  if (!magA || !magB) return 0;
  return dot / (Math.sqrt(magA) * Math.sqrt(magB));
}

function semanticThresholdsByType(type = "") {
  if (type === "experience") {
    return { match: 0.72, partial: 0.62 };
  }
  if (type === "credential") {
    return { match: 0.7, partial: 0.6 };
  }
  if (type === "tool") {
    return { match: 0.69, partial: 0.6 };
  }
  return { match: 0.68, partial: 0.58 };
}

function buildClaimQuery(check = {}) {
  const terms = uniqueNormalized(check.claim_terms || [check.claim_key]);
  const primary = String(check.claim_key || terms[0] || "").trim();
  if (check.type === "experience") {
    return `Claimed years of experience for ${primary}. Related terms: ${terms.join(", ")}`;
  }
  if (check.type === "tool") {
    return `Tool proficiency: ${primary}. Related terms: ${terms.join(", ")}`;
  }
  if (check.type === "credential") {
    return `Credential or certification: ${primary}. Related terms: ${terms.join(", ")}`;
  }
  return `Required skill evidence: ${primary}. Related terms: ${terms.join(", ")}`;
}

function promoteStatusBySemantic({
  existingStatus = "unknown",
  type = "",
  resumeSim = 0,
  transcriptSim = 0,
  transcriptHasEvidence = false,
  resumeHasEvidence = false,
}) {
  if (existingStatus === "conflict") return "conflict";
  if (existingStatus === "match") return "match";
  const th = semanticThresholdsByType(type);
  const resumeStrong = resumeSim >= th.match;
  const transcriptStrong = transcriptSim >= th.match;
  const resumeWeak = resumeSim >= th.partial;
  const transcriptWeak = transcriptSim >= th.partial;

  if (resumeStrong && transcriptStrong) return "match";
  if (transcriptStrong && !resumeWeak) return "partial";
  if ((resumeWeak && transcriptWeak) || (transcriptWeak && transcriptHasEvidence)) {
    return existingStatus === "unknown" ? "partial" : existingStatus;
  }
  if (!resumeHasEvidence && transcriptHasEvidence && transcriptStrong) {
    return "partial";
  }
  return existingStatus;
}

export async function enhanceResumeCrossCheckWithEmbeddings({
  crossCheck = {},
  resumeText = "",
  transcriptText = "",
  openaiClient = null,
  model = "text-embedding-3-small",
}) {
  const checks = Array.isArray(crossCheck.claim_checks) ? crossCheck.claim_checks : [];
  const normalizedResume = normalizeText(resumeText);
  const normalizedTranscript = normalizeText(transcriptText);
  if (!openaiClient || !checks.length || !normalizedResume || !normalizedTranscript) {
    return crossCheck;
  }

  const resumeChunks = buildSemanticChunks(normalizedResume, 80);
  const transcriptChunks = buildSemanticChunks(normalizedTranscript, 80);
  if (!resumeChunks.length || !transcriptChunks.length) {
    return crossCheck;
  }

  const queryTexts = checks.map((check) => buildClaimQuery(check));
  const inputs = [
    ...queryTexts.map((q) => `query: ${q}`),
    ...resumeChunks.map((c) => `resume: ${c}`),
    ...transcriptChunks.map((c) => `transcript: ${c}`),
  ];

  const emb = await openaiClient.embeddings.create({
    model,
    input: inputs,
  });

  const vectors = emb?.data?.map((d) => d.embedding) || [];
  if (vectors.length !== inputs.length) {
    return crossCheck;
  }

  const queryOffset = 0;
  const resumeOffset = queryTexts.length;
  const transcriptOffset = queryTexts.length + resumeChunks.length;

  const enhancedChecks = checks.map((check, idx) => {
    const queryVec = vectors[queryOffset + idx] || [];
    let bestResume = { sim: -1, text: "" };
    let bestTranscript = { sim: -1, text: "" };

    for (let i = 0; i < resumeChunks.length; i += 1) {
      const sim = cosineSimilarity(queryVec, vectors[resumeOffset + i] || []);
      if (sim > bestResume.sim) {
        bestResume = { sim, text: resumeChunks[i] };
      }
    }
    for (let i = 0; i < transcriptChunks.length; i += 1) {
      const sim = cosineSimilarity(queryVec, vectors[transcriptOffset + i] || []);
      if (sim > bestTranscript.sim) {
        bestTranscript = { sim, text: transcriptChunks[i] };
      }
    }

    const out = {
      ...check,
      semantic_resume_similarity: Number(Math.max(0, bestResume.sim).toFixed(4)),
      semantic_transcript_similarity: Number(Math.max(0, bestTranscript.sim).toFixed(4)),
      semantic_method: "embedding_similarity",
    };

    const thresholds = semanticThresholdsByType(check.type);
    if (
      !String(out.resume_evidence_text || "").trim() &&
      bestResume.sim >= thresholds.partial
    ) {
      out.resume_evidence_text = bestResume.text.slice(0, 280);
    }
    if (
      !String(out.transcript_evidence_text || "").trim() &&
      bestTranscript.sim >= thresholds.partial
    ) {
      out.transcript_evidence_text = bestTranscript.text.slice(0, 280);
    }

    const transcriptHasEvidence = Boolean(String(out.transcript_evidence_text || "").trim());
    const resumeHasEvidence = Boolean(String(out.resume_evidence_text || "").trim());
    out.status = promoteStatusBySemantic({
      existingStatus: check.status,
      type: check.type,
      resumeSim: bestResume.sim,
      transcriptSim: bestTranscript.sim,
      transcriptHasEvidence,
      resumeHasEvidence,
    });

    return out;
  });

  const recomputed = recomputeResumeCrossCheckMetrics({
    ...crossCheck,
    version: "resume_consistency_v2_1_semantic",
    has_resume_text: Boolean(normalizedResume),
    has_transcript_text: Boolean(normalizedTranscript),
    claim_checks: enhancedChecks,
  });
  return {
    ...recomputed,
    semantic_enhanced: true,
    embedding_model: model,
    notes: `${recomputed.notes || ""} Semantic evidence enrichment applied.`.trim(),
  };
}
