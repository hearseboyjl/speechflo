import express from "express";
import dotenv from "dotenv";
import cors from "cors";
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";
import authRoutes from "./routes/auth.js";
import submitApplication from "./routes/submitapplication.js";
import profileRoutes from "./routes/profiles.js";
import { checkAuth } from "./checkAuth.js";
import transcribeRoutes from "./routes/transcriber.js";
import jobApplicationsRouter from "./routes/jobApplications.js";
import skillValidationRoutes from "./routes/skillvalidation.js";
import fetchEmailRoutes from "./routes/fetchApplicantEmail.js";
import applicationDecisionRoutes from "./routes/applicationDecision.js";
import reportRoutes from "./routes/reportHandler.js";
import analyticsRoutes from "./routes/analytics.js";
import adminRoutes from "./routes/admin.js";
import publicJobsRoutes from "./routes/publicJobs.js";
import changeRequestsRoutes from "./routes/changeRequests.js";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const projectRoot = path.join(__dirname, "..");

dotenv.config({ path: path.join(projectRoot, ".env") });

const app = express();
app.set("trust proxy", 1);

const PORT = Number(process.env.PORT || 3000);
const distDir = path.join(projectRoot, "dist");
const distIndexPath = path.join(distDir, "index.html");
const shouldServeFrontend = String(process.env.SERVE_FRONTEND || "false").toLowerCase() === "true";
const hasFrontendBuild = fs.existsSync(distIndexPath);
const apiPrefixes = [
  "/auth",
  "/applications",
  "/profiles",
  "/transcribe",
  "/job-applications",
  "/api",
  "/email",
  "/application-decision",
  "/reports",
  "/analytics",
  "/admin",
  "/public",
  "/change-requests",
  "/healthz",
  "/test",
];

const allowedOrigins = new Set(
  [
    "http://localhost:5173",
    "http://localhost:5174",
    ...(process.env.CORS_ORIGINS || "")
      .split(",")
      .map((value) => value.trim())
      .filter(Boolean),
  ]
);

function isSameOriginRequest(req, origin) {
  if (!origin) return false;

  try {
    const forwardedProto = String(req.headers["x-forwarded-proto"] || req.protocol)
      .split(",")[0]
      .trim();
    const requestOrigin = `${forwardedProto}://${req.get("host")}`;
    return new URL(origin).origin === requestOrigin;
  } catch {
    return false;
  }
}

app.use(
  cors((req, callback) => {
    const origin = req.header("Origin");
    const isAllowed =
      !origin || allowedOrigins.has(origin) || isSameOriginRequest(req, origin);

    callback(
      isAllowed ? null : new Error("Not allowed by CORS"),
      {
        origin: isAllowed,
        methods: ["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"],
        allowedHeaders: ["Content-Type", "Authorization"],
        credentials: true,
        optionsSuccessStatus: 204,
      }
    );
  })
);

app.use(express.json({ limit: "10mb" }));

app.get("/healthz", (_req, res) => {
  res.json({ ok: true });
});

app.get("/test", (_req, res) => {
  res.json({ message: "Test route working!" });
});

// Keep admin SPA routes reachable on browser refresh.
// Without this, /admin and /admin/dashboard are intercepted by the /admin API middleware.
if (shouldServeFrontend && hasFrontendBuild) {
  app.get(["/admin", "/admin/", "/admin/dashboard"], (_req, res) => {
    res.sendFile(distIndexPath);
  });
}

app.use("/auth", authRoutes);
app.use("/applications", submitApplication);
app.use("/profiles", checkAuth, profileRoutes);
app.use("/transcribe", transcribeRoutes);
app.use("/job-applications", jobApplicationsRouter);
app.use("/api", skillValidationRoutes);
app.use("/email", fetchEmailRoutes);
app.use("/application-decision", applicationDecisionRoutes);
app.use("/reports", reportRoutes);
app.use("/analytics", analyticsRoutes);
app.use("/admin", adminRoutes);
app.use("/public/jobs", publicJobsRoutes);
app.use("/change-requests", changeRequestsRoutes);

if (shouldServeFrontend) {
  if (hasFrontendBuild) {
    app.use(express.static(distDir));
    app.use((req, res, next) => {
      const isApiRoute = apiPrefixes.some(
        (prefix) => req.path === prefix || req.path.startsWith(`${prefix}/`)
      );

      if (req.method !== "GET" || isApiRoute || path.extname(req.path)) {
        return next();
      }

      return res.sendFile(distIndexPath);
    });
  } else {
    console.warn(
      `[server] SERVE_FRONTEND=true but build output was not found at ${distIndexPath}`
    );
  }
}

app.listen(PORT, "0.0.0.0", () => {
  console.log(`[server] listening on port ${PORT}`);
});
