// Thesis-friendly policy defaults:
// keep everything explicit and easy to explain during defense.

export const compatibilityConfig = {
  modelVersion: "compat_v1",
  thresholds: {
    high: 80,
    moderate: 60,
    lowConfidence: 0.7,
  },
  weights: {
    skillFit: 0.4,
    requiredCoverage: 0.2,
    communicationClarity: 0.15,
    evidenceReliability: 0.1,
    responseConsistency: 0.15,
  },
  penalties: {
    // subtract this for each missing critical skill
    missingCriticalSkill: 15,
  },
};

export function getCompatibilityFlag(scoreOutOf100, cfg = compatibilityConfig) {
  const score = Number(scoreOutOf100 || 0);
  if (score >= cfg.thresholds.high) return "High";
  if (score >= cfg.thresholds.moderate) return "Moderate";
  return "Low";
}

export function getConfidenceFlag(confidence, cfg = compatibilityConfig) {
  const value = Number(confidence ?? 0);
  return value < cfg.thresholds.lowConfidence ? "Low Analysis Confidence" : "OK";
}

export const recommendationClasses = [
  "Advance",
  "Advance with Caution",
  "Manual Review",
  "Do Not Advance",
];

function toPercent01(value) {
  const n = Number(value ?? 0);
  if (!Number.isFinite(n)) return 0;
  return Math.max(0, Math.min(1, n));
}

export function computeCompatibilityResult({
  weightedScore = 0,
  requiredCoverage = 0,
  communicationClarity = 0,
  confidence = 0,
  responseConsistency = 0,
  missingCriticalCount = 0,
  cfg = compatibilityConfig,
} = {}) {
  const skillFitPct = toPercent01(weightedScore) * 100;
  const requiredCoveragePct = toPercent01(requiredCoverage) * 100;
  const clarityPct = toPercent01(communicationClarity) * 100;
  const reliabilityPct = toPercent01(confidence) * 100;
  const consistencyPct = toPercent01(responseConsistency) * 100;

  const weightedSum =
    cfg.weights.skillFit * skillFitPct +
    cfg.weights.requiredCoverage * requiredCoveragePct +
    cfg.weights.communicationClarity * clarityPct +
    cfg.weights.evidenceReliability * reliabilityPct +
    cfg.weights.responseConsistency * consistencyPct;

  const penalty = Number(missingCriticalCount || 0) * Number(cfg.penalties.missingCriticalSkill || 0);
  const score = Math.max(0, Math.min(100, weightedSum - penalty));
  const compatibilityFlag = getCompatibilityFlag(score, cfg);
  const confidenceFlag = getConfidenceFlag(confidence, cfg);

  let recommendationClass = "Manual Review";
  if (confidenceFlag === "Low Analysis Confidence") {
    recommendationClass = "Manual Review";
  } else if (compatibilityFlag === "High" && missingCriticalCount === 0) {
    recommendationClass = "Advance";
  } else if (compatibilityFlag === "Moderate" && missingCriticalCount === 0) {
    recommendationClass = "Advance with Caution";
  } else if (compatibilityFlag === "Low" && missingCriticalCount > 0) {
    recommendationClass = "Do Not Advance";
  }

  return {
    compatibility_score: Number(score.toFixed(2)),
    compatibility_flag: compatibilityFlag,
    confidence_flag: confidenceFlag,
    recommendation_class: recommendationClass,
    compatibility_model_version: cfg.modelVersion,
    components: {
      skillFit: Number(skillFitPct.toFixed(2)),
      requiredCoverage: Number(requiredCoveragePct.toFixed(2)),
      communicationClarity: Number(clarityPct.toFixed(2)),
      evidenceReliability: Number(reliabilityPct.toFixed(2)),
      responseConsistency: Number(consistencyPct.toFixed(2)),
      missingCriticalCount: Number(missingCriticalCount || 0),
      penaltyApplied: Number(penalty.toFixed(2)),
    },
  };
}
