import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { apiUrl } from "./api";


export default function JobDetails({ jobId = 6}) {
  const navigate = useNavigate(); // Ã¢Å“â€¦ ADDED

  const [loading, setLoading] = useState(false);
  const jobTitle = "Electrician";
  
    // Optional: check token on mount
    useEffect(() => {
      const token = localStorage.getItem("token");
      if (!token) return; // no token, just let user stay
  
      // Validate token with backend (optional)
      fetch(apiUrl("/auth/me"), {
        method: "GET",
        headers: { Authorization: `Bearer ${token}` },
      })
        .then((res) => {
          if (!res.ok) throw new Error("Token invalid");
        })
        .catch(() => {
          localStorage.removeItem("token");
        });
    }, []);
  
    const applyForJob = async () => {
      const token = localStorage.getItem("token");
  
      // if no token, redirect to signup
      if (!token) {
        navigate("/signup");
        return;
      }
  
      try {
        setLoading(true);
  
        const response = await fetch(
          apiUrl("/applications/apply"),
          {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              Authorization: `Bearer ${token}`,
            },
            body: JSON.stringify({ job_id: jobId, job_title: jobTitle }),
          }
        );
  
        if (response.status === 401) {
          localStorage.removeItem("token");
          navigate("/signup");
          return;
        }
  
        const data = await response.json();
  
        if (response.ok) {
          alert("Application submitted successfully!");
          navigate("/my_applications");
        } else {
          alert(data.message || "Failed to submit application.");
        }
      } catch (err) {
        console.error(err);
        alert("Server error. Try again later.");
      } finally {
        setLoading(false);
      }
    };

  return (
    <div className="min-h-screen w-full app-bg">
      <div className="mx-auto flex min-h-screen max-w-4xl flex-col px-4 py-8 sm:px-6">
        {/* Header */}
        <header className="rounded-xl border border-slate-200 bg-white shadow-sm p-6 sm:p-8 text-left">
          <h1 className="text-2xl font-extrabold tracking-wide text-[#0B1F3B] sm:text-3xl">
            Electrician (Heavy Equipment and Automotive)
          </h1>

          <p className="mt-2 text-sm font-semibold text-[#FF0000]">
            On-site AvantePH Headhunting Full time
          </p>

          <p className="mt-1 text-sm font-semibold text-[#FFA500]">
            Leyte, Eastern Visayas, Philippines
          </p>
        </header>

        <section className="mt-8 flex min-h-0 flex-1 flex-col rounded-xl border border-slate-200 bg-white shadow-sm">
          <div className="min-h-0 flex-1 overflow-auto p-6 sm:p-8">

            <div>
              <h2 className="text-base font-bold text-[#000080]">Description</h2>
              <p className="mt-3 text-sm leading-6 text-slate-700">
                We are hiring a Heavy Equipment and Automotive Electrician to perform
                electrical diagnostics, repair, and maintenance on heavy machinery and
                vehicles. The role requires in-depth knowledge of automotive electrical
                systems and the ability to troubleshoot issues using diagnostic tools and
                schematics.
              </p>

              <h3 className="mt-8 text-base font-bold text-[#000080]">
                Key Responsibilities
              </h3>
              <ul className="mt-3 list-disc space-y-2 pl-5 text-sm leading-6 text-slate-700">
                <li>Diagnose and repair electrical systems on heavy equipment and vehicles, including loaders, trucks, mixers, and forklifts.</li>
                <li>Use scanners and tools to identify faults and correct them efficiently.</li>
                <li>Interpret wiring diagrams and schematics.</li>
                <li>Maintain and repair components such as batteries, relays, starters, alternators, sensors, and control modules.</li>
                <li>Perform preventive maintenance and ensure repairs meet operational and safety standards.</li>
                <li>Document all work and report equipment status regularly.</li>
              </ul>

              <h2 className="mt-10 text-base font-bold text-[#000080]">
                Qualifications
              </h2>
              <ul className="mt-3 list-disc space-y-2 pl-5 text-sm leading-6 text-slate-700">
                <li>At least 5 years of experience in electrical repair of heavy equipment and vehicles.</li>
                <li>Skilled in using diagnostic scanners and reading schematics.</li>
                <li>Strong knowledge of AC/DC circuits and electronic components.</li>
                <li>Experience with China-branded equipment is a plus.</li>
                <li>Detail-oriented, safety-conscious, and team-focused.</li>
              </ul>
            </div>
          </div>

          <div className="border-t border-slate-200 p-4 sm:p-5">
            <div className="flex items-center justify-center">
              <button
                type="button"
                 onClick={applyForJob}
                disabled={loading}
                className="
                  inline-flex min-w-[220px] items-center justify-center
                  rounded-full bg-[#2F8DCD] px-7 py-3
                  text-sm font-semibold text-white
                  shadow-[0_8px_22px_rgba(47,141,205,0.38)]
                  transition-all duration-200
                  hover:bg-[#2a7fc0]
                  active:scale-[0.97]
                  disabled:cursor-not-allowed disabled:opacity-50
                "
              >
                {loading ? "Applying..." : "Apply for this Job"}
              </button>
            </div>
          </div>

        </section>
      </div>
    </div>
  );
}

