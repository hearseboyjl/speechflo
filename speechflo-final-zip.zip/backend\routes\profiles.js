import express from "express";
import multer from "multer";
import { db as pool } from "../db.js";
import { checkAuth } from "../checkAuth.js";

const router = express.Router();

// Store upload in memory, then persist binary in MySQL.
const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 10 * 1024 * 1024 }, // 10MB
});

// get /profiles -> fetch existing profile info
router.get("/", checkAuth, async (req, res) => {
  try {
    const userId = req.user.id;

    // get basic user info
    const [users] = await pool.query(
      "SELECT first_name, last_name, email FROM users WHERE id = ?",
      [userId]
    );
    if (users.length === 0) {
      return res.status(404).json({ message: "User not found" });
    }
    const user = users[0];

    // get profile info
    const [profiles] = await pool.query(
      "SELECT phone, resume_path FROM profiles WHERE user_id = ?",
      [userId]
    );
    const profile = profiles[0] || {};

    res.json({
      firstName: user.first_name,
      lastName: user.last_name,
      email: user.email,
      contact: profile.phone || "",
      resume_path: profile.resume_path || "",
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Server error" });
  }
});

// post /profiles -> save or update profile info
router.post("/", checkAuth, (req, res) => {
  upload.single("resume")(req, res, async (uploadErr) => {
    if (uploadErr instanceof multer.MulterError && uploadErr.code === "LIMIT_FILE_SIZE") {
      return res.status(400).json({ message: "Resume must be 10 MB or smaller" });
    }
    if (uploadErr) {
      console.error(uploadErr);
      return res.status(400).json({ message: "Failed to process resume upload" });
    }

    try {
      const { fullName, contact } = req.body;
      const resumeFile = req.file || null;
      const userId = req.user.id;

      const [firstName, ...lastNameParts] = fullName.trim().split(" ");
      const lastName = lastNameParts.join(" ") || "";

      await pool.query(
        "UPDATE users SET first_name = ?, last_name = ? WHERE id = ?",
        [firstName, lastName, userId]
      );

      const [existing] = await pool.query(
        "SELECT * FROM profiles WHERE user_id = ?",
        [userId]
      );

      let nextResumeLabel = existing[0]?.resume_path || null;
      if (resumeFile) {
        const allowedTypes = new Set([
          "application/pdf",
          "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        ]);
        if (!allowedTypes.has(resumeFile.mimetype)) {
          return res.status(400).json({ message: "Only PDF or DOCX files are allowed" });
        }

        const safeName = String(resumeFile.originalname || "resume").replace(/[^\w.\- ]+/g, "_");
        nextResumeLabel = safeName;
        await pool.query(
          `
          INSERT INTO applicant_resume_files (user_id, file_name, mime_type, file_data)
          VALUES (?, ?, ?, ?)
          ON DUPLICATE KEY UPDATE
            file_name = VALUES(file_name),
            mime_type = VALUES(mime_type),
            file_data = VALUES(file_data)
          `,
          [userId, safeName, resumeFile.mimetype, resumeFile.buffer]
        );
      }

      if (existing.length > 0) {
        await pool.query(
          "UPDATE profiles SET phone = ?, resume_path = ?, updated_at = CURRENT_TIMESTAMP WHERE user_id = ?",
          [contact, nextResumeLabel, userId]
        );
      } else {
        await pool.query(
          "INSERT INTO profiles (user_id, phone, resume_path) VALUES (?, ?, ?)",
          [userId, contact, nextResumeLabel]
        );
      }

      return res.json({ message: "Profile saved successfully" });
    } catch (err) {
      console.error(err);
      return res.status(500).json({ message: "Server error" });
    }
  });
});

// get /profiles/resume/download -> download current user's saved resume
router.get("/resume/download", checkAuth, async (req, res) => {
  try {
    const userId = req.user.id;
    const [rows] = await pool.query(
      "SELECT file_name, mime_type, file_data FROM applicant_resume_files WHERE user_id = ? LIMIT 1",
      [userId]
    );

    const resume = rows[0];
    if (!resume) {
      return res.status(404).json({ message: "Resume not found" });
    }
    res.setHeader("Content-Type", resume.mime_type || "application/octet-stream");
    res.setHeader(
      "Content-Disposition",
      `attachment; filename="${(resume.file_name || "resume").replace(/"/g, "")}"`
    );
    return res.send(resume.file_data);
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "Server error" });
  }
});

export default router;
