import { useEffect, useMemo, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { apiUrl } from "../api";

export default function PublicJobDetails() {
  const navigate = useNavigate();
  const { jobId } = useParams();
  const [job, setJob] = useState(null);
  const [loading, setLoading] = useState(true);
  const [loadingApply, setLoadingApply] = useState(false);
  const [hasApplied, setHasApplied] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    let alive = true;

    const loadJob = async () => {
      setLoading(true);
      setError("");
      try {
        const res = await fetch(apiUrl(`/public/jobs/${jobId}`));
        if (!res.ok) {
          const text = await res.text();
          throw new Error(text || "Failed to load job details.");
        }
        const data = await res.json();
        if (alive) setJob(data);

        const token = localStorage.getItem("token");
        if (token) {
          try {
            const myRes = await fetch(apiUrl("/applications/my"), {
              headers: { Authorization: `Bearer ${token}` },
            });
            if (myRes.ok) {
              const apps = await myRes.json();
              const alreadyApplied = (Array.isArray(apps) ? apps : []).some(
                (app) => Number(app.job_id) === Number(jobId)
              );
              if (alive) setHasApplied(alreadyApplied);
            }
          } catch {
            // Ignore optional applicant-state check errors.
          }
        } else if (alive) {
          setHasApplied(false);
        }
      } catch (err) {
        if (alive) setError(err.message || "Failed to load job details.");
      } finally {
        if (alive) setLoading(false);
      }
    };

    loadJob();
    return () => {
      alive = false;
    };
  }, [jobId]);

  const applyForJob = async () => {
    const token = localStorage.getItem("token");
    if (!token) {
      navigate("/login-applicant");
      return;
    }
    if (!job?.id) return;
    if (hasApplied) {
      navigate("/my_applications");
      return;
    }

    setLoadingApply(true);
    try {
      const response = await fetch(apiUrl("/applications/apply"), {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          job_id: job.id,
        }),
      });

      if (response.status === 401) {
        localStorage.removeItem("token");
        navigate("/login-applicant");
        return;
      }

      const data = await response.json();
      if (response.ok) {
        setHasApplied(true);
        alert("Application submitted successfully!");
        navigate("/my_applications");
      } else if (response.status === 409) {
        setHasApplied(true);
        alert(data.message || "You already applied to this job.");
      } else if (response.status === 403) {
        alert(data.message || "Only applicant accounts can apply for jobs.");
      } else {
        alert(data.message || "Failed to submit application.");
      }
    } catch (err) {
      console.error(err);
      alert("Server error. Try again later.");
    } finally {
      setLoadingApply(false);
    }
  };

  const locationLabel = useMemo(
    () => [job?.city, job?.region].filter(Boolean).join(", "),
    [job]
  );

  if (loading) {
    return (
      <div className="min-h-screen w-full app-bg p-8">
        <div className="mx-auto max-w-4xl rounded-xl border border-slate-200 bg-white p-6 text-sm text-slate-600">
          Loading job details...
        </div>
      </div>
    );
  }

  if (error || !job) {
    return (
      <div className="min-h-screen w-full app-bg p-8">
        <div className="mx-auto max-w-4xl rounded-xl border border-rose-200 bg-rose-50 p-6 text-sm text-rose-700">
          {error || "Job not found."}
          <div className="mt-4">
            <button
              type="button"
              onClick={() => navigate("/jobs")}
              className="rounded-full bg-[#2F8DCD] px-5 py-2 text-sm font-semibold text-white hover:bg-[#2a7fc0]"
            >
              Back to Jobs
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen w-full app-bg">
      <div className="mx-auto flex min-h-screen max-w-4xl flex-col px-4 py-8 sm:px-6">
        <header className="rounded-xl border border-slate-200 bg-white shadow-sm p-6 sm:p-8">
          <h1 className="text-2xl font-extrabold tracking-wide text-[#0B1F3B] sm:text-3xl">
            {job.title}
          </h1>

          <p className="mt-2 text-sm font-semibold text-[#FF0000]">
            {[job.workSetup, job.companyName, job.employmentType].filter(Boolean).join(" | ") || "Open role"}
          </p>

          <p className="mt-1 text-sm font-semibold text-[#FFA500]">
            {locationLabel || "Location not specified"}
          </p>
        </header>

        <section className="mt-8 flex min-h-0 flex-1 flex-col rounded-xl border border-slate-200 bg-white shadow-sm">
          <div className="min-h-0 flex-1 overflow-auto p-6 sm:p-8">
            <div>
              <h2 className="text-base font-bold text-[#000080]">Description</h2>
              <p className="mt-3 text-sm leading-6 text-slate-700 whitespace-pre-wrap">
                {job.description || "No description provided."}
              </p>

              <h3 className="mt-8 text-base font-bold text-[#000080]">Required Skills</h3>
              {Array.isArray(job.skills) && job.skills.length ? (
                <ul className="mt-3 list-disc space-y-2 pl-5 text-sm leading-6 text-slate-700">
                  {job.skills.map((skill, index) => (
                    <li key={`${skill.name}-${index}`}>
                      {skill.name}
                      {skill.category ? ` (${skill.category})` : ""}
                      {!skill.required ? " - optional" : ""}
                    </li>
                  ))}
                </ul>
              ) : (
                <p className="mt-3 text-sm text-slate-700">No skill list provided yet.</p>
              )}
            </div>
          </div>

          <div className="border-t border-slate-200 p-4 sm:p-5">
            <div className="flex items-center justify-center gap-3">
              <button
                type="button"
                onClick={() => navigate("/jobs")}
                className="inline-flex min-w-[160px] items-center justify-center rounded-full border border-slate-300 bg-white px-6 py-3 text-sm font-semibold text-slate-700 transition-all duration-200 hover:bg-slate-50"
              >
                Back to Jobs
              </button>
              <button
                type="button"
                onClick={applyForJob}
                disabled={loadingApply || hasApplied}
                className="inline-flex min-w-[220px] items-center justify-center rounded-full bg-[#2F8DCD] px-7 py-3 text-sm font-semibold text-white shadow-[0_8px_22px_rgba(47,141,205,0.38)] transition-all duration-200 hover:bg-[#2a7fc0] active:scale-[0.97] disabled:cursor-not-allowed disabled:opacity-50"
              >
                {loadingApply ? "Applying..." : hasApplied ? "Already Applied" : "Apply for this Job"}
              </button>
            </div>
          </div>
        </section>
      </div>
    </div>
  );
}
