function normalizeNote(value) {
  const note = String(value || "").trim();
  return note || null;
}

export async function appendApplicationStatusEvent(
  executor,
  { applicationId, status, note = null, changedBy = null, createdAt = null }
) {
  const appId = Number(applicationId);
  if (!Number.isFinite(appId)) return false;

  const statusValue = String(status || "").trim().toLowerCase();
  if (!statusValue) return false;

  try {
    const [latestRows] = await executor.query(
      `
      SELECT status
      FROM application_status_history
      WHERE application_id = ?
      ORDER BY created_at DESC, id DESC
      LIMIT 1
      `,
      [appId]
    );

    if (latestRows[0]?.status === statusValue) {
      return false;
    }

    await executor.query(
      `
      INSERT INTO application_status_history (
        application_id,
        status,
        note,
        changed_by,
        created_at
      ) VALUES (?, ?, ?, ?, COALESCE(?, NOW()))
      `,
      [
        appId,
        statusValue,
        normalizeNote(note),
        changedBy || null,
        createdAt || null,
      ]
    );

    return true;
  } catch (err) {
    // Allow app flows to continue if migration wasn't applied yet.
    if (err?.code === "ER_NO_SUCH_TABLE") {
      return false;
    }
    throw err;
  }
}

export async function loadApplicationTimeline(executor, applicationIds = []) {
  const ids = Array.from(
    new Set(
      (Array.isArray(applicationIds) ? applicationIds : [])
        .map((id) => Number(id))
        .filter((id) => Number.isFinite(id))
    )
  );

  if (!ids.length) {
    return new Map();
  }

  try {
    const placeholders = ids.map(() => "?").join(", ");
    const [rows] = await executor.query(
      `
      SELECT
        h.id,
        h.application_id,
        h.status,
        h.note,
        h.changed_by,
        h.created_at,
        CONCAT(COALESCE(u.first_name, ''), ' ', COALESCE(u.last_name, '')) AS actor_name,
        u.role AS actor_role
      FROM application_status_history h
      LEFT JOIN users u ON u.id = h.changed_by
      WHERE h.application_id IN (${placeholders})
      ORDER BY h.application_id ASC, h.created_at ASC, h.id ASC
      `,
      ids
    );

    const timelineByApplication = new Map();
    rows.forEach((row) => {
      if (!timelineByApplication.has(row.application_id)) {
        timelineByApplication.set(row.application_id, []);
      }

      timelineByApplication.get(row.application_id).push({
        id: row.id,
        status: row.status,
        note: row.note || "",
        changedBy: row.changed_by,
        actorName: String(row.actor_name || "").trim(),
        actorRole: row.actor_role || "",
        createdAt: row.created_at,
      });
    });

    return timelineByApplication;
  } catch (err) {
    if (err?.code === "ER_NO_SUCH_TABLE") {
      return new Map();
    }
    throw err;
  }
}
